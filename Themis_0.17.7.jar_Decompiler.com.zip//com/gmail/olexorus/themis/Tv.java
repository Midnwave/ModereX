package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum Tv {
   FULL,
   SYSTEM,
   HIDDEN;

   private static final Tv[] g;

   private static Tv[] P() {
      return new Tv[]{FULL, SYSTEM, HIDDEN};
   }

   static {
      long var0 = kt.a(-4745459172035837524L, -5624958017528854462L, MethodHandles.lookup().lookupClass()).a(117736885029357L) ^ 69410454864433L;
      FULL = new Tv("FULL", 0);
      SYSTEM = new Tv("SYSTEM", 1);
      HIDDEN = new Tv("HIDDEN", 2);
      g = P();
   }
}

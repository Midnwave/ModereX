package com.gmail.olexorus.themis;

import java.util.Iterator;

abstract class cq {
   private final Iterator<RS<K, V>> C;
   protected RS<K, V> m;
   final OB e;

   cq(OB var1) {
      this.e = var1;
      this.C = this.e.H.iterator();
   }

   public boolean hasNext() {
      return this.C.hasNext();
   }

   public RS<K, V> v() {
      this.m = (RS)this.C.next();
      return this.m;
   }

   public void remove() {
      OB.T(this.e, this.m.D);
      this.C.remove();
   }
}

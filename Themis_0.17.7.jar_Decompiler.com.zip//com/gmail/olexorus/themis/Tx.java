package com.gmail.olexorus.themis;

import java.util.BitSet;

public class Tx {
   public static final Tx P;
   public static final Tx y;
   private final BitSet b;
   private final ax R;

   private Tx(BitSet var1, ax var2) {
      this.R = var2;
      this.b = var1;
   }

   public Tx(BitSet var1) {
      this.R = ax.PARTIALLY_FILTERED;
      this.b = var1;
   }

   public BitSet H() {
      return this.b;
   }

   public ax V() {
      return this.R;
   }

   static {
      P = new Tx(new BitSet(0), ax.FULLY_FILTERED);
      y = new Tx(new BitSet(0), ax.PASS_THROUGH);
   }
}

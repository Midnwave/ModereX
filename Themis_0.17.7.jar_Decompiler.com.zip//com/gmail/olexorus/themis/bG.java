package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public final class bG {
   private V R;
   private V y;
   private float x;
   private float b;
   private static final long a = kt.a(-5433551247042336158L, 1930262223942604365L, MethodHandles.lookup().lookupClass()).a(55093779108865L);

   public bG(V var1, V var2, float var3, float var4) {
      this.R = var1;
      this.y = var2;
      this.x = var3;
      this.b = var4;
   }

   public static bG B(lm<?> var0) {
      V var1 = V.c(var0);
      V var2 = V.c(var0);
      float var3 = var0.L();
      float var4 = var0.L();
      return new bG(var1, var2, var3, var4);
   }

   public static void s(lm<?> var0, bG var1) {
      V.q(var0, var1.R);
      V.q(var0, var1.y);
      var0.S(var1.x);
      var0.S(var1.b);
   }

   public V V() {
      return this.R;
   }

   public float K() {
      return this.x;
   }

   public float m() {
      return this.b;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof bG)) {
         return false;
      } else {
         bG var2 = (bG)var1;
         if (Float.compare(var2.x, this.x) != 0) {
            return false;
         } else if (Float.compare(var2.b, this.b) != 0) {
            return false;
         } else {
            return !this.R.equals(var2.R) ? false : this.y.equals(var2.y);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.R, this.y, this.x, this.b});
   }

   public String toString() {
      long var1 = a ^ 30115302711011L;
      return "EntityPositionData{position=" + this.R + ", deltaMovement=" + this.y + ", yaw=" + this.x + ", pitch=" + this.b + '}';
   }
}

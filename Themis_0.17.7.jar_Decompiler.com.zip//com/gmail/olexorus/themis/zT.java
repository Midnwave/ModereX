package com.gmail.olexorus.themis;

public final class zT {
   private al G;
   private O6 v;

   public zT(al var1, O6 var2) {
      this.G = var1;
      this.v = var2;
   }

   public static zT u(lm<?> var0) {
      al var1 = var0.R();
      O6 var2 = O6.I(var0);
      return new zT(var1, var2);
   }

   public static void U(lm<?> var0, zT var1) {
      var0.T(var1.G);
      O6.M(var0, var1.v);
   }
}

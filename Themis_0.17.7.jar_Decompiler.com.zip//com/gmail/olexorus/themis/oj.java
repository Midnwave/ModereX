package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum oj {
   START_SNEAKING,
   STOP_SNEAKING,
   LEAVE_BED,
   START_SPRINTING,
   STOP_SPRINTING,
   START_JUMPING_WITH_HORSE,
   STOP_JUMPING_WITH_HORSE,
   OPEN_HORSE_INVENTORY,
   START_FLYING_WITH_ELYTRA;

   private static final oj[] s;
   private static final oj[] u;
   private static final long a = kt.a(6691852302450232520L, 8510837761441201128L, MethodHandles.lookup().lookupClass()).a(74629113588256L);

   private oj() {
   }

   public abstract int T(zZ var1);

   public static oj o(zZ var0, int var1) {
      long var2 = a ^ 136749654731017L;
      oj[] var4 = s;
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         oj var7 = var4[var6];
         if (var7.T(var0) == var1) {
            return var7;
         }
      }

      throw new IllegalStateException("Invalid entity action id " + var1 + " for " + var0);
   }

   private static oj[] C() {
      return new oj[]{START_SNEAKING, STOP_SNEAKING, LEAVE_BED, START_SPRINTING, STOP_SPRINTING, START_JUMPING_WITH_HORSE, STOP_JUMPING_WITH_HORSE, OPEN_HORSE_INVENTORY, START_FLYING_WITH_ELYTRA};
   }

   oj(As var3) {
      this();
   }

   static {
      long var0 = a ^ 97998342855461L;
      START_SNEAKING = new oE("START_SNEAKING", 0);
      STOP_SNEAKING = new oM("STOP_SNEAKING", 1);
      LEAVE_BED = new oH("LEAVE_BED", 2);
      START_SPRINTING = new of("START_SPRINTING", 3);
      STOP_SPRINTING = new oY("STOP_SPRINTING", 4);
      START_JUMPING_WITH_HORSE = new oV("START_JUMPING_WITH_HORSE", 5);
      STOP_JUMPING_WITH_HORSE = new oy("STOP_JUMPING_WITH_HORSE", 6);
      OPEN_HORSE_INVENTORY = new oI("OPEN_HORSE_INVENTORY", 7);
      START_FLYING_WITH_ELYTRA = new oi("START_FLYING_WITH_ELYTRA", 8);
      u = C();
      s = values();
   }
}

package com.gmail.olexorus.themis;

public class sz extends lm<sz> {
   private boolean G;

   public void t() {
      this.G = this.P();
   }

   public void z(sz var1) {
      this.G = var1.G;
   }

   public void d() {
      this.I(this.G);
   }
}

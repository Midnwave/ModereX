package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class od extends oh {
   private V F;
   private v2 n;
   private int q;
   private static final long a = kt.a(4893947827962101448L, -6803445616429445043L, MethodHandles.lookup().lookupClass()).a(17214533427065L);

   public od(V var1, v2 var2, int var3) {
      this.F = var1;
      this.n = var2;
      this.q = var3;
   }

   public static od K(lm<?> var0) {
      V var1 = V.c(var0);
      v2 var2 = new v2(var0.f());
      int var3 = var0.R().i(zZ.V_1_21_4) ? var0.Q() : 25;
      return new od(var1, var2, var3);
   }

   public static void Q(lm<?> var0, od var1) {
      V.q(var0, var1.F);
      var0.L(var1.n.V());
      if (var0.R().i(zZ.V_1_21_4)) {
         var0.E(var1.q);
      }

   }

   public static od j(RT var0, vL var1) {
      long var2 = a ^ 21801472263155L;
      V var4 = V.b(var0.W("target"), var1);
      v2 var5 = v2.o(var0.W("color"), var1);
      int var6 = 25;
      if (var1.K(vL.V_1_21_4)) {
         var6 = var0.N("duration").P();
      }

      return new od(var4, var5, var6);
   }

   public static void N(od var0, vL var1, RT var2) {
      long var3 = a ^ 7512034059599L;
      var2.j("target", V.Q(var0.F, var1));
      var2.j("color", v2.j(var0.n, var1));
      if (var1.K(vL.V_1_21_4)) {
         var2.j("duration", new mz(var0.q));
      }

   }

   public boolean p() {
      return false;
   }
}

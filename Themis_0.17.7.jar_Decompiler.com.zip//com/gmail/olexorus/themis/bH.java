package com.gmail.olexorus.themis;

import java.util.Objects;

public class bH {
   private Gj<zl> d;

   public bH(Gj<zl> var1) {
      this.d = var1;
   }

   public static bH s(lm<?> var0) {
      Gj var1 = Gj.K(var0, My.a(), zl::s);
      return new bH(var1);
   }

   public static void c(lm<?> var0, bH var1) {
      Gj.G(var0, var1.d, zl::w);
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof bH)) {
         return false;
      } else {
         bH var2 = (bH)var1;
         return this.d.equals(var2.d);
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.d);
   }
}

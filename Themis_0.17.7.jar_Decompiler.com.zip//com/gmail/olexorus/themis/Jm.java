package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class Jm {
   private static final long a = kt.a(-915145014515191251L, -8540934837123161629L, MethodHandles.lookup().lookupClass()).a(176405976087062L);

   public static aw R(Object var0, Gs var1, Object var2, Object var3, boolean var4) {
      // $FF: Couldn't be decompiled
   }

   public static aE W(Object var0, Gs var1, Object var2, Object var3, boolean var4) {
      // $FF: Couldn't be decompiled
   }
}

package com.gmail.olexorus.themis;

public interface NP<I extends X, R> {
   R h(I var1);

   default R z(I var1) {
      return this.D(var1, (Object)null);
   }

   default R D(I var1, R var2) {
      return var1 == null ? var2 : this.h(var1);
   }
}

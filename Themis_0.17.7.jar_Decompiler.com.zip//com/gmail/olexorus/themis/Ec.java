package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.Objects;

final class Ec extends E2 implements TG {
   private final String c;
   private static final long f = kt.a(-5813465182048096244L, -7089725998585011859L, MethodHandles.lookup().lookupClass()).a(145589836279607L);

   static TG F(List<? extends lv> var0, WR var1, String var2) {
      long var3 = f ^ 58699346404510L;
      return new Ec(lv.Z(var0, p), (WR)Objects.requireNonNull(var1, "style"), (String)Objects.requireNonNull(var2, "keybind"));
   }

   Ec(List<X> var1, WR var2, String var3) {
      super(var1, var2);
      this.c = var3;
   }

   public String T() {
      return this.c;
   }

   public TG K(List<? extends lv> var1) {
      return F(var1, this.F, this.c);
   }

   public TG R(WR var1) {
      return F(this.E, var1, this.c);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof TG)) {
         return false;
      } else if (!super.equals(var1)) {
         return false;
      } else {
         TG var2 = (TG)var1;
         return Objects.equals(this.c, var2.T());
      }
   }

   public int hashCode() {
      int var1 = super.hashCode();
      var1 = 31 * var1 + this.c.hashCode();
      return var1;
   }

   public String toString() {
      return cH.M(this);
   }

   public W_ w() {
      return new AF(this);
   }
}

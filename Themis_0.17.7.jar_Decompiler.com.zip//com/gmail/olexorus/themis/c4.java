package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class c4 extends id implements lr {
   private final int H;
   private final int Y;
   private final al r;
   private static final long b = kt.a(8954213784707542062L, 6579580587308648320L, MethodHandles.lookup().lookupClass()).a(266573610316081L);

   public c4(int var1, int var2, al var3) {
      this((z2)null, var1, var2, var3);
   }

   public c4(z2 var1, int var2, int var3, al var4) {
      super(var1);
      this.H = var2;
      this.Y = var3;
      this.r = var4;
   }

   public lr W(z2 var1) {
      return new c4(var1, this.H, this.Y, this.r);
   }

   public int o() {
      return this.H;
   }

   public int i() {
      return this.Y;
   }

   public al j() {
      return this.r;
   }

   public boolean I(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof c4)) {
         return false;
      } else if (!super.equals(var1)) {
         return false;
      } else {
         c4 var2 = (c4)var1;
         if (this.H != var2.H) {
            return false;
         } else {
            return this.Y != var2.Y ? false : this.r.equals(var2.r);
         }
      }
   }

   public int z() {
      return Objects.hash(new Object[]{super.hashCode(), this.H, this.Y, this.r});
   }

   public String toString() {
      long var1 = b ^ 71498278050493L;
      return "StaticPaintingVariant{width=" + this.H + ", height=" + this.Y + ", assetId=" + this.r + '}';
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum Gz {
   FOOD,
   BLOCKS,
   MISC;

   private static final Gz[] T;

   private static Gz[] E() {
      return new Gz[]{FOOD, BLOCKS, MISC};
   }

   static {
      long var0 = kt.a(5320203344958386435L, 8360232895738371009L, MethodHandles.lookup().lookupClass()).a(48433908390675L) ^ 103291242667556L;
      FOOD = new Gz("FOOD", 0);
      BLOCKS = new Gz("BLOCKS", 1);
      MISC = new Gz("MISC", 2);
      T = E();
   }
}

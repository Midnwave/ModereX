package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum b6 {
   CRAFTING,
   FURNACE,
   BLAST_FURNACE,
   SMOKER;

   private static final b6[] u;

   public int I() {
      return this.ordinal();
   }

   public static b6 W(int var0) {
      return u[var0];
   }

   // $FF: synthetic method
   private static b6[] B() {
      return new b6[]{CRAFTING, FURNACE, BLAST_FURNACE, SMOKER};
   }

   static {
      long var0 = kt.a(1644136020287600556L, 2022660073769480651L, MethodHandles.lookup().lookupClass()).a(113473360902084L) ^ 63871500958284L;
      CRAFTING = new b6("CRAFTING", 0);
      FURNACE = new b6("FURNACE", 1);
      BLAST_FURNACE = new b6("BLAST_FURNACE", 2);
      SMOKER = new b6("SMOKER", 3);
      u = values();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum W5 {
   SUCCESSFULLY_LOADED,
   DECLINED,
   FAILED_DOWNLOAD,
   ACCEPTED,
   DOWNLOADED,
   INVALID_URL,
   FAILED_RELOAD,
   DISCARDED;

   public static final W5[] VALUES;
   private static final W5[] I;

   private static W5[] h() {
      return new W5[]{SUCCESSFULLY_LOADED, DECLINED, FAILED_DOWNLOAD, ACCEPTED, DOWNLOADED, INVALID_URL, FAILED_RELOAD, DISCARDED};
   }

   static {
      long var0 = kt.a(9131911064940235399L, 9090227398658229253L, MethodHandles.lookup().lookupClass()).a(32409920635460L) ^ 96000219724602L;
      SUCCESSFULLY_LOADED = new W5("SUCCESSFULLY_LOADED", 0);
      DECLINED = new W5("DECLINED", 1);
      FAILED_DOWNLOAD = new W5("FAILED_DOWNLOAD", 2);
      ACCEPTED = new W5("ACCEPTED", 3);
      DOWNLOADED = new W5("DOWNLOADED", 4);
      INVALID_URL = new W5("INVALID_URL", 5);
      FAILED_RELOAD = new W5("FAILED_RELOAD", 6);
      DISCARDED = new W5("DISCARDED", 7);
      I = h();
      VALUES = values();
   }
}

package com.gmail.olexorus.themis;

import java.util.List;
import java.util.Objects;

public final class Ed {
   public static final tw<Ed> Y = (new uG()).I();
   public static final tw<List<Ed>> t;
   private final CW c;
   private final double u;

   public Ed(CW var1, double var2) {
      this.c = var1;
      this.u = var2;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof Ed)) {
         return false;
      } else {
         Ed var2 = (Ed)var1;
         return Double.compare(var2.u, this.u) != 0 ? false : this.c.equals(var2.c);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.c, this.u});
   }

   static CW j(Ed var0) {
      return var0.c;
   }

   static double c(Ed var0) {
      return var0.u;
   }

   static {
      t = Y.c();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

enum zG implements it {
   REMOVED;

   private static final zG[] p;

   private static zG[] p() {
      return new zG[]{REMOVED};
   }

   static {
      long var0 = kt.a(4370463336418214447L, -6092340082366781266L, MethodHandles.lookup().lookupClass()).a(274424932062416L) ^ 83460440232402L;
      REMOVED = new zG("REMOVED", 0);
      p = p();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class Mg {
   private static final long a = kt.a(-2477309306792899124L, -8420668834556417374L, MethodHandles.lookup().lookupClass()).a(211177206838368L);

   public String y(n9 var1) {
      return this.C(var1);
   }

   public String C(Rl var1) {
      long var2 = a ^ 101976490435661L;
      String var4 = var1.getClass().getGenericInterfaces()[0].toString();
      return var4.startsWith("kotlin.jvm.functions.") ? var4.substring("kotlin.jvm.functions.".length()) : var4;
   }
}

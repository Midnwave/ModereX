package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Optional;

public enum G4 {
   ROLLABLE,
   ALIGNED;

   private static final G4[] P;
   private final String X;
   private static final G4[] d;

   private G4(String var3) {
      this.X = var3;
   }

   public String j() {
      return this.X;
   }

   public static Optional<G4> B(String var0) {
      return Arrays.stream(P).filter(G4::lambda$byName$0).findFirst();
   }

   private static boolean lambda$byName$0(String var0, G4 var1) {
      return var1.j().equals(var0);
   }

   private static G4[] B() {
      return new G4[]{ROLLABLE, ALIGNED};
   }

   static {
      long var0 = kt.a(-7126018114453376957L, 7237585183784014470L, MethodHandles.lookup().lookupClass()).a(263029544742830L) ^ 78835438293120L;
      ROLLABLE = new G4("ROLLABLE", 0, "rollable");
      ALIGNED = new G4("ALIGNED", 1, "aligned");
      d = B();
      P = values();
   }
}

package com.gmail.olexorus.themis;

import java.util.BitSet;

public class JJ {
   public static long[] O(lm<?> var0) {
      if (var0.R().i(zZ.V_1_17)) {
         return var0.J();
      } else {
         return var0.R().i(zZ.V_1_9) ? new long[]{(long)var0.Q()} : new long[]{(long)var0.C()};
      }
   }

   public static BitSet p(lm<?> var0) {
      return BitSet.valueOf(O(var0));
   }

   public static void O(lm<?> var0, BitSet var1) {
      long[] var2 = var1.toLongArray();
      if (var0.R().i(zZ.V_1_17)) {
         var0.Q(var2);
      } else if (var0.R().i(zZ.V_1_9)) {
         if (var2.length > 0) {
            var0.E((int)var2[0]);
         } else {
            var0.E(0);
         }
      } else if (var2.length > 0) {
         var0.f((int)var2[0]);
      } else {
         var0.f(0);
      }

   }
}

package com.gmail.olexorus.themis;

import java.util.Arrays;
import java.util.List;

class OA {
   static <T> List<T> v(T[] var0) {
      return Arrays.asList(var0);
   }
}

package com.gmail.olexorus.themis;

import java.util.UUID;

public class QA extends lm<QA> {
   private byte[] J;
   private UUID K;
   private byte[] X;
   private byte[] u;

   public void t() {
      this.J = (byte[])this.u(lm::w);
      this.K = this.V();
      this.X = this.w();
      this.u = this.w();
   }

   public void d() {
      this.l(this.J, lm::N);
      this.y(this.K);
      this.N(this.X);
      this.N(this.u);
   }

   public void F(QA var1) {
      this.J = var1.J;
      this.K = var1.K;
      this.X = var1.X;
      this.u = var1.u;
   }
}

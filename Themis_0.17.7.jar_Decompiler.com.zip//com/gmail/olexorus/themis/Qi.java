package com.gmail.olexorus.themis;

public class Qi extends lm<Qi> {
   public static boolean k = true;
   private Cm w;
   private boolean U;
   private X S;

   public Qi(aE var1) {
      super(var1);
   }

   public void t() {
      this.S = this.a();
      if (this.I.i(zZ.V_1_19_1)) {
         this.U = this.P();
      } else {
         this.w = (Cm)this.y(mg.o());
      }

   }

   public void d() {
      this.G(this.S);
      if (this.I.i(zZ.V_1_19_1)) {
         this.I(this.U);
      } else if (this.w == null) {
         if (this.U) {
            this.j(mg.r);
         } else {
            this.j(mg.B);
         }
      } else {
         this.j(this.w);
      }

   }

   public void M(Qi var1) {
      this.w = var1.w;
      this.U = var1.U;
      this.S = var1.S;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class CF {
   private static final N8<cy> z;
   public static final cy n;
   public static final cy Y;
   public static final cy P;
   private static final long a = kt.a(4411933764022727L, 3451070169764790893L, MethodHandles.lookup().lookupClass()).a(8860856347646L);

   public static cy j(String var0, String var1) {
      long var2 = a ^ 29924631882905L;
      al var4 = new al("entity/frog/" + var1);
      return (cy)z.h(var0, CF::lambda$define$0);
   }

   public static N8<cy> O() {
      return z;
   }

   private static iH lambda$define$0(al var0, z2 var1) {
      return new iH(var1, var0);
   }

   static {
      long var0 = a ^ 34402595495329L;
      z = new N8("frog_variant");
      n = j("cold", "cold_frog");
      Y = j("temperate", "temperate_frog");
      P = j("warm", "warm_frog");
      z.f();
   }
}

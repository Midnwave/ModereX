package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

class Aw extends A5<VA, vy> implements vy {
   private v1 f;
   private static final long c = kt.a(-4386118961820224083L, -7765262918923541720L, MethodHandles.lookup().lookupClass()).a(90374358020816L);

   Aw() {
   }

   Aw(VA var1) {
      super(var1);
      this.f = var1.W();
   }

   public vy n(v1 var1) {
      long var2 = c ^ 6474342741904L;
      this.f = (v1)Objects.requireNonNull(var1, "storage");
      return this;
   }

   public VA k() {
      long var1 = c ^ 138078801069196L;
      if (this.o == null) {
         throw new IllegalStateException("nbt path must be set");
      } else if (this.f == null) {
         throw new IllegalStateException("storage must be set");
      } else {
         return lW.q(this.y, this.l(), this.o, this.B, this.R, this.f);
      }
   }
}

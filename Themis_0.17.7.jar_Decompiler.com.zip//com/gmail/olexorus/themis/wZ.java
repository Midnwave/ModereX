package com.gmail.olexorus.themis;

import java.time.Instant;
import java.util.UUID;

public class wZ extends wa {
   int S;

   public wZ(int var1, UUID var2, int var3, byte[] var4, String var5, Instant var6, long var7, oX var9, X var10, Tx var11, r0 var12) {
      super(var2, var3, var4, var5, var6, var7, var9, var10, var11, var12);
      this.S = var1;
   }

   public int F() {
      return this.S;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum gk {
   EMIT_LEGACY_NBT,
   EMIT_DATA_COMPONENTS,
   EMIT_EITHER;

   private static final gk[] T;

   private static gk[] V() {
      return new gk[]{EMIT_LEGACY_NBT, EMIT_DATA_COMPONENTS, EMIT_EITHER};
   }

   static {
      long var0 = kt.a(8300242145102205135L, -461873492380845874L, MethodHandles.lookup().lookupClass()).a(97771602464331L) ^ 58030240828707L;
      EMIT_LEGACY_NBT = new gk("EMIT_LEGACY_NBT", 0);
      EMIT_DATA_COMPONENTS = new gk("EMIT_DATA_COMPONENTS", 1);
      EMIT_EITHER = new gk("EMIT_EITHER", 2);
      T = V();
   }
}

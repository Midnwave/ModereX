package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum OS {
   PINK,
   BLUE,
   RED,
   GREEN,
   YELLOW,
   PURPLE,
   WHITE;

   public static final l3<String, OS> NAMES;
   private final String Z;
   private static final OS[] K;

   private OS(String var3) {
      this.Z = var3;
   }

   private static String lambda$static$0(OS var0) {
      return var0.Z;
   }

   private static OS[] k() {
      return new OS[]{PINK, BLUE, RED, GREEN, YELLOW, PURPLE, WHITE};
   }

   static {
      long var0 = kt.a(8659128946874522948L, -5428849504965720L, MethodHandles.lookup().lookupClass()).a(57885918303527L) ^ 88375287199250L;
      PINK = new OS("PINK", 0, "pink");
      BLUE = new OS("BLUE", 1, "blue");
      RED = new OS("RED", 2, "red");
      GREEN = new OS("GREEN", 3, "green");
      YELLOW = new OS("YELLOW", 4, "yellow");
      PURPLE = new OS("PURPLE", 5, "purple");
      WHITE = new OS("WHITE", 6, "white");
      K = k();
      NAMES = l3.Q(OS.class, OS::lambda$static$0);
   }
}

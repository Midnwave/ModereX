package com.gmail.olexorus.themis;

public class tQ extends tO<tQ> {
   public static final tQ b = new tQ();

   private tQ() {
      super(B_.T);
   }

   public static tQ t(lm<?> var0) {
      return b;
   }

   public static void n(lm<?> var0, tQ var1) {
   }
}

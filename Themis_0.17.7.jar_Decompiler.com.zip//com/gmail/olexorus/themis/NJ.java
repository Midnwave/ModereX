package com.gmail.olexorus.themis;

import java.util.function.Function;

public interface NJ<C> {
   X X(X var1, C var2);

   private default X lambda$mapContext$0(Function var1, X var2, Object var3) {
      return this.X(var2, var1.apply(var3));
   }
}

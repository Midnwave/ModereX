package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collections;

public final class j {
   private static final N8<GI> y;
   public static final GI a;
   public static final GI k;
   public static final GI g;
   public static final GI I;
   public static final GI Y;
   public static final GI o;
   public static final GI L;
   public static final GI D;
   public static final GI x;
   private static final long b = kt.a(-5573829051094098134L, 5995669369124958432L, MethodHandles.lookup().lookupClass()).a(93306596530283L);

   public static GI v(String var0, gC<Wa> var1) {
      long var2 = b ^ 76570360233613L;
      return a(var0, "wolf_" + var0, var1);
   }

   public static GI a(String var0, String var1, gC<Wa> var2) {
      long var3 = b ^ 84524902138980L;
      return k(var0, al.z("entity/wolf/" + var1), al.z("entity/wolf/" + var1 + "_tame"), al.z("entity/wolf/" + var1 + "_angry"), var2);
   }

   public static GI k(String var0, al var1, al var2, al var3, gC<Wa> var4) {
      return (GI)y.h(var0, j::lambda$define$0);
   }

   public static N8<GI> E() {
      return y;
   }

   private static ik lambda$define$0(al var0, al var1, al var2, gC var3, z2 var4) {
      return new ik(var4, var0, var1, var2, var3);
   }

   static {
      long var0 = b ^ 19115565064026L;
      y = new N8("wolf_variant");
      a = a("pale", "wolf", new gC(Collections.singletonList(zW.pj)));
      k = v("spotted", new gC(al.z("is_savanna")));
      g = v("snowy", new gC(Collections.singletonList(zW.X)));
      I = v("black", new gC(Collections.singletonList(zW.p1)));
      Y = v("ashen", new gC(Collections.singletonList(zW.z)));
      o = v("rusty", new gC(al.z("is_jungle")));
      L = v("woods", new gC(Collections.singletonList(zW.pw)));
      D = v("chestnut", new gC(Collections.singletonList(zW.p9)));
      x = v("striped", new gC(al.z("is_badlands")));
      y.f();
   }
}

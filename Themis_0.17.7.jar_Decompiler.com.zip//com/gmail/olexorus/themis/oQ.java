package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class oQ extends oh {
   private float W;
   private v2 s;
   private static final long a = kt.a(-6127439840719498332L, 1571592263305705997L, MethodHandles.lookup().lookupClass()).a(32209309138330L);

   public oQ(float var1, v2 var2) {
      this.W = var1;
      this.s = var2;
   }

   public static oQ l(lm<?> var0) {
      v2 var1;
      float var2;
      if (var0.R().i(zZ.V_1_21_2)) {
         var1 = new v2(var0.f());
      } else {
         var2 = var0.L();
         float var3 = var0.L();
         float var4 = var0.L();
         var1 = new v2(var2, var3, var4);
      }

      var2 = var0.L();
      return new oQ(var2, var1);
   }

   public static void p(lm<?> var0, oQ var1) {
      if (var0.R().i(zZ.V_1_21_2)) {
         var0.L(var1.s.V());
      } else {
         var0.S(var1.o());
         var0.S(var1.O());
         var0.S(var1.u());
      }

      var0.S(var1.W);
   }

   public static oQ S(RT var0, vL var1) {
      long var2 = a ^ 31790837013414L;
      v2 var4 = v2.o(var0.W("color"), var1);
      float var5 = var0.N("scale").b();
      return new oQ(var5, var4);
   }

   public static void e(oQ var0, vL var1, RT var2) {
      long var3 = a ^ 83250000216334L;
      var2.j("color", v2.j(var0.s, var1));
      var2.j("scale", new m6(var0.W));
   }

   public boolean p() {
      return false;
   }

   public float o() {
      return (float)this.s.k() / 255.0F;
   }

   public float O() {
      return (float)this.s.v() / 255.0F;
   }

   public float u() {
      return (float)this.s.D() / 255.0F;
   }
}

package com.gmail.olexorus.themis;

enum of {
   public int T(zZ var1) {
      if (var1.i(zZ.V_1_21_6)) {
         return this.ordinal() - 2;
      } else {
         return var1.R(zZ.V_1_7_10) ? 4 : this.ordinal();
      }
   }
}

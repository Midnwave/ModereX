package com.gmail.olexorus.themis;

public class y8 extends lm<y8> {
   private o0 E;
   private boolean j;
   private VC x;
   private int A;

   public void t() {
      this.x = this.M();
      this.A = this.Q();
      this.E = o0.d(this.Q());
      this.j = this.P();
   }

   public void d() {
      this.o(this.x);
      this.E(this.A);
      this.E(this.E.O());
      this.I(this.j);
   }

   public void c(y8 var1) {
      this.E = var1.E;
      this.j = var1.j;
      this.x = var1.x;
      this.A = var1.A;
   }
}

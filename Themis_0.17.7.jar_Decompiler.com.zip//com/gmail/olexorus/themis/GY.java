package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.stream.Stream;

public interface GY extends d<GY, A4>, Gl<GY> {
   long b = kt.a(7942989798742924713L, -1654347378998021792L, MethodHandles.lookup().lookupClass()).a(244903453959199L);

   String p();

   List<X> p();

   List<VE> n();

   GY P(List<? extends lv> var1);

   String R();

   default Stream<? extends rE> T() {
      long var1 = b ^ 118593887986508L;
      return Stream.concat(Stream.of(rE.c("key", this.p()), rE.E("arguments", this.n()), rE.c("fallback", this.R())), d.super.T());
   }
}

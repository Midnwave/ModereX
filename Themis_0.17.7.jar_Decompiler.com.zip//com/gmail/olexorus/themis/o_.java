package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum o_ {
   BIOME,
   CHUNK;

   private final int A;
   private final int C;
   private final boolean r;
   private final int z;
   private final int k;

   private o_(int var3, int var4, boolean var5, int var6) {
      this.A = var3;
      this.C = var4;
      this.r = var5;
      this.z = var6;
      this.k = 1 << var6 * 3;
   }

   public GX s() {
      int var1 = this.V();
      Gm var2 = new Gm(var1);
      nK var3 = new nK(var1, this.f());
      return new GX(var2, var3, this);
   }

   public int V() {
      return this.A;
   }

   public int A() {
      return this.C;
   }

   public boolean T() {
      return this.r;
   }

   public int g() {
      return this.z;
   }

   public int f() {
      return this.k;
   }

   // $FF: synthetic method
   private static o_[] F() {
      return new o_[]{BIOME, CHUNK};
   }

   static {
      long var0 = kt.a(-2161919489721322291L, -5925540342845599001L, MethodHandles.lookup().lookupClass()).a(83771836952321L) ^ 90784304441294L;
      BIOME = new o_("BIOME", 0, 3, 3, false, 2);
      CHUNK = new o_("CHUNK", 1, 4, 8, true, 4);
   }
}

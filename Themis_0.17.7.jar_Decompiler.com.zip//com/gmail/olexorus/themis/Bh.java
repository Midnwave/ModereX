package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;

public final class Bh {
   private final Map<Ro, Vn> V;
   private static final long a = kt.a(5588791226608792903L, -648179938329658235L, MethodHandles.lookup().lookupClass()).a(123118818139340L);

   public Bh(Map<Ro, Vn> var1) {
      this.V = var1;
   }

   public static Bh k(lm<?> var0) {
      EnumMap var1 = new EnumMap(Ro.class);
      Ro[] var2 = Ro.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Ro var5 = var2[var4];
         var1.put(var5, Vn.N(var0));
      }

      return new Bh(var1);
   }

   public static void k(lm<?> var0, Bh var1) {
      Ro[] var2 = Ro.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Ro var5 = var2[var4];
         Vn.L(var0, var1.k(var5));
      }

   }

   public Vn k(Ro var1) {
      return (Vn)this.V.computeIfAbsent(var1, Bh::lambda$getState$0);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof Bh)) {
         return false;
      } else {
         Bh var2 = (Bh)var1;
         return this.V.equals(var2.V);
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.V);
   }

   public String toString() {
      long var1 = a ^ 72272629265681L;
      return "RecipeBookSettings{states=" + this.V + '}';
   }

   private static Vn lambda$getState$0(Ro var0) {
      return new Vn();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum zY {
   CHAT,
   SYSTEM;

   public static final l3<String, zY> ID_INDEX;
   private final String k;
   private static final zY[] p;

   private zY(String var3) {
      this.k = var3;
   }

   public String j() {
      return this.k;
   }

   private static zY[] f() {
      return new zY[]{CHAT, SYSTEM};
   }

   static {
      long var0 = kt.a(1778012133093819179L, -2125227911446065727L, MethodHandles.lookup().lookupClass()).a(45562609044511L) ^ 94591089338841L;
      CHAT = new zY("CHAT", 0, "chat");
      SYSTEM = new zY("SYSTEM", 1, "system");
      p = f();
      ID_INDEX = l3.Q(zY.class, zY::j);
   }
}

package com.gmail.olexorus.themis;

class ts implements AY<tY> {
   public <C> tY z(NJ<C> var1, C var2, tY var3) {
      return tY.R(var3) == null ? var3 : var3.D(var1.X(tY.R(var3), var2));
   }
}

package com.gmail.olexorus.themis;

public interface na {
   default Cu W(Cs var1) {
      return new Ce(this, var1);
   }

   default void G(ay var1) {
   }

   default void Q(ai var1) {
   }

   default void J(aI var1) {
   }

   default void L(aw var1) {
   }

   default void z(aE var1) {
   }

   default void U(a0 var1) {
   }
}

package com.gmail.olexorus.themis;

public class ao extends aw {
   public ao(Object var1, Gs var2, Object var3, Object var4, boolean var5) {
      super(var1, var2, var3, var4, var5);
   }

   protected ao(int var1, wC var2, zZ var3, Object var4, Gs var5, Object var6, Object var7) {
      super(var1, var2, var3, var4, var5, var6, var7);
   }

   public ao N() {
      try {
         Object var1 = NY.j(this.n());
         return new ao(this.K(), this.U(), this.M(), this.c(), this.Z(), this.O(), var1);
      } catch (Co var2) {
         var2.printStackTrace();
         return null;
      }
   }

   public A6 U() {
      return (A6)super.y();
   }
}

package com.gmail.olexorus.themis;

final class Bs extends BG implements bP {
   static final Bs h = new Bs();

   public boolean equals(Object var1) {
      return this == var1;
   }

   public int hashCode() {
      return 0;
   }
}

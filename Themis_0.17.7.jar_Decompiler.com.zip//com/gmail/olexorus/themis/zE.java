package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum zE {
   SURVIVAL,
   CREATIVE,
   ADVENTURE,
   SPECTATOR;

   private static final zE[] N;

   public int q() {
      return this.ordinal();
   }

   public static zE o(int var0) {
      return var0 >= 0 && var0 < N.length ? N[var0] : SURVIVAL;
   }

   public static zE N() {
      return SURVIVAL;
   }

   // $FF: synthetic method
   private static zE[] Z() {
      return new zE[]{SURVIVAL, CREATIVE, ADVENTURE, SPECTATOR};
   }

   static {
      long var0 = kt.a(-5666217935496956755L, -7788084866902796095L, MethodHandles.lookup().lookupClass()).a(128605702230290L) ^ 91170728253422L;
      SURVIVAL = new zE("SURVIVAL", 0);
      CREATIVE = new zE("CREATIVE", 1);
      ADVENTURE = new zE("ADVENTURE", 2);
      SPECTATOR = new zE("SPECTATOR", 3);
      N = values();
   }
}

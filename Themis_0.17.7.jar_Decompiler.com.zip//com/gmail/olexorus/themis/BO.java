package com.gmail.olexorus.themis;

public interface BO extends MC {
   static BO f(String var0) {
      return new MW(var0);
   }

   default uX<BO> y() {
      return tq.c;
   }

   String o();
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import java.util.NoSuchElementException;

class Op implements Iterator<E>, lK {
   private int l;
   final CU<E> e;
   private static final long a = kt.a(-9035251275028069211L, -1813139490443335104L, MethodHandles.lookup().lookupClass()).a(176255272434399L);

   public Op(CU var1) {
      this.e = var1;
   }

   protected final int W() {
      return this.l;
   }

   protected final void w(int var1) {
      this.l = var1;
   }

   public boolean hasNext() {
      return this.l < this.e.size();
   }

   public E next() {
      if (!this.hasNext()) {
         throw new NoSuchElementException();
      } else {
         CU var10000 = this.e;
         int var1 = this.l++;
         return var10000.get(var1);
      }
   }

   public void remove() {
      long var1 = a ^ 122348739058365L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }
}

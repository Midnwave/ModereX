package com.gmail.olexorus.themis;

public interface a1<T, C extends c7<?, ? extends bJ>> extends zo<T, C> {
}

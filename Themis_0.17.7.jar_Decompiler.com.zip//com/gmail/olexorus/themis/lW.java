package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.Objects;

final class lW extends Eq<VA, vy> implements VA {
   private final v1 I;
   private static final long c = kt.a(-3609884584986243666L, -7662106938648080594L, MethodHandles.lookup().lookupClass()).a(39182202724117L);

   static VA q(List<? extends lv> var0, WR var1, String var2, boolean var3, lv var4, v1 var5) {
      long var6 = c ^ 16284264874772L;
      return new lW(lv.Z(var0, p), (WR)Objects.requireNonNull(var1, "style"), (String)Objects.requireNonNull(var2, "nbtPath"), var3, lv.z(var4), (v1)Objects.requireNonNull(var5, "storage"));
   }

   lW(List<X> var1, WR var2, String var3, boolean var4, X var5, v1 var6) {
      super(var1, var2, var3, var4, var5);
      this.I = var6;
   }

   public X V() {
      return this.i;
   }

   public v1 W() {
      return this.I;
   }

   public VA F(List<? extends lv> var1) {
      return q(var1, this.F, this.v, this.X, this.i, this.I);
   }

   public VA w(WR var1) {
      return q(this.E, var1, this.v, this.X, this.i, this.I);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof VA)) {
         return false;
      } else if (!super.equals(var1)) {
         return false;
      } else {
         lW var2 = (lW)var1;
         return Objects.equals(this.I, var2.W());
      }
   }

   public int hashCode() {
      int var1 = super.hashCode();
      var1 = 31 * var1 + this.I.hashCode();
      return var1;
   }

   public String toString() {
      return cH.M(this);
   }

   public vy S() {
      return new Aw(this);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class M1 {
   private static Method T;
   private static Method G;
   private static Method S;
   private static Method k;
   private static final long a = kt.a(-4450039083445945536L, 1740699070389116428L, MethodHandles.lookup().lookupClass()).a(91919859446297L);

   public static void c() {
      long var0 = a ^ 23255742786672L;
      Class var2 = EO.A("channel.ChannelHandlerContext");

      try {
         T = EO.q1.getDeclaredMethod("decode", var2, EO.P, List.class);
         T.setAccessible(true);
      } catch (NoSuchMethodException var7) {
         var7.printStackTrace();
      }

      try {
         G = EO.q5.getDeclaredMethod("encode", var2, Object.class, EO.P);
         G.setAccessible(true);
      } catch (NoSuchMethodException var6) {
         var6.printStackTrace();
      }

      Class var3;
      try {
         var3 = EO.A("handler.codec.MessageToMessageDecoder");
         S = var3.getDeclaredMethod("decode", var2, Object.class, List.class);
         S.setAccessible(true);
      } catch (NoSuchMethodException var5) {
         var5.printStackTrace();
      }

      try {
         var3 = EO.A("handler.codec.MessageToMessageEncoder");
         k = var3.getDeclaredMethod("encode", var2, Object.class, List.class);
         k.setAccessible(true);
      } catch (NoSuchMethodException var4) {
         var4.printStackTrace();
      }

   }

   public static List<Object> i(Object var0, Object var1, Object var2) {
      ArrayList var3 = new ArrayList();

      try {
         T.invoke(var0, var1, var2, var3);
      } catch (IllegalAccessException var5) {
         var5.printStackTrace();
      }

      return var3;
   }

   public static void Q(Object var0, Object var1, Object var2, Object var3) {
      try {
         G.invoke(var0, var1, var2, var3);
      } catch (IllegalAccessException var5) {
         var5.printStackTrace();
      }

   }
}

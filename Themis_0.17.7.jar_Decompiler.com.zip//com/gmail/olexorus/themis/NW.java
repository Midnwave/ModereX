package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum NW {
   NOT_SET,
   FALSE,
   TRUE;

   private final String N;
   private static final NW[] G;

   private NW(String var3) {
      this.N = var3;
   }

   public String toString() {
      return this.N;
   }

   public static NW O(boolean var0) {
      return var0 ? TRUE : FALSE;
   }

   public static NW S(Boolean var0) {
      return var0 == null ? NOT_SET : O(var0);
   }

   private static NW[] f() {
      return new NW[]{NOT_SET, FALSE, TRUE};
   }

   static {
      long var0 = kt.a(-1862247450340153367L, 1557152421652091331L, MethodHandles.lookup().lookupClass()).a(140600299629024L) ^ 32082030270099L;
      NOT_SET = new NW("NOT_SET", 0, "not_set");
      FALSE = new NW("FALSE", 1, "false");
      TRUE = new NW("TRUE", 2, "true");
      G = f();
   }
}

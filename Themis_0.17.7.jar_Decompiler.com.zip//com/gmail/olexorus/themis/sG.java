package com.gmail.olexorus.themis;

public class sG extends lm<sG> {
   private uZ E;
   private V C;
   private Ep c;

   public void t() {
      this.E = uZ.i(this.Q());
      this.C = new V(this.o(), this.o(), this.o());
      this.c = (Ep)this.u(sG::lambda$read$0);
   }

   public void d() {
      this.E(this.E.t());
      this.v(this.C.o());
      this.v(this.C.h());
      this.v(this.C.D());
      this.l(this.c, sG::lambda$write$1);
   }

   public void d(sG var1) {
      this.E = var1.E;
      this.C = var1.C;
      this.c = var1.c;
   }

   private static void lambda$write$1(lm var0, Ep var1) {
      var0.E(var1.c());
      var0.E(var1.T().t());
   }

   private static Ep lambda$read$0(lm var0) {
      return new Ep(var0.Q(), uZ.i(var0.Q()));
   }
}

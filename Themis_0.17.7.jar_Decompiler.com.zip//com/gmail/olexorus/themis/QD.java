package com.gmail.olexorus.themis;

public class QD extends lm<QD> {
   private int E;
   private double u;
   private double w;
   private double Y;

   public void t() {
      this.E = this.Q();
      if (this.I.i(zZ.V_1_21)) {
         this.m(this.o());
      } else {
         this.u = this.o();
         this.w = this.o();
         this.Y = this.o();
      }

   }

   public void d() {
      this.E(this.E);
      if (this.I.i(zZ.V_1_21)) {
         this.v(this.X());
      } else {
         this.v(this.u);
         this.v(this.w);
         this.v(this.Y);
      }

   }

   public void P(QD var1) {
      this.E = var1.E;
      this.u = var1.u;
      this.w = var1.w;
      this.Y = var1.Y;
   }

   public double X() {
      return this.u;
   }

   public void m(double var1) {
      this.u = var1;
      this.w = var1;
      this.Y = var1;
   }
}

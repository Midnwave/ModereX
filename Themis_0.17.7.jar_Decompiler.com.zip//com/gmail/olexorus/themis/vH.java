package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class vH {
   private final al d;
   private final Rc f;
   private static final long a = kt.a(1153881653872309025L, 4887501280008355042L, MethodHandles.lookup().lookupClass()).a(271975149232409L);

   public vH(RT var1) {
      long var2 = a ^ 139539953468168L;
      this(new al(var1.N("name")), var1.M("element"));
   }

   public vH(al var1, Rc var2) {
      this.d = var1;
      this.f = var2;
   }

   public static List<vH> x(m_<RT> var0) {
      ArrayList var1 = new ArrayList(var0.N());
      Iterator var2 = var0.N().iterator();

      while(var2.hasNext()) {
         RT var3 = (RT)var2.next();
         var1.add(new vH(var3));
      }

      return Collections.unmodifiableList(var1);
   }

   public al v() {
      return this.d;
   }

   public Rc R() {
      return this.f;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof vH)) {
         return false;
      } else {
         vH var2 = (vH)var1;
         return !this.d.equals(var2.d) ? false : Objects.equals(this.f, var2.f);
      }
   }

   public int hashCode() {
      int var1 = this.d.hashCode();
      var1 = 31 * var1 + (this.f != null ? this.f.hashCode() : 0);
      return var1;
   }

   public String toString() {
      long var1 = a ^ 126602089286253L;
      return "RegistryElement{id=" + this.d + ", data=" + this.f + '}';
   }
}

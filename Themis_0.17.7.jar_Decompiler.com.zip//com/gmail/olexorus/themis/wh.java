package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum wh {
   DOWN,
   UP,
   NORTH,
   SOUTH,
   WEST,
   EAST;

   private final int P;
   private final B3 D;
   private final VC y;
   private static final wh[] k;
   private static final wh[] Z;

   private wh(int var3, B3 var4, VC var5) {
      this.P = var3;
      this.D = var4;
      this.y = var5;
   }

   public int o() {
      return this.P;
   }

   public static wh H(int var0) {
      return k[var0 % k.length];
   }

   // $FF: synthetic method
   private static wh[] o() {
      return new wh[]{DOWN, UP, NORTH, SOUTH, WEST, EAST};
   }

   static {
      long var0 = kt.a(-3535117556263602618L, 5708180193244337319L, MethodHandles.lookup().lookupClass()).a(123884935922118L) ^ 124243891225912L;
      DOWN = new wh("DOWN", 0, -1, B3.Y, new VC(0, -1, 0));
      UP = new wh("UP", 1, -1, B3.Y, new VC(0, 1, 0));
      NORTH = new wh("NORTH", 2, 0, B3.Z, new VC(0, 0, -1));
      SOUTH = new wh("SOUTH", 3, 1, B3.Z, new VC(0, 0, 1));
      WEST = new wh("WEST", 4, 2, B3.X, new VC(-1, 0, 0));
      EAST = new wh("EAST", 5, 3, B3.X, new VC(1, 0, 0));
      k = new wh[]{NORTH, SOUTH, WEST, EAST};
      Z = values();
   }
}

package com.gmail.olexorus.themis;

public class yG extends lm<yG> {
   private uE K;
   private int u;
   private float x;
   private float n;

   public void t() {
      this.K = uE.B(this.Q());
      if (this.I.i(zZ.V_1_19)) {
         this.u = this.Q();
         if (this.I.i(zZ.V_1_21)) {
            this.x = this.L();
            this.n = this.L();
         }
      }

   }

   public void d() {
      this.E(this.K.p());
      if (this.I.i(zZ.V_1_19)) {
         this.E(this.u);
         if (this.I.i(zZ.V_1_21)) {
            this.S(this.x);
            this.S(this.n);
         }
      }

   }

   public void p(yG var1) {
      this.K = var1.K;
      this.u = var1.u;
      this.x = var1.x;
      this.n = var1.n;
   }
}

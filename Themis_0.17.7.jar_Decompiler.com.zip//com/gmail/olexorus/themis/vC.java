package com.gmail.olexorus.themis;

import com.gmail.olexorus.themis.api.CheckType;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;

public final class vC extends vh {
   private long P;
   private static int Y;

   public vC(Player var1, Vb var2) {
      super(CheckType.TICKRATE, var1, var2);
   }

   public void T(Object[] param1) {
      // $FF: Couldn't be decompiled
   }

   public void p(Object[] var1) {
      long var3 = (Long)var1[0];
      PlayerTeleportEvent var2 = (PlayerTeleportEvent)var1[1];
      int var5 = T7();

      vC var10000;
      long var10001;
      short var10002;
      label32: {
         label31: {
            try {
               var10000 = this;
               var10001 = this.P;
               var10002 = this.t(new Object[0]).O(new Object[0]);
               if (var5 != 0) {
                  break label32;
               }

               if (var10002 != 0) {
                  break label31;
               }
            } catch (RuntimeException var7) {
               throw a(var7);
            }

            var10002 = 50;
            break label32;
         }

         var10002 = 2500;
      }

      try {
         var10000.P = var10001 - (long)var10002;
         if (var3 > 0L && vh.i() == null) {
            ++var5;
            f(var5);
         }

      } catch (RuntimeException var6) {
         throw a(var6);
      }
   }

   public void b(Object[] var1) {
      VehicleEnterEvent var2 = (VehicleEnterEvent)var1[0];
      this.P -= (long)50;
   }

   public void f(Object[] var1) {
      VehicleExitEvent var2 = (VehicleExitEvent)var1[0];
      this.P -= (long)50;
   }

   public static void f(int var0) {
      Y = var0;
   }

   public static int T2() {
      return Y;
   }

   public static int T7() {
      int var0 = T2();

      try {
         return var0 == 0 ? 52 : 0;
      } catch (RuntimeException var1) {
         throw a(var1);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   static {
      if (T7() != 0) {
         f(58);
      }

   }
}

package com.gmail.olexorus.themis;

import com.google.gson.TypeAdapter;
import java.lang.invoke.MethodHandles;

final class Rm {
   static final TypeAdapter<Bb> F;

   static {
      long var0 = kt.a(4732898480890346031L, -2896546790177959036L, MethodHandles.lookup().lookupClass()).a(150310631050109L) ^ 54949400190494L;
      F = u6.q("click action", Bb.NAMES);
   }
}

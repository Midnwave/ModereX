package com.gmail.olexorus.themis;

public class QR extends lm<QR> {
   private float q;
   private boolean N;

   public void t() {
      this.q = this.L();
      this.N = this.P();
   }

   public void d() {
      this.S(this.q);
      this.I(this.N);
   }

   public void f(QR var1) {
      this.q = var1.q;
      this.N = var1.N;
   }
}

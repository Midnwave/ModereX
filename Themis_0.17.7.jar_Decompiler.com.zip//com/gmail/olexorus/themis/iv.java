package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class iv extends id implements OC {
   public static final uk T;
   private final i_ s;
   private final uk p;
   private static final long a = kt.a(-7867580635577042482L, 8105643401764241324L, MethodHandles.lookup().lookupClass()).a(94678778604817L);

   public iv(i_ var1, uk var2) {
      this((z2)null, var1, var2);
   }

   public iv(z2 var1, i_ var2, uk var3) {
      super(var1);
      this.s = var2;
      this.p = var3;
   }

   public static iv R(RT var0, lm<?> var1) {
      long var2 = a ^ 20001273678603L;
      i_ var4 = i_.H(var0, var1);
      uk var5 = (uk)var0.P("action", uk::x, T, var1);
      return new iv((z2)null, var4, var5);
   }

   public static void N(RT var0, lm<?> var1, iv var2) {
      long var3 = a ^ 78297304169673L;
      i_.A(var0, var1, var2.s);
      if (var2.p != T) {
         var0.X("action", var2.p, uk::m, var1);
      }

   }

   public OC R(z2 var1) {
      return new iv(var1, this.s, this.p);
   }

   public i_ P() {
      return this.s;
   }

   public uk O() {
      return this.p;
   }

   public T<?> M() {
      return ag.J;
   }

   public boolean I(Object var1) {
      if (!(var1 instanceof iv)) {
         return false;
      } else if (!super.equals(var1)) {
         return false;
      } else {
         iv var2 = (iv)var1;
         return !this.s.equals(var2.s) ? false : this.p.equals(var2.p);
      }
   }

   public int z() {
      return Objects.hash(new Object[]{super.hashCode(), this.s, this.p});
   }

   static {
      long var0 = a ^ 42956551913801L;
      T = new uk(new Vy(X.D("gui.ok"), (X)null, 150), (T9)null);
   }
}

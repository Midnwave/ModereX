package com.gmail.olexorus.themis;

public class Zi extends lm<Zi> {
   private int W;
   private String x;
   private byte[] B;

   public void t() {
      this.W = this.Q();
      this.x = this.A();
      this.B = this.j(NY.r(this.g));
   }

   public void d() {
      this.E(this.W);
      this.I(this.x);
      this.N(this.B);
   }

   public void q(Zi var1) {
      this.W = var1.W;
      this.x = var1.x;
      this.B = var1.B;
   }
}

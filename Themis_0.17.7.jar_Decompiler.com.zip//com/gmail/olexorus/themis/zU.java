package com.gmail.olexorus.themis;

import java.util.List;
import java.util.Objects;

public class zU {
   private gC<cB> F;
   private List<Oe> t;
   private RT b;
   private MP m;

   public zU(gC<cB> var1, List<Oe> var2, RT var3, MP var4) {
      this.F = var1;
      this.t = var2;
      this.b = var3;
      this.m = var4;
   }

   public static zU J(lm<?> var0) {
      gC var1 = (gC)var0.u(zU::lambda$read$0);
      List var2 = (List)var0.u(zU::lambda$read$1);
      RT var3 = (RT)var0.u(lm::u);
      MP var4 = var0.R().i(zZ.V_1_21_5) ? MP.v(var0) : new MP();
      return new zU(var1, var2, var3, var4);
   }

   public static void Z(lm<?> var0, zU var1) {
      var0.l(var1.F, gC::n);
      var0.l(var1.t, zU::lambda$write$2);
      var0.l(var1.b, lm::G);
      if (var0.R().i(zZ.V_1_21_5)) {
         MP.a(var0, var1.m);
      }

   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof zU)) {
         return false;
      } else {
         zU var2 = (zU)var1;
         if (!Objects.equals(this.F, var2.F)) {
            return false;
         } else if (!Objects.equals(this.t, var2.t)) {
            return false;
         } else {
            return !Objects.equals(this.b, var2.b) ? false : this.m.equals(var2.m);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.F, this.t, this.b, this.m});
   }

   private static void lambda$write$2(lm var0, List var1) {
      var0.D(var1, Oe::u);
   }

   private static List lambda$read$1(lm var0, lm var1) {
      return var0.j(Oe::w);
   }

   private static gC lambda$read$0(lm var0) {
      return gC.P(var0, rS::P);
   }
}

package com.gmail.olexorus.themis;

public class lT extends lc<lT> {
}

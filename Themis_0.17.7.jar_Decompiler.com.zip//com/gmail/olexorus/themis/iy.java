package com.gmail.olexorus.themis;

public class iy extends id implements zD {
   public iy(z2 var1) {
      super(var1);
   }
}

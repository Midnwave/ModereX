package com.gmail.olexorus.themis;

public abstract class ZW<T extends ZW<T>> extends lm<T> {
   public ZW(wC var1) {
      super(var1);
   }
}

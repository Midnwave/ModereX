package com.gmail.olexorus.themis;

import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelPipeline;
import java.lang.invoke.MethodHandles;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.bukkit.entity.Player;

public class NZ implements vd {
   public final Set<Channel> n = new HashSet();
   public List<Object> A;
   private int I = -1;
   private static final long a = kt.a(-652516519612703834L, 8571308773411639778L, MethodHandles.lookup().lookupClass()).a(226545931972111L);

   public void y(Gs var1, Object var2) {
      Object var3 = var1.b();
      if (var3 == null) {
         var3 = oS.J().v().n(var2);
      }

      this.q(var3, var2);
   }

   public boolean B() {
      Object var1 = EO.o();
      if (var1 != null) {
         vJ var2 = new vJ(var1);

         for(int var3 = 0; var3 < 2; ++var3) {
            List var4 = var2.x(var3);
            Iterator var5 = var4.iterator();

            while(var5.hasNext()) {
               Object var6 = var5.next();
               if (var6 instanceof ChannelFuture) {
                  this.I = var3;
                  return true;
               }
            }
         }
      }

      return false;
   }

   public void U() {
      long var1 = a ^ 18926178837131L;
      Object var3 = EO.o();
      if (var3 != null) {
         vJ var4 = new vJ(var3);
         List var5 = var4.x(this.I);
         nd var6 = new nd(var5, this::lambda$inject$0);
         var4.S(this.I, var6);
         if (this.A == null) {
            this.A = EO.T();
         }

         synchronized(this.A) {
            if (!this.A.isEmpty()) {
               oS.J().m().n("Late bind not enabled, injecting into existing channel");
            }

            Iterator var8 = this.A.iterator();

            while(var8.hasNext()) {
               Object var9 = var8.next();
               vJ var10 = new vJ(var9);
               Channel var11 = (Channel)var10.Q(0, Channel.class);
               if (var11 != null) {
                  try {
                     GR.K(var11, uy.PLAY);
                  } catch (Exception var14) {
                     oS.J().m().Q("PacketEvents Spigot injector failed to inject into an existing channel. If you need assistance, join our Discord server: https://discord.gg/DVHxPPxHZc");
                     var14.printStackTrace();
                  }
               }
            }
         }
      }

   }

   public void Z() {
      Iterator var1 = this.n.iterator();

      while(var1.hasNext()) {
         Channel var2 = (Channel)var1.next();
         this.q(var2);
      }

      this.n.clear();
      Object var4 = EO.o();
      if (var4 != null) {
         vJ var5 = new vJ(var4);
         List var3 = var5.x(this.I);
         if (var3 instanceof nd) {
            var5.S(this.I, ((nd)var3).v());
         }
      }

   }

   private void n(Channel var1) {
      long var2 = a ^ 57699430140688L;
      ChannelPipeline var4 = var1.pipeline();
      ChannelHandler var5 = var4.get(oS.g);
      if (var5 != null) {
         var4.remove(oS.g);
      }

      if (var4.get("SpigotNettyServerChannelHandler#0") != null) {
         var4.addAfter("SpigotNettyServerChannelHandler#0", oS.g, new wS());
      } else if (var4.get("floodgate-init") != null) {
         var4.addAfter("floodgate-init", oS.g, new wS());
      } else if (var4.get("MinecraftPipeline#0") != null) {
         var4.addAfter("MinecraftPipeline#0", oS.g, new wS());
      } else {
         var4.addFirst(oS.g, new wS());
      }

      if (this.A == null) {
         this.A = EO.T();
      }

      synchronized(this.A) {
         Iterator var7 = this.A.iterator();

         while(var7.hasNext()) {
            Object var8 = var7.next();
            vJ var9 = new vJ(var8);
            Channel var10 = (Channel)var9.Q(0, Channel.class);
            if (var10 != null && var10.isOpen() && var10.localAddress().equals(var1.localAddress())) {
               var10.close();
            }
         }

      }
   }

   private void q(Channel var1) {
      long var2 = a ^ 70295366778288L;
      if (var1.pipeline().get(oS.g) != null) {
         var1.pipeline().remove(oS.g);
      } else {
         oS.J().m().A("Failed to uninject server channel, handler not found");
      }

   }

   public void n(Object var1, Gs var2) {
      CP var3 = this.N((Channel)var1);
      if (var3 != null) {
         var3.h = var2;
      }

      Nu var4 = this.u((Channel)var1);
      if (var4 != null) {
         var4.K = var2;
      }

   }

   public void q(Object var1, Object var2) {
      CP var3 = this.N((Channel)var1);
      if (var3 != null) {
         var3.Q = (Player)var2;
      }

      Nu var4 = this.u((Channel)var1);
      if (var4 != null) {
         var4.A = (Player)var2;
         var4.K.h().s(((Player)var2).getName());
         var4.K.h().G(((Player)var2).getUniqueId());
      }

   }

   public CP N(Channel var1) {
      return (CP)var1.pipeline().get(oS.H);
   }

   public Nu u(Channel var1) {
      return (Nu)var1.pipeline().get(oS.z);
   }

   public boolean T() {
      return false;
   }

   private void lambda$inject$0(ChannelFuture var1) {
      Channel var2 = var1.channel();
      this.n(var2);
      this.n.add(var2);
   }
}

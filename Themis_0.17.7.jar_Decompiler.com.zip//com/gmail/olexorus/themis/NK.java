package com.gmail.olexorus.themis;

import java.util.List;
import java.util.Objects;

public class NK {
   private List<m7> d;

   public NK(List<m7> var1) {
      this.d = var1;
   }

   public static NK W(lm<?> var0) {
      List var1 = var0.j(m7::L);
      return new NK(var1);
   }

   public static void k(lm<?> var0, NK var1) {
      var0.D(var1.d, m7::Y);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof NK)) {
         return false;
      } else {
         NK var2 = (NK)var1;
         return this.d.equals(var2.d);
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.d);
   }
}

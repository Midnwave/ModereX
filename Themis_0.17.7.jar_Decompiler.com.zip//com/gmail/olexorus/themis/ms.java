package com.gmail.olexorus.themis;

public interface ms<T> {
   void r(RT var1, lm<?> var2, T var3);
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.function.BiFunction;

public interface GI extends GL, uW<GI>, rp {
   long b = kt.a(-4611456585944624338L, -2340838884991516575L, MethodHandles.lookup().lookupClass()).a(65207613826888L);

   al e();

   al D();

   al Y();

   gC<Wa> u();

   static GI y(lm<?> var0) {
      return !var0.R().i(zZ.V_1_21_5) && !var0.R().m(zZ.V_1_21) ? (GI)var0.i((VD)j.E(), (MO)(GI::t)) : (GI)var0.y((VD)j.E());
   }

   static void h(lm<?> var0, GI var1) {
      if (!var0.R().i(zZ.V_1_21_5) && !var0.R().m(zZ.V_1_21)) {
         var0.M(var1, GI::R);
      } else {
         var0.j((GL)var1);
      }

   }

   static GI t(lm<?> var0) {
      al var1 = var0.R();
      al var2 = var0.R();
      al var3 = var0.R();
      gC var4 = gC.P((lm)var0, (BiFunction)zW.V());
      return new ik(var1, var2, var3, var4);
   }

   static void R(lm<?> var0, GI var1) {
      var0.T(var1.e());
      var0.T(var1.D());
      var0.T(var1.Y());
      gC.n(var0, var1.u());
   }

   static GI n(Rc var0, lm<?> var1, z2 var2) {
      long var3 = b ^ 107927848175151L;
      RT var5 = (RT)var0;
      al var7;
      al var8;
      if (var1.R().m(zZ.V_1_21_5)) {
         al var10 = new al(var5.N("wild_texture"));
         var7 = new al(var5.N("tame_texture"));
         var8 = new al(var5.N("angry_texture"));
         gC var11 = (gC)var5.g("biomes", GI::lambda$decode$0, var1);
         return new ik(var2, var10, var7, var8, var11);
      } else {
         RT var6 = var5.l("assets");
         var7 = new al(var6.N("wild"));
         var8 = new al(var6.N("tame"));
         al var9 = new al(var6.N("angry"));
         return new ik(var2, var7, var8, var9, gC.l());
      }
   }

   private static gC lambda$decode$0(Rc var0, lm var1) {
      return gC.T(var0, var1, zW.V());
   }
}

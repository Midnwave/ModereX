package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collection;
import java.util.Iterator;

public abstract class CT<E> implements Collection<E>, lK {
   private static final long a = kt.a(3793837503678909472L, 8302937174247825226L, MethodHandles.lookup().lookupClass()).a(200954114132371L);

   protected CT() {
   }

   public abstract int q();

   public abstract Iterator<E> iterator();

   public boolean contains(E var1) {
      Iterable var2 = (Iterable)this;
      boolean var3 = false;
      boolean var10000;
      if (var2 instanceof Collection && ((Collection)var2).isEmpty()) {
         var10000 = false;
      } else {
         Iterator var4 = var2.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = false;
               break;
            }

            Object var5 = var4.next();
            boolean var7 = false;
            if (bU.I(var5, var1)) {
               var10000 = true;
               break;
            }
         }
      }

      return var10000;
   }

   public boolean containsAll(Collection<? extends Object> var1) {
      Iterable var2 = (Iterable)var1;
      boolean var3 = false;
      boolean var10000;
      if (((Collection)var2).isEmpty()) {
         var10000 = true;
      } else {
         Iterator var4 = var2.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = true;
               break;
            }

            Object var5 = var4.next();
            boolean var7 = false;
            if (!this.contains(var5)) {
               var10000 = false;
               break;
            }
         }
      }

      return var10000;
   }

   public boolean isEmpty() {
      return this.size() == 0;
   }

   public String toString() {
      long var1 = a ^ 3890133178053L;
      return wF.e((Iterable)this, (CharSequence)", ", (CharSequence)"[", (CharSequence)"]", 0, (CharSequence)null, (Gg)(new nI(this)), 24, (Object)null);
   }

   public Object[] toArray() {
      return z8.t((Collection)this);
   }

   public <T> T[] toArray(T[] var1) {
      return z8.s((Collection)this, var1);
   }

   public boolean add(E var1) {
      long var2 = a ^ 33262277415613L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean addAll(Collection<? extends E> var1) {
      long var2 = a ^ 44959108254283L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public void clear() {
      long var1 = a ^ 11787407530205L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean remove(Object var1) {
      long var2 = a ^ 50225909477497L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean removeAll(Collection<? extends Object> var1) {
      long var2 = a ^ 15501503512826L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean retainAll(Collection<? extends Object> var1) {
      long var2 = a ^ 71552978785970L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }
}

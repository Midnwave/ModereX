package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum EX {
   INTEGER,
   HEARTS;

   private static final EX[] e;
   private static final EX[] R;

   public static EX S(String var0) {
      EX[] var1 = e;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         EX var4 = var1[var3];
         if (var4.name().equalsIgnoreCase(var0)) {
            return var4;
         }
      }

      return null;
   }

   public static EX V(int var0) {
      return e[var0];
   }

   private static EX[] o() {
      return new EX[]{INTEGER, HEARTS};
   }

   static {
      long var0 = kt.a(-6352306061183861301L, -55659048969052402L, MethodHandles.lookup().lookupClass()).a(58446368456227L) ^ 36608221241793L;
      INTEGER = new EX("INTEGER", 0);
      HEARTS = new EX("HEARTS", 1);
      R = o();
      e = values();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class Tj {
   private static final N8<bo<?>> I;
   public static final bo<?> h;
   public static final bo<zq> c;
   public static final bo<AH> u;
   public static final bo<OX> X;
   public static final bo<rj> s;
   public static final bo<Cr> b;
   public static final bo<BP> z;
   public static final bo<r> J;
   public static final bo<lf> w;
   public static final bo<tV> e;
   public static final bo<JC> o;
   public static final bo<cr> W;
   public static final bo<lu> j;
   public static final bo<Rd> H;
   public static final bo<cm> A;
   public static final bo<JY> i;

   public static N8<bo<?>> Z() {
      return I;
   }

   public static <T> bo<T> P(String var0) {
      return F(var0, (MO)null, (Gw)null);
   }

   public static <T> bo<T> F(String var0, MO<T> var1, Gw<T> var2) {
      return (bo)I.h(var0, Tj::lambda$define$0);
   }

   private static iB lambda$define$0(MO var0, Gw var1, z2 var2) {
      return new iB(var2, var0, var1);
   }

   static {
      long var0 = kt.a(321725067933124352L, -4934062573981975775L, MethodHandles.lookup().lookupClass()).a(83446081799620L) ^ 34641767914212L;
      I = new N8("debug_subscription");
      h = P("dedicated_server_tick_time");
      c = F("bees", zq::x, zq::U);
      u = F("brains", AH::G, AH::m);
      X = F("breezes", OX::E, OX::B);
      s = F("goal_selectors", rj::B, rj::E);
      b = F("entity_paths", Cr::C, Cr::M);
      z = F("entity_block_intersections", BP::u, BP::b);
      J = F("bee_hives", r::G, r::A);
      w = F("pois", lf::I, lf::k);
      e = F("redstone_wire_orientations", tV::g, tV::Y);
      o = F("village_sections", JC::b, JC::i);
      W = F("raids", cr::D, cr::v);
      j = F("structures", lu::l, lu::U);
      H = F("game_event_listeners", Rd::m, Rd::n);
      A = F("neighbor_updates", cm::D, cm::t);
      i = F("game_events", JY::j, JY::e);
      I.f();
   }
}

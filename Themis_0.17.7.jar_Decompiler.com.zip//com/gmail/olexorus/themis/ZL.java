package com.gmail.olexorus.themis;

public class ZL extends ZD<ZL> {
   public void t() {
      this.z = OC.v(this);
   }

   public void d() {
      OC.X(this, this.z);
   }
}

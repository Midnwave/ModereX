package com.gmail.olexorus.themis;

public class a_ extends lm<a_> {
   private int M;
   private int C;

   public void t() {
      this.M = this.Q();
      this.C = this.Q();
   }

   public void d() {
      this.E(this.M);
      this.E(this.C);
   }

   public void u(a_ var1) {
      this.M = var1.M;
      this.C = var1.C;
   }
}

package com.gmail.olexorus.themis;

public class sL extends lm<sL> {
   private int f;
   private Ar v;
   private al K;
   private us<?> S;

   public void t() {
      if (this.I.i(zZ.V_1_21_2)) {
         this.f = this.a();
         this.S = us.e(this);
      } else {
         this.f = this.M();
         if (this.I.i(zZ.V_1_13)) {
            this.K = this.R();
         } else {
            this.v = Ar.F(this);
         }
      }

   }

   public void d() {
      this.y(this.f);
      if (this.I.i(zZ.V_1_21_2)) {
         us.N(this, this.S);
      } else if (this.I.i(zZ.V_1_13)) {
         this.T(this.K);
      } else {
         Ar.w(this, this.v);
      }

   }

   public void P(sL var1) {
      this.f = var1.f;
      this.v = var1.v;
      this.K = var1.K;
      this.S = var1.S;
   }
}

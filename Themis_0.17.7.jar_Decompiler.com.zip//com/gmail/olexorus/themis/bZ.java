package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum bZ {
   NONE,
   CLOCKWISE_90,
   CLOCKWISE_180,
   COUNTERCLOCKWISE_90;

   // $FF: synthetic method
   private static bZ[] I() {
      return new bZ[]{NONE, CLOCKWISE_90, CLOCKWISE_180, COUNTERCLOCKWISE_90};
   }

   static {
      long var0 = kt.a(-6315591631294669111L, -2803352540922217696L, MethodHandles.lookup().lookupClass()).a(37530239637959L) ^ 101787523294163L;
      NONE = new bZ("NONE", 0);
      CLOCKWISE_90 = new bZ("CLOCKWISE_90", 1);
      CLOCKWISE_180 = new bZ("CLOCKWISE_180", 2);
      COUNTERCLOCKWISE_90 = new bZ("COUNTERCLOCKWISE_90", 3);
   }
}

package com.gmail.olexorus.themis;

public class cD<T> extends id implements Jf<T> {
   private final Wj<T> S;
   private final T A;

   public cD(z2 var1, Wj<T> var2, T var3) {
      super(var1);
      this.S = var2;
      this.A = var3;
   }

   public boolean i() {
      return this.S != null;
   }

   public Wj<T> l() {
      if (this.S == null) {
         throw new UnsupportedOperationException();
      } else {
         return this.S;
      }
   }

   public T F() {
      if (this.A == null) {
         throw new UnsupportedOperationException();
      } else {
         return this.A;
      }
   }
}

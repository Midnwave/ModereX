package com.gmail.olexorus.themis;

// $FF: synthetic class
class cb {
   static final int[] W = new int[Bb.values().length];

   static {
      try {
         W[Bb.OPEN_URL.ordinal()] = 1;
      } catch (NoSuchFieldError var8) {
      }

      try {
         W[Bb.OPEN_FILE.ordinal()] = 2;
      } catch (NoSuchFieldError var7) {
      }

      try {
         W[Bb.RUN_COMMAND.ordinal()] = 3;
      } catch (NoSuchFieldError var6) {
      }

      try {
         W[Bb.SUGGEST_COMMAND.ordinal()] = 4;
      } catch (NoSuchFieldError var5) {
      }

      try {
         W[Bb.CHANGE_PAGE.ordinal()] = 5;
      } catch (NoSuchFieldError var4) {
      }

      try {
         W[Bb.COPY_TO_CLIPBOARD.ordinal()] = 6;
      } catch (NoSuchFieldError var3) {
      }

      try {
         W[Bb.SHOW_DIALOG.ordinal()] = 7;
      } catch (NoSuchFieldError var2) {
      }

      try {
         W[Bb.CUSTOM.ordinal()] = 8;
      } catch (NoSuchFieldError var1) {
      }

   }
}

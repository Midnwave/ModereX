package com.gmail.olexorus.themis;

public class iN extends id implements TY {
   public iN(z2 var1) {
      super(var1);
   }
}

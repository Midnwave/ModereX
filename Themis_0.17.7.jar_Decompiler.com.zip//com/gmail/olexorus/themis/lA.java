package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

class lA extends E2 implements Aa {
   private static final boolean I;
   static final Aa M;
   static final Aa f;
   static final Aa Q;
   private final String z;
   private static final long c = kt.a(-9078468472811795363L, 8900413939803999754L, MethodHandles.lookup().lookupClass()).a(62227128594828L);

   static Aa w(List<? extends lv> var0, WR var1, String var2) {
      long var3 = c ^ 103312139348046L;
      List var5 = lv.Z(var0, p);
      return (Aa)(var5.isEmpty() && var1.A() && var2.isEmpty() ? X.f() : new lA(var5, (WR)Objects.requireNonNull(var1, "style"), (String)Objects.requireNonNull(var2, "content")));
   }

   Aa p(List<? extends lv> var1, WR var2, String var3) {
      return w(var1, var2, var3);
   }

   private static Aa F(String var0) {
      return new lA(Collections.emptyList(), WR.O(), var0);
   }

   lA(List<X> var1, WR var2, String var3) {
      super(var1, var2);
      this.z = var3;
      if (I) {
         O7 var4 = this.e();
         if (var4 != null) {
            OP.G(var4);
         }
      }

   }

   final O7 e() {
      return this.z.indexOf(167) != -1 ? new O7(this) : null;
   }

   public String H() {
      return this.z;
   }

   public Aa q(String var1) {
      return (Aa)(Objects.equals(this.z, var1) ? this : this.p(this.E, this.F, var1));
   }

   public Aa u(List<? extends lv> var1) {
      return this.p(var1, this.F, this.z);
   }

   public Aa v(WR var1) {
      return this.p(this.E, var1, this.z);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof lA)) {
         return false;
      } else if (!super.equals(var1)) {
         return false;
      } else {
         lA var2 = (lA)var1;
         return Objects.equals(this.z, var2.z);
      }
   }

   public int hashCode() {
      int var1 = super.hashCode();
      var1 = 31 * var1 + this.z.hashCode();
      return var1;
   }

   public String toString() {
      return cH.M(this);
   }

   public nh E() {
      return new Aj(this);
   }

   static {
      I = Boolean.TRUE.equals(ud.E.i());
      M = F("");
      f = F("\n");
      Q = F(" ");
   }
}

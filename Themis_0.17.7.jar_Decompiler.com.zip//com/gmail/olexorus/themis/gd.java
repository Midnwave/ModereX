package com.gmail.olexorus.themis;

import java.io.Closeable;

public final class gd {
   public static final void C(Closeable var0, Throwable var1) {
      if (var0 != null) {
         if (var1 == null) {
            var0.close();
         } else {
            try {
               var0.close();
            } catch (Throwable var3) {
               iQ.t(var1, var3);
            }
         }
      }

   }
}

package com.gmail.olexorus.themis;

import java.util.Set;

public interface i extends GL {
   int u();

   int R();

   i u();

   vM X();

   Set<Mz> T();

   default zQ b() {
      return this.B(oS.J().g().w().u());
   }

   default zQ B(vL var1) {
      return zQ.C;
   }
}

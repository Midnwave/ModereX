package com.gmail.olexorus.themis;

import java.util.List;

public final class cr {
   private final List<VC> j;

   public cr(List<VC> var1) {
      this.j = var1;
   }

   public static cr D(lm<?> var0) {
      List var1 = var0.j(lm::M);
      return new cr(var1);
   }

   public static void v(lm<?> var0, cr var1) {
      var0.D(var1.j, lm::o);
   }
}

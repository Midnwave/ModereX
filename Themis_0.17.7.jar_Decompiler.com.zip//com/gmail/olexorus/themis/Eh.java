package com.gmail.olexorus.themis;

import com.google.common.collect.SetMultimap;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Eh {
   private final wi S;
   private final bJ y;
   private final List<l7> r = new ArrayList();
   private final String R;
   final String V;
   private int A = 1;
   private int n;
   List<String> v;
   private Set<l7> c = new HashSet();
   private int D;
   private int J;
   private boolean b;
   private static final long a = kt.a(8479426705278806990L, -3389038464294425336L, MethodHandles.lookup().lookupClass()).a(273341636689036L);

   public Eh(wi var1, ti var2, bJ var3) {
      this.S = var1;
      this.y = var3;
      this.n = var1.A;
      this.V = var1.o(var3);
      this.R = var2.P();
      SetMultimap var4 = var2.M();
      HashSet var5 = new HashSet();
      if (!var2.y().h) {
         Bd var6 = var2.E();
         if (var6 != null) {
            this.r.add(new l7(this, var6));
            var5.add(var6);
         }
      }

      var4.entries().forEach(this::lambda$new$0);
   }

   protected void D(l7 var1) {
      long var2 = a ^ 71070956903528L;
      if (this.v != null && !this.v.isEmpty()) {
         Bd var4 = var1.v();
         int var5 = 0;
         Iterator var6 = this.v.iterator();

         while(var6.hasNext()) {
            String var7 = (String)var6.next();
            Pattern var8 = Pattern.compile(".*" + Pattern.quote(var7) + ".*", 2);
            Iterator var9 = var4.s.iterator();

            while(var9.hasNext()) {
               String var10 = (String)var9.next();
               Pattern var11 = Pattern.compile(".*" + Pattern.quote(var10) + ".*", 2);
               if (var8.matcher(var10).matches()) {
                  var5 += 3;
               } else if (var11.matcher(var7).matches()) {
                  ++var5;
               }
            }

            if (var8.matcher(var1.s()).matches()) {
               var5 += 2;
            }

            if (var8.matcher(var1.T(this.y)).matches()) {
               ++var5;
            }

            if (var1.A() != null && var8.matcher(var1.A()).matches()) {
               var5 += 2;
            }
         }

         var1.U(var5);
      } else {
         var1.U(1);
      }
   }

   public boolean h(String var1) {
      this.c.clear();
      Iterator var2 = this.r.iterator();

      while(var2.hasNext()) {
         l7 var3 = (l7)var2.next();
         if (var3.z().endsWith(" " + var1)) {
            this.c.add(var3);
         }
      }

      return !this.c.isEmpty();
   }

   public void p() {
      this.O(this.y);
   }

   public void O(bJ var1) {
      long var2 = a ^ 30744681522783L;
      f var4 = this.S.C();
      Iterator var6;
      if (!this.c.isEmpty()) {
         l7 var12 = (l7)Oa.U(this.c);
         var4.d(this, var1, var12);
         var6 = this.c.iterator();

         while(var6.hasNext()) {
            l7 var13 = (l7)var6.next();
            var4.a(this, var13);
         }

         var4.a(this, var1, var12);
      } else {
         List var5 = (List)this.C().stream().filter(l7::n).collect(Collectors.toList());
         var6 = var5.stream().sorted(Comparator.comparingInt(Eh::lambda$showHelp$1)).iterator();
         if (!var6.hasNext()) {
            var1.W(zX.F, N6.NO_COMMAND_MATCHED_SEARCH, "{search}", Oa.d(this.v, " "));
            var5 = this.C();
            var6 = var5.iterator();
         }

         this.D = var5.size();
         int var7 = (this.A - 1) * this.n;
         int var8 = var7 + this.n;
         this.J = (int)Math.ceil((double)((float)this.D / (float)this.n));
         int var9 = 0;
         if (var7 >= this.D) {
            var1.W(zX.i, N6.HELP_NO_RESULTS);
         } else {
            ArrayList var10 = new ArrayList();

            while(var6.hasNext()) {
               l7 var11 = (l7)var6.next();
               if (var9 >= var8) {
                  break;
               }

               if (var9++ >= var7) {
                  var10.add(var11);
               }
            }

            this.b = var8 >= this.D;
            if (this.v == null) {
               var4.Z(this, var10);
            } else {
               var4.P(this, var10);
            }

         }
      }
   }

   public List<l7> C() {
      return this.r;
   }

   public void F(int var1) {
      this.n = var1;
   }

   public void s(int var1) {
      this.A = var1;
   }

   public void p(List<String> var1) {
      this.v = var1;
      this.C().forEach(this::D);
   }

   public bJ X() {
      return this.y;
   }

   public String m() {
      return this.R;
   }

   public String t() {
      return this.V;
   }

   public int S() {
      return this.A;
   }

   public int E() {
      return this.D;
   }

   public int o() {
      return this.J;
   }

   public boolean L() {
      return this.A == 1 && this.b;
   }

   private static int lambda$showHelp$1(l7 var0) {
      return var0.d() * -1;
   }

   private void lambda$new$0(bJ var1, Set var2, Entry var3) {
      long var4 = a ^ 12194374389111L;
      String var6 = (String)var3.getKey();
      if (!var6.equals("__default") && !var6.equals("__catchunknown")) {
         Bd var7 = (Bd)var3.getValue();
         if (!var7.n && var7.l(var1) && !var2.contains(var7)) {
            this.r.add(new l7(this, var7));
            var2.add(var7);
         }

      }
   }
}

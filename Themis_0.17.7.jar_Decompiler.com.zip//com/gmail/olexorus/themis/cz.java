package com.gmail.olexorus.themis;

public class cz<T extends us<?>> extends id implements Wu<T> {
   private final MO<T> n;
   private final Gw<T> p;

   public cz(z2 var1, MO<T> var2, Gw<T> var3) {
      super(var1);
      this.n = var2;
      this.p = var3;
   }

   public T j(lm<?> var1) {
      return (us)this.n.apply(var1);
   }

   public void i(lm<?> var1, T var2) {
      this.p.accept(var1, var2);
   }
}

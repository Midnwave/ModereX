package com.gmail.olexorus.themis;

public class GX {
   public final o_ t;
   public n5 C;
   public n0 z;

   public GX(n5 var1, n0 var2, o_ var3) {
      this.C = var1;
      this.z = var2;
      this.t = var3;
   }

   public static GX k(Br var0, o_ var1, boolean var2) {
      return s(var0, var1, var2, true);
   }

   public static GX s(Br var0, o_ var1, boolean var2, boolean var3) {
      byte var4 = var0.Q();
      n5 var5 = E(var1, var4, var0, var2);
      nK var6;
      if (!(var5 instanceof gM)) {
         long[] var7 = var3 ? var0.g(var0.G()) : null;
         var6 = new nK(var4, var1.f(), var7);
         if (!var3) {
            var0.h(var6.n());
         }
      } else {
         if (var3) {
            var0.g(var0.G());
         }

         var6 = null;
      }

      return new GX(var5, var6, var1);
   }

   public static void V(Wy var0, GX var1) {
      E(var0, var1, true);
   }

   public static void E(Wy var0, GX var1, boolean var2) {
      if (var1.C instanceof gM) {
         var0.e(0);
         var0.O(var1.C.e(0));
         if (var2) {
            var0.O(0);
         }

      } else {
         var0.e(var1.z.D());
         if (!(var1.C instanceof Aq)) {
            int var3 = var1.C.f();
            var0.O(var3);

            for(int var4 = 0; var4 < var3; ++var4) {
               var0.O(var1.C.e(var4));
            }
         }

         long[] var5 = var1.z.n();
         if (var2) {
            var0.O(var5.length);
         }

         var0.l(var5);
      }
   }

   public static GX p(Br var0) {
      int var1 = Math.max(4, var0.Q() & 255);
      n5 var2 = E(o_.CHUNK, var1, var0, false);
      nw var3 = new nw(var1, var0.g(var0.G()));
      return new GX(var2, var3, o_.CHUNK);
   }

   public int A(int var1, int var2, int var3) {
      if (this.z != null) {
         int var4 = this.z.h(C(this.t, var1, var2, var3));
         return this.C.e(var4);
      } else {
         return this.C.e(0);
      }
   }

   private static n5 E(o_ var0, int var1, Br var2, boolean var3) {
      if (var1 == 0 && var3) {
         return new gM(var2);
      } else if (var1 <= var0.V()) {
         int var4 = var0.T() ? var0.V() : var1;
         return new Gm(var4, var2);
      } else {
         return (n5)(var1 <= var0.A() ? new C3(var1, var2) : Aq.a);
      }
   }

   private static int C(o_ var0, int var1, int var2, int var3) {
      return (var2 << var0.g() | var3) << var0.g() | var1;
   }
}

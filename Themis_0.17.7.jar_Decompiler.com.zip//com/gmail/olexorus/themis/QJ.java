package com.gmail.olexorus.themis;

public class QJ extends lm<QJ> {
   private Bh A;

   public void t() {
      this.A = Bh.k((lm)this);
   }

   public void d() {
      Bh.k(this, this.A);
   }

   public void u(QJ var1) {
      this.A = var1.A;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public final class oT implements BX {
   public static final oT C;
   public static final oT Q;
   public static final oT u;
   public static final oT R;
   public static final oT O;
   public static final oT f;
   public static final oT w;
   public static final oT q;
   public static final oT X;
   public static final oT Y;
   public static final oT i;
   public static final oT F;
   public static final oT T;
   public static final oT z;
   public static final oT N;
   public static final oT g;
   private static final List<oT> m;
   public static final l3<String, oT> x;
   private final String n;
   private final int d;
   private final G3 D;
   private static final long a = kt.a(4071407911009968044L, 4243481929836770440L, MethodHandles.lookup().lookupClass()).a(156327012916606L);

   public static oT j(int var0) {
      switch(var0) {
      case 0:
         return C;
      case 170:
         return Q;
      case 43520:
         return u;
      case 43690:
         return R;
      case 5592405:
         return X;
      case 5592575:
         return Y;
      case 5635925:
         return i;
      case 5636095:
         return F;
      case 11141120:
         return O;
      case 11141290:
         return f;
      case 11184810:
         return q;
      case 16733525:
         return T;
      case 16733695:
         return z;
      case 16755200:
         return w;
      case 16777045:
         return N;
      case 16777215:
         return g;
      default:
         return null;
      }
   }

   public static oT W(BX var0) {
      return var0 instanceof oT ? (oT)var0 : (oT)BX.t(m, var0);
   }

   private oT(String var1, int var2) {
      this.n = var1;
      this.d = var2;
      this.D = G3.c(this.k(), this.v(), this.D());
   }

   public int Y() {
      return this.d;
   }

   public G3 q() {
      return this.D;
   }

   public String toString() {
      return this.n;
   }

   public Stream<? extends rE> T() {
      long var1 = a ^ 133057092765952L;
      return Stream.concat(Stream.of(rE.c("name", this.n)), BX.super.T());
   }

   private static String lambda$static$0(oT var0) {
      return var0.n;
   }

   static {
      long var0 = a ^ 110231410025265L;
      C = new oT("black", 0);
      Q = new oT("dark_blue", 170);
      u = new oT("dark_green", 43520);
      R = new oT("dark_aqua", 43690);
      O = new oT("dark_red", 11141120);
      f = new oT("dark_purple", 11141290);
      w = new oT("gold", 16755200);
      q = new oT("gray", 11184810);
      X = new oT("dark_gray", 5592405);
      Y = new oT("blue", 5592575);
      i = new oT("green", 5635925);
      F = new oT("aqua", 5636095);
      T = new oT("red", 16733525);
      z = new oT("light_purple", 16733695);
      N = new oT("yellow", 16777045);
      g = new oT("white", 16777215);
      m = Collections.unmodifiableList(Arrays.asList(C, Q, u, R, O, f, w, q, X, Y, i, F, T, z, N, g));
      x = l3.v(oT::lambda$static$0, m);
   }
}

package com.gmail.olexorus.themis;

public interface Al<C extends om> extends u1<C> {
}

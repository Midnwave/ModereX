package com.gmail.olexorus.themis;

import java.util.List;

public class mP<T> {
   private final List<CO<T>> D;
   private final bW q;

   public mP(List<CO<T>> var1, bW var2) {
      this.D = var1;
      this.q = var2;
   }

   public static <T> bg<mP<T>> D(tw<T> var0) {
      tw var1 = CO.p(var0).c();
      return new lB(var1);
   }

   static List p(mP var0) {
      return var0.D;
   }

   static bW l(mP var0) {
      return var0.q;
   }
}

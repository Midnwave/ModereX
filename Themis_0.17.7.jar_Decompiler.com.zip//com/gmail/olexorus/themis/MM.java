package com.gmail.olexorus.themis;

import java.security.PublicKey;
import java.time.Instant;

public class MM {
   private final Instant d;
   private final PublicKey s;
   private final byte[] I;

   public MM(Instant var1, PublicKey var2, byte[] var3) {
      this.d = var1;
      this.s = var2;
      this.I = var3;
   }

   public Instant o() {
      return this.d;
   }

   public PublicKey Z() {
      return this.s;
   }

   public byte[] y() {
      return this.I;
   }
}

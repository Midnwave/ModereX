package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class iq extends id implements WQ {
   private CW I;
   private X S;
   private float F;
   private int n;
   private static final long b = kt.a(1164562103060379916L, -8710541398352178973L, MethodHandles.lookup().lookupClass()).a(153015032483813L);

   public iq(CW var1, X var2, float var3, int var4) {
      this((z2)null, var1, var2, var3, var4);
   }

   public iq(z2 var1, CW var2, X var3, float var4, int var5) {
      super(var1);
      this.I = var2;
      this.S = var3;
      this.F = var4;
      this.n = var5;
   }

   public static iq Z(lm<?> var0) {
      return (iq)WQ.T(var0);
   }

   public static void r(lm<?> var0, iq var1) {
      WQ.D(var0, var1);
   }

   public WQ w(z2 var1) {
      return new iq(var1, this.I, this.S, this.F, this.n);
   }

   public CW h() {
      return this.I;
   }

   public void E(CW var1) {
      this.I = var1;
   }

   public X D() {
      return this.S;
   }

   public void Q(X var1) {
      this.S = var1;
   }

   public float P() {
      return this.F;
   }

   public void K(float var1) {
      this.F = var1;
   }

   public int g() {
      return this.n;
   }

   public void r(int var1) {
      this.n = var1;
   }

   public boolean I(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof iq)) {
         return false;
      } else if (!super.equals(var1)) {
         return false;
      } else {
         iq var2 = (iq)var1;
         if (Float.compare(var2.F, this.F) != 0) {
            return false;
         } else if (this.n != var2.n) {
            return false;
         } else {
            return !this.I.equals(var2.I) ? false : this.S.equals(var2.S);
         }
      }
   }

   public int z() {
      return Objects.hash(new Object[]{super.hashCode(), this.I, this.S, this.F, this.n});
   }

   public String toString() {
      long var1 = b ^ 111769855071974L;
      return "JukeboxSong{sound=" + this.I + ", description=" + this.S + ", lengthInSeconds=" + this.F + ", comparatorOutput=" + this.n + '}';
   }
}

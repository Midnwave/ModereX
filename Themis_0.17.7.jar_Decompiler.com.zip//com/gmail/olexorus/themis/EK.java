package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum EK {
   NORMAL,
   COLD,
   WARM;

   private static final l3<String, EK> q;
   private final String R;
   private static final EK[] a;

   private EK(String var3) {
      this.R = var3;
   }

   public static EK v(String var0) {
      return (EK)rN.V(q, var0);
   }

   public String Q() {
      return this.R;
   }

   private static EK[] I() {
      return new EK[]{NORMAL, COLD, WARM};
   }

   static {
      long var0 = kt.a(1487637747700811471L, 7677025720360195755L, MethodHandles.lookup().lookupClass()).a(226239037292338L) ^ 74924090333838L;
      NORMAL = new EK("NORMAL", 0, "normal");
      COLD = new EK("COLD", 1, "cold");
      WARM = new EK("WARM", 2, "warm");
      a = I();
      q = l3.Q(EK.class, EK::Q);
   }
}

package com.gmail.olexorus.themis;

public class il extends id implements On {
   public il(z2 var1) {
      super(var1);
   }
}

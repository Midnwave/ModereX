package com.gmail.olexorus.themis;

import com.gmail.olexorus.themis.api.CheckType;
import java.lang.invoke.MethodHandles;
import java.util.EnumMap;

final class nM extends n9 implements EP<EnumMap<CheckType, oG>> {
   public static final nM m = new nM();
   private static final long a = kt.a(-2353781728956975858L, -3952428982607508888L, MethodHandles.lookup().lookupClass()).a(170416178000050L);

   nM() {
      super(0);
   }

   public final EnumMap O(Object[] param1) {
      // $FF: Couldn't be decompiled
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}

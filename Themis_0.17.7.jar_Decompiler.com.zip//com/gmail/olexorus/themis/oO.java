package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class oO extends oh implements wG {
   private VO c;
   private static final long a = kt.a(-6762382551494400057L, 7648069106218626118L, MethodHandles.lookup().lookupClass()).a(83611562499594L);

   public oO(VO var1) {
      this.c = var1;
   }

   public VO y() {
      return this.c;
   }

   public static oO N(lm<?> var0) {
      int var1;
      if (var0.R().i(zZ.V_1_9)) {
         var1 = var0.Q();
      } else if (var0.R().i(zZ.V_1_13)) {
         var1 = var0.f();
      } else {
         var1 = var0.Q();
      }

      return new oO(VO.r(var0.R().u(), var1));
   }

   public static void Y(lm<?> var0, oO var1) {
      if (var0.R().i(zZ.V_1_9)) {
         var0.E(var1.y().e());
      } else {
         var0.L(var1.y().e());
      }

   }

   public static oO p(RT var0, vL var1) {
      long var2 = a ^ 47271474888217L;
      String var4 = var1.K(vL.V_1_20_5) ? "block_state" : "value";
      VO var5 = VO.I(var0.W(var4), var1);
      return new oO(var5);
   }

   public static void k(oO var0, vL var1, RT var2) {
      long var3 = a ^ 43662886225635L;
      String var5 = var1.K(vL.V_1_20_5) ? "block_state" : "value";
      var2.j(var5, VO.w(var0.c, var1));
   }

   public boolean p() {
      return false;
   }

   public oA D(vL var1) {
      return oA.h(this.c.e());
   }
}

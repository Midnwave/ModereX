package com.gmail.olexorus.themis;

import java.util.UUID;

public class ZK extends lm<ZK> {
   private UUID v;

   public void t() {
      this.v = (UUID)this.u(lm::V);
   }

   public void d() {
      this.l(this.v, lm::y);
   }

   public void V(ZK var1) {
      this.v = var1.v;
   }
}

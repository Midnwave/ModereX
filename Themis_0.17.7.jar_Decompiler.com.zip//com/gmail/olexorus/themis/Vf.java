package com.gmail.olexorus.themis;

import java.util.Optional;

public interface Vf extends GL, go {
   boolean A(Vf var1);

   Optional<Vf> b();
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class n6 {
   private static final N8<O8> z;
   public static final O8 U;
   public static final O8 N;
   public static final O8 w;

   public static O8 h(String var0) {
      return (O8)z.h(var0, ib::new);
   }

   public static N8<O8> L() {
      return z;
   }

   static {
      long var0 = kt.a(8126468472443449252L, 640475174426804907L, MethodHandles.lookup().lookupClass()).a(129215591719835L) ^ 136692878004102L;
      z = new N8("salmon_variant");
      U = h("small");
      N = h("medium");
      w = h("large");
      z.f();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

final class AL implements Rv {
   private final String U;
   private final UUID E;
   private final List<mx> I;
   private final boolean z;
   private final v1 R;
   private static final long c = kt.a(242618042404800106L, -7694558715476386335L, MethodHandles.lookup().lookupClass()).a(185231950217763L);

   AL(String var1, UUID var2, List<mx> var3, boolean var4, v1 var5) {
      long var6 = c ^ 1976178342538L;
      super();
      this.U = var1;
      this.E = var2;
      if (var3.isEmpty()) {
         this.I = Collections.emptyList();
      } else {
         this.I = Collections.unmodifiableList(new ArrayList((Collection)Objects.requireNonNull(var3, "properties")));
      }

      this.z = var4;
      this.R = var5;
   }

   public String j() {
      return this.U;
   }

   public UUID Y() {
      return this.E;
   }

   public List<mx> d() {
      return this.I;
   }

   public boolean p() {
      return this.z;
   }

   public v1 K() {
      return this.R;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof Rv)) {
         return false;
      } else {
         AL var2 = (AL)var1;
         return Objects.equals(this.U, var2.U) && Objects.equals(this.E, var2.E) && Objects.equals(this.I, var2.I) && this.z == var2.z && Objects.equals(this.R, var2.R);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.U, this.E, this.I, this.z, this.R});
   }

   public String toString() {
      return cH.M(this);
   }
}

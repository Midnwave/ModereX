package com.gmail.olexorus.themis;

class R4 {
   private String R;
   private boolean O;
   private double l;

   public R4(String var1, boolean var2) {
      this.R = var1;
      this.O = var2;
   }

   public String t() {
      return this.R;
   }

   public double n() {
      return this.l;
   }

   public R4 W() {
      this.l = 1.0D;
      if (this.O) {
         switch(this.R.charAt(this.R.length() - 1)) {
         case 'K':
         case 'k':
            this.l = 1000.0D;
            this.R = this.R.substring(0, this.R.length() - 1);
            break;
         case 'M':
         case 'm':
            this.l = 1000000.0D;
            this.R = this.R.substring(0, this.R.length() - 1);
         }
      }

      return this;
   }
}

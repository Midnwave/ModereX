package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class R3 {
   private static final N8<VI<?>> qN;
   public static final tw<VI<?>> FT;
   public static final VI<oh> qw;
   public static final VI<oh> qa;
   public static final VI<oO> y;
   public static final VI<oh> qj;
   public static final VI<oh> q;
   public static final VI<oO> qX;
   public static final VI<oh> Fh;
   public static final VI<oh> qC;
   public static final VI<oh> qP;
   public static final VI<oh> m;
   public static final VI<oZ> Z;
   public static final VI<oh> f;
   public static final VI<oh> qQ;
   public static final VI<oh> qW;
   public static final VI<oh> qb;
   public static final VI<oh> Q;
   public static final VI<oQ> q7;
   public static final VI<oz> r;
   public static final VI<oL> Fr;
   public static final VI<oh> q_;
   public static final VI<oh> qd;
   public static final VI<oh> FI;
   public static final VI<oh> X;
   public static final VI<o6> F;
   public static final VI<oh> FQ;
   public static final VI<oh> ql;
   public static final VI<oh> G;
   public static final VI<oO> a;
   public static final VI<oh> qe;
   public static final VI<oh> qy;
   public static final VI<oh> qx;
   public static final VI<oh> J;
   public static final VI<oC> I;
   public static final VI<oh> d;
   public static final VI<oh> qn;
   public static final VI<oh> b;
   public static final VI<o6> L;
   public static final VI<oh> q0;
   public static final VI<oh> E;
   public static final VI<oh> FR;
   public static final VI<oL> N;
   public static final VI<oa> q6;
   public static final VI<oJ> j;
   public static final VI<oh> q5;
   public static final VI<oh> z;
   public static final VI<oh> q2;
   public static final VI<oh> qf;
   public static final VI<oh> q9;
   public static final VI<oh> qU;
   public static final VI<oh> A;
   public static final VI<oh> V;
   public static final VI<oh> x;
   public static final VI<oh> qK;
   public static final VI<oh> qB;
   public static final VI<oh> o;
   public static final VI<oh> qg;
   public static final VI<oh> q3;
   public static final VI<oh> qG;
   public static final VI<oh> t;
   public static final VI<oh> qi;
   public static final VI<oh> qT;
   public static final VI<oh> c;
   public static final VI<oh> U;
   public static final VI<oh> qE;
   public static final VI<oh> qL;
   public static final VI<oh> qr;
   public static final VI<oh> qD;
   public static final VI<oh> qZ;
   public static final VI<oh> qH;
   public static final VI<oh> qv;
   public static final VI<oh> s;
   public static final VI<oh> g;
   public static final VI<oh> C;
   public static final VI<oh> qs;
   public static final VI<oh> qJ;
   public static final VI<oh> qm;
   public static final VI<oh> qF;
   public static final VI<oh> l;
   public static final VI<oh> qz;
   public static final VI<oh> qM;
   public static final VI<oh> q1;
   public static final VI<oh> qt;
   public static final VI<oh> F7;
   public static final VI<oh> S;
   public static final VI<oh> qc;
   public static final VI<oh> T;
   public static final VI<oh> v;
   public static final VI<oh> w;
   public static final VI<oh> P;
   public static final VI<oh> K;
   public static final VI<oh> qu;
   public static final VI<oh> Fs;
   public static final VI<oh> Fn;
   public static final VI<oh> h;
   public static final VI<oD> k;
   public static final VI<oh> D;
   public static final VI<oh> u;
   public static final VI<oh> e;
   public static final VI<oh> qq;
   public static final VI<oh> qO;
   public static final VI<oh> qo;
   public static final VI<oh> n;
   public static final VI<oh> R;
   public static final VI<oh> Fo;
   public static final VI<oh> M;
   public static final VI<oh> q4;
   public static final VI<oh> qk;
   public static final VI<oh> qY;
   public static final VI<oh> qV;
   public static final VI<oh> B;
   public static final VI<oh> Y;
   public static final VI<oh> O;
   public static final VI<oh> W;
   public static final VI<oO> qI;
   public static final VI<oh> qA;
   public static final VI<oh> i;
   public static final VI<oh> qh;
   public static final VI<od> q8;
   public static final VI<oO> qR;
   public static final VI<oh> H;
   public static final VI<o6> qp;
   public static final VI<oh> p;
   public static final VI<oh> qS;

   public static VI<oh> M(String var0) {
      return K(var0, R3::lambda$define$0, (Gw)null, R3::lambda$define$1, (td)null);
   }

   public static <T extends oh> VI<T> K(String var0, MO<T> var1, Gw<T> var2, M4<T> var3, td<T> var4) {
      return (VI)qN.h(var0, R3::lambda$define$2);
   }

   public static VI<?> W(String var0) {
      return (VI)qN.R(var0);
   }

   public static VI<?> k(vL var0, int var1) {
      return (VI)qN.e(var0, var1);
   }

   private static void lambda$static$6(o6 var0, vL var1, RT var2) {
      if (var1.K(vL.V_1_21_9)) {
         o6.H(var0, var1, var2);
      }

   }

   private static o6 lambda$static$5(RT var0, vL var1) {
      return var1.K(vL.V_1_21_9) ? o6.K(var0, var1) : new o6(0);
   }

   private static void lambda$static$4(lm var0, o6 var1) {
      if (var0.R().i(zZ.V_1_21_9)) {
         o6.Q(var0, var1);
      }

   }

   private static o6 lambda$static$3(lm var0) {
      return var0.R().i(zZ.V_1_21_9) ? o6.O(var0) : new o6(0);
   }

   private static ct lambda$define$2(MO var0, Gw var1, M4 var2, td var3, z2 var4) {
      return new ct(var4, var0, var1, var2, var3);
   }

   private static oh lambda$define$1(RT var0, vL var1) {
      return oh.z();
   }

   private static oh lambda$define$0(lm var0) {
      return oh.z();
   }

   static {
      long var0 = kt.a(5044680289028169292L, -9155499359303629171L, MethodHandles.lookup().lookupClass()).a(275365371530441L) ^ 79527096821390L;
      qN = new N8("particle_type");
      FT = g9.w(qN);
      qw = M("ambient_entity_effect");
      qa = M("angry_villager");
      y = K("block", oO::N, oO::Y, oO::p, oO::k);
      qj = M("barrier");
      q = M("light");
      qX = K("block_marker", oO::N, oO::Y, oO::p, oO::k);
      Fh = M("bubble");
      qC = M("cloud");
      qP = M("crit");
      m = M("damage_indicator");
      Z = K("dragon_breath", oZ::t, oZ::v, oZ::z, oZ::T);
      f = M("dripping_lava");
      qQ = M("falling_lava");
      qW = M("landing_lava");
      qb = M("dripping_water");
      Q = M("falling_water");
      q7 = K("dust", oQ::l, oQ::p, oQ::S, oQ::e);
      r = K("dust_color_transition", oz::K, oz::I, oz::M, oz::G);
      Fr = K("effect", oL::w, oL::k, oL::d, oL::o);
      q_ = M("elder_guardian");
      qd = M("enchanted_hit");
      FI = M("enchant");
      X = M("end_rod");
      F = K("entity_effect", o6::O, o6::Q, o6::K, o6::H);
      FQ = M("explosion_emitter");
      ql = M("explosion");
      G = M("sonic_boom");
      a = K("falling_dust", oO::N, oO::Y, oO::p, oO::k);
      qe = M("firework");
      qy = M("fishing");
      qx = M("flame");
      J = M("sculk_soul");
      I = K("sculk_charge", oC::Q, oC::b, oC::y, oC::m);
      d = M("sculk_charge_pop");
      qn = M("soul_fire_flame");
      b = M("soul");
      L = K("flash", R3::lambda$static$3, R3::lambda$static$4, R3::lambda$static$5, R3::lambda$static$6);
      q0 = M("happy_villager");
      E = M("composter");
      FR = M("heart");
      N = K("instant_effect", oL::w, oL::k, oL::d, oL::o);
      q6 = K("item", oa::Y, oa::K, oa::K, oa::F);
      j = K("vibration", oJ::d, oJ::i, oJ::o, oJ::u);
      q5 = M("item_slime");
      z = M("item_snowball");
      q2 = M("large_smoke");
      qf = M("lava");
      q9 = M("mycelium");
      qU = M("note");
      A = M("poof");
      V = M("portal");
      x = M("rain");
      qK = M("smoke");
      qB = M("sneeze");
      o = M("spit");
      qg = M("squid_ink");
      q3 = M("sweep_attack");
      qG = M("totem_of_undying");
      t = M("underwater");
      qi = M("splash");
      qT = M("witch");
      c = M("bubble_pop");
      U = M("current_down");
      qE = M("bubble_column_up");
      qL = M("nautilus");
      qr = M("dolphin");
      qD = M("campfire_cosy_smoke");
      qZ = M("campfire_signal_smoke");
      qH = M("dripping_honey");
      qv = M("falling_honey");
      s = M("landing_honey");
      g = M("falling_nectar");
      C = M("falling_spore_blossom");
      qs = M("ash");
      qJ = M("crimson_spore");
      qm = M("warped_spore");
      qF = M("spore_blossom_air");
      l = M("dripping_obsidian_tear");
      qz = M("falling_obsidian_tear");
      qM = M("landing_obsidian_tear");
      q1 = M("reverse_portal");
      qt = M("white_ash");
      F7 = M("small_flame");
      S = M("snowflake");
      qc = M("dripping_dripstone_lava");
      T = M("falling_dripstone_lava");
      v = M("dripping_dripstone_water");
      w = M("falling_dripstone_water");
      P = M("glow_squid_ink");
      K = M("glow");
      qu = M("wax_on");
      Fs = M("wax_off");
      Fn = M("electric_spark");
      h = M("scrape");
      k = K("shriek", oD::y, oD::W, oD::i, oD::A);
      D = M("dripping_cherry_leaves");
      u = M("falling_cherry_leaves");
      e = M("landing_cherry_leaves");
      qq = M("cherry_leaves");
      qO = M("egg_crack");
      qo = M("gust");
      n = M("gust_emitter");
      R = M("white_smoke");
      Fo = M("dust_plume");
      M = M("gust_dust");
      q4 = M("trial_spawner_detection");
      qk = M("small_gust");
      qY = M("gust_emitter_large");
      qV = M("gust_emitter_small");
      B = M("infested");
      Y = M("item_cobweb");
      O = M("trial_spawner_detection_ominous");
      W = M("vault_connection");
      qI = K("dust_pillar", oO::N, oO::Y, oO::p, oO::k);
      qA = M("ominous_spawning");
      i = M("raid_omen");
      qh = M("trial_omen");
      q8 = K("trail", od::K, od::Q, od::j, od::N);
      qR = K("block_crumble", oO::N, oO::Y, oO::p, oO::k);
      H = M("pale_oak_leaves");
      qp = K("tinted_leaves", o6::O, o6::Q, o6::K, o6::H);
      p = M("firefly");
      qS = M("copper_fire_flame");
      qN.f();
   }
}

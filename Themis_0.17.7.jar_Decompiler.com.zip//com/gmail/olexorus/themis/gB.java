package com.gmail.olexorus.themis;

public interface gB {
   <V> gB v(Va<V> var1, V var2);

   gB E(C var1);

   C A();
}

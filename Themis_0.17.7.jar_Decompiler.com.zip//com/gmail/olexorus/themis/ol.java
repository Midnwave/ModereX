package com.gmail.olexorus.themis;

import java.util.Objects;

public class ol implements t8 {
   private String A;
   private String d;

   public ol(String var1, String var2) {
      this.A = var1;
      this.d = var2;
   }

   public static ol Y(lm<?> var0) {
      String var1 = (String)var0.u(lm::A);
      String var2 = (String)var0.u(lm::A);
      return new ol(var1, var2);
   }

   public static void D(lm<?> var0, ol var1) {
      var0.l(var1.A, lm::I);
      var0.l(var1.d, lm::I);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof ol)) {
         return false;
      } else {
         ol var2 = (ol)var1;
         return !Objects.equals(this.A, var2.A) ? false : Objects.equals(this.d, var2.d);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.A, this.d});
   }
}

package com.gmail.olexorus.themis;

import java.util.Objects;

public class ug {
   private EZ s;

   public ug(EZ var1) {
      this.s = var1;
   }

   public static ug r(lm<?> var0) {
      EZ var1 = EZ.b(var0);
      return new ug(var1);
   }

   public static void s(lm<?> var0, ug var1) {
      EZ.M(var0, var1.s);
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof ug)) {
         return false;
      } else {
         ug var2 = (ug)var1;
         return this.s.equals(var2.s);
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.s);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class o6 extends oh {
   private vc i;
   private static final long a = kt.a(-6650867212340522679L, -7217132819783306718L, MethodHandles.lookup().lookupClass()).a(124340896074651L);

   public o6(int var1) {
      this(new vc(var1));
   }

   public o6(vc var1) {
      this.i = var1;
   }

   public static o6 O(lm<?> var0) {
      int var1 = var0.R().i(zZ.V_1_20_5) ? var0.f() : 0;
      return new o6(var1);
   }

   public static void Q(lm<?> var0, o6 var1) {
      if (var0.R().i(zZ.V_1_20_5)) {
         var0.L(var1.i.V());
      }

   }

   public static o6 K(RT var0, vL var1) {
      long var2 = a ^ 117186125963484L;
      vc var4;
      if (var1.K(vL.V_1_20_5)) {
         Rc var5 = var0.W("color");
         var4 = vc.p(var5, var1);
      } else {
         var4 = vc.J;
      }

      return new o6(var4);
   }

   public static void H(o6 var0, vL var1, RT var2) {
      long var3 = a ^ 56078304929628L;
      if (var1.K(vL.V_1_20_5)) {
         var2.j("color", vc.y(var0.i, var1));
      }

   }

   public boolean p() {
      return false;
   }
}

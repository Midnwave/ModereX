package com.gmail.olexorus.themis;

class nS implements tw<T> {
   final bg X;

   nS(bg var1) {
      this.X = var1;
   }

   public T n(Rc var1, lm<?> var2) {
      RT var3 = (RT)var1.s(RT.class);
      return this.X.U(var3, var2);
   }

   public Rc j(lm<?> var1, T var2) {
      RT var3 = new RT();
      this.X.r(var3, var1, var2);
      return var3;
   }
}

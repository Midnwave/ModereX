package com.gmail.olexorus.themis;

public interface Mw extends lV<vc> {
   default tw<vc> F(Jf<v2> var1) {
      return g9.r;
   }
}

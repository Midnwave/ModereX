package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.stream.Stream;

final class Bc extends BG implements bh {
   private final int g;
   private static final long a = kt.a(-7011198897341903448L, 8939524916819721220L, MethodHandles.lookup().lookupClass()).a(110849377257550L);

   Bc(int var1) {
      this.g = var1;
   }

   public int t() {
      return this.g;
   }

   public byte l() {
      return (byte)(this.g & 255);
   }

   public int p() {
      return this.g;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         Bc var2 = (Bc)var1;
         return this.g == var2.g;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Integer.hashCode(this.g);
   }

   public Stream<? extends rE> T() {
      long var1 = a ^ 70677377980573L;
      return Stream.of(rE.N("value", this.g));
   }
}

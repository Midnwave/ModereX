package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import java.util.Objects;
import java.util.SortedMap;

final class iW implements ML {
   private final Tr B;
   private final SortedMap<Integer, C> m;
   private final int k;
   private final C E;
   private static final long a = kt.a(5856388165794017005L, 8767285585850645192L, MethodHandles.lookup().lookupClass()).a(184637632361589L);

   iW(Tr var1, SortedMap<Integer, C> var2, int var3, C var4) {
      this.B = var1;
      this.m = var2;
      this.k = var3;
      this.E = var4;
   }

   public <V> V x(Va<V> var1) {
      return this.E.x(var1);
   }

   public ML n(int var1) {
      return new iW(this.B, this.m, var1, i(this.B, this.m, var1));
   }

   public static C i(Tr var0, SortedMap<Integer, C> var1, int var2) {
      SortedMap var3 = var1.headMap(var2 + 1);
      gB var4 = var0.y();
      Iterator var5 = var3.values().iterator();

      while(var5.hasNext()) {
         C var6 = (C)var5.next();
         var4.E(var6);
      }

      return var4.A();
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         iW var2 = (iW)var1;
         return this.k == var2.k && Objects.equals(this.B, var2.B) && Objects.equals(this.m, var2.m) && Objects.equals(this.E, var2.E);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.B, this.m, this.k, this.E});
   }

   public String toString() {
      long var1 = a ^ 73862931175845L;
      return this.getClass().getSimpleName() + "{schema=" + this.B + ", sets=" + this.m + ", targetVersion=" + this.k + ", filtered=" + this.E + '}';
   }

   static C b(iW var0) {
      return var0.E;
   }
}

package com.gmail.olexorus.themis;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

public class wa extends w6 {
   int N;
   byte[] P;
   String G;
   Instant z;
   long j;
   oX o;
   X l;
   Tx C;
   r0 s;

   public wa(UUID var1, int var2, byte[] var3, String var4, Instant var5, long var6, oX var8, X var9, Tx var10, r0 var11) {
      super(X.N(var4), var11.x(), var1);
      this.N = var2;
      this.P = var3;
      this.G = var4;
      this.z = var5;
      this.j = var6;
      this.o = var8;
      this.l = var9;
      this.C = var10;
      this.s = var11;
   }

   public int X() {
      return this.N;
   }

   public byte[] k() {
      return this.P;
   }

   public X b() {
      return X.N(this.G);
   }

   public String H() {
      return this.G;
   }

   public Instant X() {
      return this.z;
   }

   public long j() {
      return this.j;
   }

   public oX s() {
      return this.o;
   }

   public Optional<X> f() {
      return Optional.ofNullable(this.l);
   }

   public Tx O() {
      return this.C;
   }

   public r0 T() {
      return this.s;
   }
}

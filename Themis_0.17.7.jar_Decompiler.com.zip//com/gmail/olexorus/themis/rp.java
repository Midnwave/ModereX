package com.gmail.olexorus.themis;

public interface rp {
   boolean I(Object var1);

   int z();
}

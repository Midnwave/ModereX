package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.stream.Stream;

final class bX implements Vd, nc {
   static final bX V = new bX(0);
   private final int C;
   private static final long a = kt.a(-2200335095121102449L, 6881213914333339744L, MethodHandles.lookup().lookupClass()).a(71353223527136L);

   bX(int var1) {
      this.C = var1;
   }

   public int E() {
      return this.C;
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof bX)) {
         return false;
      } else {
         bX var2 = (bX)var1;
         return this.C == var2.C;
      }
   }

   public int hashCode() {
      return Integer.hashCode(this.C);
   }

   public String toString() {
      return cH.M(this);
   }

   public Stream<? extends rE> T() {
      long var1 = a ^ 15115380323401L;
      return Stream.of(rE.N("value", this.C));
   }
}

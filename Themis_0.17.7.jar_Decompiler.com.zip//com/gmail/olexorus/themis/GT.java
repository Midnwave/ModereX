package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class GT implements Bi {
   private final X I;
   private final boolean m;
   private final String n;
   private final String p;
   private static final long a = kt.a(6916976845158670597L, 2729723680852068004L, MethodHandles.lookup().lookupClass()).a(29044919180588L);

   public GT(X var1, boolean var2, String var3, String var4) {
      this.I = var1;
      this.m = var2;
      this.n = var3;
      this.p = var4;
   }

   public static GT n(RT var0, lm<?> var1) {
      long var2 = a ^ 131150318773125L;
      X var4 = (X)var0.g("label", h.z(var1), var1);
      boolean var5 = var0.w("initial");
      String var6 = var0.g("on_true", "true");
      String var7 = var0.g("on_false", "false");
      return new GT(var4, var5, var6, var7);
   }

   public static void g(RT var0, lm<?> var1, GT var2) {
      long var3 = a ^ 40454284152312L;
      var0.X("label", var2.I, h.z(var1), var1);
      if (var2.m) {
         var0.j("initial", new mA(true));
      }

      if (!"true".equals(var2.n)) {
         var0.j("on_true", new mZ(var2.n));
      }

      if (!"false".equals(var2.p)) {
         var0.j("on_false", new mZ(var2.p));
      }

   }

   public wE<?> Q() {
      return E6.V;
   }
}

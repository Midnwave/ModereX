package com.gmail.olexorus.themis;

public final class ze {
   private final double W;
   private final long e;
   private static int p;

   public ze(double var1, long var3) {
      this.W = var1;
      this.e = var3;
   }

   public final double D(Object[] var1) {
      return this.W;
   }

   public final long l(Object[] var1) {
      return this.e;
   }

   public static void F(int var0) {
      p = var0;
   }

   public static int q() {
      return p;
   }

   public static int l() {
      int var0 = q();

      try {
         return var0 == 0 ? 120 : 0;
      } catch (RuntimeException var1) {
         throw a(var1);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   static {
      if (l() == 0) {
         F(64);
      }

   }
}

package com.gmail.olexorus.themis;

public class Ep {
   private int X;
   private uZ s;

   public Ep(int var1, uZ var2) {
      this.X = var1;
      this.s = var2;
   }

   public int c() {
      return this.X;
   }

   public uZ T() {
      return this.s;
   }
}

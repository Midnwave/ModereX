package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class Gb {
   private MI Z;
   private vS k;
   private tr G;
   private wU V;
   private static final long a = kt.a(373193453962458433L, 738303401197877065L, MethodHandles.lookup().lookupClass()).a(262168065090036L);

   public Gb(MI var1, vS var2, tr var3, wU var4) {
      this.Z = var1;
      this.k = var2;
      this.G = var3;
      this.V = var4;
   }

   public static Gb t(lm<?> var0) {
      MI var1 = (MI)var0.e(NE::L);
      vS var2 = vS.r(var0);
      tr var3 = (tr)var0.w((Enum[])tr.values());
      Object var4 = var0.R().i(zZ.V_1_21_6) ? wU.I(var0) : Ew.T;
      return new Gb(var1, var2, var3, (wU)var4);
   }

   public static void X(lm<?> var0, Gb var1) {
      var0.j((GL)var1.Z);
      vS.s(var0, var1.k);
      var0.o((Enum)var1.G);
      if (var0.R().i(zZ.V_1_21_6)) {
         wU.Q(var0, var1.V);
      }

   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof Gb)) {
         return false;
      } else {
         Gb var2 = (Gb)var1;
         if (!this.Z.equals(var2.Z)) {
            return false;
         } else if (!this.k.equals(var2.k)) {
            return false;
         } else {
            return this.G == var2.G;
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.Z, this.k, this.G});
   }

   public String toString() {
      long var1 = a ^ 99739285574309L;
      return "ModifierEntry{attribute=" + this.Z + ", modifier=" + this.k + ", slotGroup=" + this.G + '}';
   }
}

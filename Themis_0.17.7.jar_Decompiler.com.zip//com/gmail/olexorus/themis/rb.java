package com.gmail.olexorus.themis;

class rb extends rE {
   final String c;
   final byte[] p;

   rb(String var1, byte[] var2) {
      super((rM)null);
      this.c = var1;
      this.p = var2;
   }

   public String X() {
      return this.c;
   }
}

package com.gmail.olexorus.themis;

public class OW {
   private i u;
   private int j;
   private o9 F;

   public OW(i var1, int var2) {
      this(var1, var2, o9.Z());
   }

   public OW(i var1, int var2, o9 var3) {
      this.u = var1;
      this.j = var2;
      this.F = var3;
   }

   public static OW u(TU var0) {
      if (var0 == null) {
         return null;
      } else if (var0.h()) {
         return H();
      } else {
         o9 var1 = o9.c(var0.B());
         return new OW(var0.v(), var0.o(), var1);
      }
   }

   public static TU b(lm<?> var0) {
      return var0.R().m(zZ.V_1_20_5) ? var0.u() : g(var0).W();
   }

   public static OW g(lm<?> var0) {
      i var1 = (i)var0.e(z1::Z);
      int var2 = var0.Q();
      o9 var3 = o9.l(var0);
      return new OW(var1, var2, var3);
   }

   public static void O(lm<?> var0, TU var1) {
      if (var0.R().m(zZ.V_1_20_5)) {
         var0.m(var1);
      } else {
         t(var0, u(var1));
      }

   }

   public static void t(lm<?> var0, OW var1) {
      var0.j((GL)var1.u);
      var0.E(var1.j);
      o9.d(var0, var1.F);
   }

   public static OW H() {
      return new OW(z1.B6, 0);
   }

   public TU W() {
      return TU.g().s(this.u).A(this.j).B(this.F.I(this.u.b())).a();
   }
}

package com.gmail.olexorus.themis;

public interface Oz<T> {
   T n(Rc var1, lm<?> var2);
}

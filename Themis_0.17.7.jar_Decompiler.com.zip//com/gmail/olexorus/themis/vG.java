package com.gmail.olexorus.themis;

// $FF: synthetic class
class vG {
   static final int[] A = new int[uy.values().length];

   static {
      try {
         A[uy.HANDSHAKING.ordinal()] = 1;
      } catch (NoSuchFieldError var5) {
      }

      try {
         A[uy.STATUS.ordinal()] = 2;
      } catch (NoSuchFieldError var4) {
      }

      try {
         A[uy.LOGIN.ordinal()] = 3;
      } catch (NoSuchFieldError var3) {
      }

      try {
         A[uy.PLAY.ordinal()] = 4;
      } catch (NoSuchFieldError var2) {
      }

      try {
         A[uy.CONFIGURATION.ordinal()] = 5;
      } catch (NoSuchFieldError var1) {
      }

   }
}

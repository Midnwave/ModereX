package com.gmail.olexorus.themis;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

public interface a5<K, V> extends Map<K, V> {
   Map<K, V> c(boolean var1);

   default int size() {
      return this.c(true).size();
   }

   default boolean isEmpty() {
      return this.c(true).isEmpty();
   }

   default boolean containsKey(Object var1) {
      return this.c(true).containsKey(var1);
   }

   default boolean containsValue(Object var1) {
      return this.c(true).containsValue(var1);
   }

   default V get(Object var1) {
      return this.c(true).get(var1);
   }

   default V put(K var1, V var2) {
      return this.c(false).put(var1, var2);
   }

   default V remove(Object var1) {
      return this.c(false).remove(var1);
   }

   default void putAll(Map<? extends K, ? extends V> var1) {
      this.c(false).putAll(var1);
   }

   default void clear() {
      this.c(false).clear();
   }

   default Set<K> keySet() {
      return this.c(false).keySet();
   }

   default Collection<V> values() {
      return this.c(false).values();
   }

   default Set<Entry<K, V>> entrySet() {
      return this.c(false).entrySet();
   }

   default V getOrDefault(Object var1, V var2) {
      return this.c(true).getOrDefault(var1, var2);
   }

   default void forEach(BiConsumer<? super K, ? super V> var1) {
      this.c(true).forEach(var1);
   }

   default void replaceAll(BiFunction<? super K, ? super V, ? extends V> var1) {
      this.c(false).replaceAll(var1);
   }

   default V putIfAbsent(K var1, V var2) {
      return this.c(false).putIfAbsent(var1, var2);
   }

   default boolean remove(Object var1, Object var2) {
      return this.c(false).remove(var1, var2);
   }

   default boolean replace(K var1, V var2, V var3) {
      return this.c(false).replace(var1, var2, var3);
   }

   default V replace(K var1, V var2) {
      return this.c(false).replace(var1, var2);
   }

   default V computeIfAbsent(K var1, Function<? super K, ? extends V> var2) {
      return this.c(false).computeIfAbsent(var1, var2);
   }

   default V computeIfPresent(K var1, BiFunction<? super K, ? super V, ? extends V> var2) {
      return this.c(false).computeIfPresent(var1, var2);
   }

   default V compute(K var1, BiFunction<? super K, ? super V, ? extends V> var2) {
      return this.c(false).compute(var1, var2);
   }

   default V merge(K var1, V var2, BiFunction<? super V, ? super V, ? extends V> var3) {
      return this.c(false).merge(var1, var2, var3);
   }
}

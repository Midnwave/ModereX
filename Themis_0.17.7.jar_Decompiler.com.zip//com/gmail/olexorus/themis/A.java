package com.gmail.olexorus.themis;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

final class A implements MA {
   private static final Optional<rC> n = Je.d(rC.class);
   static final Consumer<EI> K;
   private final Gson l;
   private final UnaryOperator<GsonBuilder> s;
   private final ab g;
   private final VT Q;
   private final C i;

   A(C var1, ab var2, VT var3) {
      this.i = var1;
      this.g = var2;
      this.Q = var3;
      this.s = A::lambda$new$2;
      this.l = ((GsonBuilder)this.s.apply((new GsonBuilder()).disableHtmlEscaping())).create();
   }

   public Gson e() {
      return this.l;
   }

   public X v(String var1) {
      X var2 = (X)this.e().fromJson(var1, X.class);
      if (var2 == null) {
         throw Gx.Y(var1);
      } else {
         return var2;
      }
   }

   public X Z(String var1, X var2) {
      if (var1 == null) {
         return var2;
      } else {
         X var3 = (X)this.e().fromJson(var1, X.class);
         return var3 == null ? var2 : var3;
      }
   }

   public String H(X var1) {
      return this.e().toJson(var1);
   }

   private static GsonBuilder lambda$new$2(C var0, ab var1, VT var2, GsonBuilder var3) {
      var3.registerTypeAdapterFactory(new zK(var0, var1, var2));
      return var3;
   }

   private static Consumer lambda$static$1() {
      return A::lambda$static$0;
   }

   private static void lambda$static$0(EI var0) {
   }

   static {
      K = (Consumer)n.map(rC::E).orElseGet(A::lambda$static$1);
   }
}

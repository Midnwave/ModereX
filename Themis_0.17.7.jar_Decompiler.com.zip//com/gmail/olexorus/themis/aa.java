package com.gmail.olexorus.themis;

public class aa extends lm<aa> {
   private double N;
   private double T;

   public void t() {
      this.N = this.o();
      this.T = this.o();
   }

   public void d() {
      this.v(this.N);
      this.v(this.T);
   }

   public void F(aa var1) {
      this.N = var1.N;
      this.T = var1.T;
   }
}

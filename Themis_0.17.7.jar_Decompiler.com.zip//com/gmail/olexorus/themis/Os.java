package com.gmail.olexorus.themis;

public interface Os<T> {
   void n(T var1, String var2);
}

package com.gmail.olexorus.themis;

public interface bW extends GL {
   tw<bW> i = g9.Z(g9.w(tp.w()), cL.g).K(E_::t, bW::lambda$static$0);

   float k(float var1);

   private static E_ lambda$static$0(bW var0) {
      return var0 instanceof cL ? E_.Y((cL)var0) : E_.u(var0);
   }
}

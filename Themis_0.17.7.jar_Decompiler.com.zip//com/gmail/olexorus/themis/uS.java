package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum uS {
   EMPTY,
   VEC3I,
   CHUNK,
   AZIMUTH;

   private final MO<ac> V;
   private final Gw<ac> y;
   private static final uS[] N;

   private uS(MO<ac> var3, Gw<ac> var4) {
      this.V = var3;
      this.y = var4;
   }

   public ac B(lm<?> var1) {
      return (ac)this.V.apply(var1);
   }

   public void R(lm<?> var1, ac var2) {
      this.y.accept(var1, var2);
   }

   private static uS[] Z() {
      return new uS[]{EMPTY, VEC3I, CHUNK, AZIMUTH};
   }

   static {
      long var0 = kt.a(3458778052733454468L, -212674699260537941L, MethodHandles.lookup().lookupClass()).a(123575706279694L) ^ 12695862587739L;
      EMPTY = new uS("EMPTY", 0, gp::g, gp::v);
      VEC3I = new uS("VEC3I", 1, g2::E, g2::s);
      CHUNK = new uS("CHUNK", 2, Ch::k, Ch::y);
      AZIMUTH = new uS("AZIMUTH", 3, rm::N, rm::u);
      N = Z();
   }
}

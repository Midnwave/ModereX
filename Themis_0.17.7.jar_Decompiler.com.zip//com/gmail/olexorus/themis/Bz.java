package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Bz {
   public static final Bz g = new Bz(Collections.emptyList());
   private List<X> R;
   private static final long a = kt.a(-2619307147464170172L, -44972638571781240L, MethodHandles.lookup().lookupClass()).a(115320667706014L);

   public Bz(List<X> var1) {
      this.R = var1;
   }

   public static Bz r(lm<?> var0) {
      List var1 = var0.j(lm::a);
      return new Bz(var1);
   }

   public static void S(lm<?> var0, Bz var1) {
      var0.D(var1.R, lm::G);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof Bz)) {
         return false;
      } else {
         Bz var2 = (Bz)var1;
         return this.R.equals(var2.R);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.R});
   }

   public String toString() {
      long var1 = a ^ 113058979050970L;
      return "ItemLore{lines=" + this.R + '}';
   }
}

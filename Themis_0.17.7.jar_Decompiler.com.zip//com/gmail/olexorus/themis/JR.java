package com.gmail.olexorus.themis;

public interface JR extends gK, M8 {
   String J();

   Ae D();
}

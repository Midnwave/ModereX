package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class o {
   private al L;
   private static final long a = kt.a(2900205336359442564L, -7500130077928956723L, MethodHandles.lookup().lookupClass()).a(247926345742459L);

   public o(al var1) {
      this.L = var1;
   }

   public static o H(lm<?> var0) {
      return new o(var0.R());
   }

   public static void F(lm<?> var0, o var1) {
      var0.T(var1.L);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof o)) {
         return false;
      } else {
         o var2 = (o)var1;
         return this.L.equals(var2.L);
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.L);
   }

   public String toString() {
      long var1 = a ^ 85138551058354L;
      return "ItemDamageResistant{typesTagKey=" + this.L + '}';
   }
}

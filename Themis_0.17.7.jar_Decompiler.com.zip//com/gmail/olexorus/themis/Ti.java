package com.gmail.olexorus.themis;

public final class Ti implements TO {
   private final int w;

   public Ti(int var1) {
      this.w = var1;
   }

   public AR C(VD<AR> var1, lm<?> var2) {
      vL var3 = var2.R().u();
      return (AR)var1.C(var3, this.w);
   }

   public int z() {
      return this.w;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class V4 {
   private V G;
   private float D;
   private float v;
   private static final long a = kt.a(-404851629419196881L, -3685119119941386528L, MethodHandles.lookup().lookupClass()).a(97204028461851L);

   public V4(V var1, float var2, float var3) {
      this.G = var1;
      this.D = var2;
      this.v = var3;
   }

   public V4(double var1, double var3, double var5, float var7, float var8) {
      this(new V(var1, var3, var5), var7, var8);
   }

   public V v() {
      return this.G;
   }

   public double B() {
      return this.G.o();
   }

   public double P() {
      return this.G.h();
   }

   public double u() {
      return this.G.D();
   }

   public float I() {
      return this.D;
   }

   public float T() {
      return this.v;
   }

   public V4 j() {
      return new V4(this.G, this.D, this.v);
   }

   public String toString() {
      long var1 = a ^ 60989225545230L;
      return "Location {[" + this.G.toString() + "], yaw: " + this.D + ", pitch: " + this.v + "}";
   }
}

package com.gmail.olexorus.themis;

import java.util.Objects;

public class TS {
   private Nt v;
   private boolean p;

   public TS(Nt var1, boolean var2) {
      this.v = var1;
      this.p = var2;
   }

   public static TS X(lm<?> var0) {
      Nt var1 = (Nt)var0.u(lm::E);
      boolean var2 = var0.P();
      return new TS(var1, var2);
   }

   public static void y(lm<?> var0, TS var1) {
      var0.l(var1.v, lm::c);
      var0.I(var1.p);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof TS)) {
         return false;
      } else {
         TS var2 = (TS)var1;
         return this.p != var2.p ? false : Objects.equals(this.v, var2.v);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.v, this.p});
   }
}

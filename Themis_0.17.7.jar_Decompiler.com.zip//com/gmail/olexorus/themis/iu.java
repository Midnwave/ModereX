package com.gmail.olexorus.themis;

public class iu<T extends wU> extends id implements Bu<T> {
   private final MO<T> z;
   private final Gw<T> a;

   public iu(z2 var1, MO<T> var2, Gw<T> var3) {
      super(var1);
      this.z = var2;
      this.a = var3;
   }

   public T M(lm<?> var1) {
      return (wU)this.z.apply(var1);
   }

   public void Q(lm<?> var1, T var2) {
      this.a.accept(var1, var2);
   }
}

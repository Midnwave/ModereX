package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class mB {
   private static final N8<cP> q;
   public static final cP H;
   public static final cP p;
   public static final cP T;
   public static final cP G;
   public static final cP j;
   public static final cP M;
   public static final cP Q;
   public static final cP d;
   public static final cP K;
   public static final cP W;
   public static final cP O;
   public static final cP Z;
   public static final cP a;
   public static final cP D;
   public static final cP u;

   public static N8<cP> h() {
      return q;
   }

   public static cP R(String var0) {
      return (cP)q.h(var0, in::new);
   }

   static {
      long var0 = kt.a(458282945342876164L, 2884537861700655010L, MethodHandles.lookup().lookupClass()).a(252632832992443L) ^ 51904080371881L;
      q = new N8("villager_profession");
      H = R("none");
      p = R("armorer");
      T = R("butcher");
      G = R("cartographer");
      j = R("cleric");
      M = R("farmer");
      Q = R("fisherman");
      d = R("fletcher");
      K = R("leatherworker");
      W = R("librarian");
      O = R("mason");
      Z = R("nitwit");
      a = R("shepherd");
      D = R("toolsmith");
      u = R("weaponsmith");
      q.f();
   }
}

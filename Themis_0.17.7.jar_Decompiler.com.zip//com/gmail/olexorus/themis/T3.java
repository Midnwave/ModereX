package com.gmail.olexorus.themis;

public interface T3<T extends MC> extends NG<T3<T>, T> {
   zj P();
}

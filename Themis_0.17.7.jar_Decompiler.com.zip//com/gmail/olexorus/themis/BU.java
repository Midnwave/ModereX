package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.stream.Stream;

final class BU extends BG implements E4 {
   private final short s;
   private static final long a = kt.a(3167999574198877088L, -539933846720864082L, MethodHandles.lookup().lookupClass()).a(208875817019563L);

   BU(short var1) {
      this.s = var1;
   }

   public short s() {
      return this.s;
   }

   public byte l() {
      return (byte)(this.s & 255);
   }

   public int p() {
      return this.s;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         BU var2 = (BU)var1;
         return this.s == var2.s;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Short.hashCode(this.s);
   }

   public Stream<? extends rE> T() {
      long var1 = a ^ 123341102257546L;
      return Stream.of(rE.B("value", this.s));
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum bv {
   DEFAULT,
   FALL_VARIANTS,
   INTENTIONAL_GAME_DESIGN;

   public static final l3<String, bv> ID_INDEX;
   private final String I;
   private static final bv[] S;

   private bv(String var3) {
      this.I = var3;
   }

   public String b() {
      return this.I;
   }

   private static bv[] E() {
      return new bv[]{DEFAULT, FALL_VARIANTS, INTENTIONAL_GAME_DESIGN};
   }

   static {
      long var0 = kt.a(-8708107748107744215L, 1456421101885441708L, MethodHandles.lookup().lookupClass()).a(60581175109137L) ^ 68002787848410L;
      DEFAULT = new bv("DEFAULT", 0, "default");
      FALL_VARIANTS = new bv("FALL_VARIANTS", 1, "fall_variants");
      INTENTIONAL_GAME_DESIGN = new bv("INTENTIONAL_GAME_DESIGN", 2, "intentional_game_design");
      S = E();
      ID_INDEX = l3.Q(bv.class, bv::b);
   }
}

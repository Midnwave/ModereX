package com.gmail.olexorus.themis;

import java.util.Stack;

class Oc extends Stack<bO> {
   public synchronized bO u() {
      return super.size() == 0 ? null : (bO)super.peek();
   }
}

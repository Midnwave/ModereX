package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public abstract class CU<E> extends CT<E> implements List<E>, lK {
   public static final Tt k = new Tt((MH)null);
   private static final long b = kt.a(8810691336234382322L, 7265475018470451117L, MethodHandles.lookup().lookupClass()).a(279474531705402L);

   protected CU() {
   }

   public abstract int q();

   public abstract E get(int var1);

   public Iterator<E> iterator() {
      return (Iterator)(new Op(this));
   }

   public int indexOf(E var1) {
      List var2 = (List)this;
      boolean var3 = false;
      int var4 = 0;
      Iterator var5 = var2.iterator();

      int var10000;
      while(true) {
         if (!var5.hasNext()) {
            var10000 = -1;
            break;
         }

         Object var6 = var5.next();
         boolean var8 = false;
         if (bU.I(var6, var1)) {
            var10000 = var4;
            break;
         }

         ++var4;
      }

      return var10000;
   }

   public int lastIndexOf(E var1) {
      List var2 = (List)this;
      boolean var3 = false;
      ListIterator var4 = var2.listIterator(var2.size());

      int var10000;
      while(true) {
         if (var4.hasPrevious()) {
            Object var5 = var4.previous();
            boolean var6 = false;
            if (!bU.I(var5, var1)) {
               continue;
            }

            var10000 = var4.nextIndex();
            break;
         }

         var10000 = -1;
         break;
      }

      return var10000;
   }

   public ListIterator<E> listIterator() {
      return (ListIterator)(new Ox(this, 0));
   }

   public ListIterator<E> listIterator(int var1) {
      return (ListIterator)(new Ox(this, var1));
   }

   public List<E> subList(int var1, int var2) {
      return (List)(new gW(this, var1, var2));
   }

   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else {
         return !(var1 instanceof List) ? false : k.U((Collection)this, (Collection)var1);
      }
   }

   public int hashCode() {
      return k.K((Collection)this);
   }

   public void add(int var1, E var2) {
      long var3 = b ^ 65035213693013L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean addAll(int var1, Collection<? extends E> var2) {
      long var3 = b ^ 88779219288033L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public E remove(int var1) {
      long var2 = b ^ 63657028267874L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public E set(int var1, E var2) {
      long var3 = b ^ 126676479073087L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }
}

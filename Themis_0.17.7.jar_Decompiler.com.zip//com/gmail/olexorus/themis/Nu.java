package com.gmail.olexorus.themis;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;
import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.logging.Level;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class Nu extends MessageToMessageDecoder<ByteBuf> {
   public Gs K;
   public Player A;
   public boolean C;
   private static final long a = kt.a(-7952771467331485692L, 8877542220132472043L, MethodHandles.lookup().lookupClass()).a(198010863232917L);

   public Nu(Gs var1) {
      this.K = var1;
   }

   public Nu(Nu var1) {
      this.K = var1.K;
      this.A = var1.A;
      this.C = var1.C;
   }

   public void Y(ChannelHandlerContext var1, ByteBuf var2, List<Object> var3) {
      try {
         JO.r(var1.channel(), this.K, this.A, var2, true);
         var3.add(NY.Q(var2));
      } catch (Throwable var5) {
         if (vl.J(var5, Co.class)) {
            throw var5;
         } else {
            throw new Co(var5);
         }
      }
   }

   public void H(ChannelHandlerContext var1, ByteBuf var2, List<Object> var3) {
      if (var2.isReadable()) {
         this.Y(var1, var2, var3);
      }

   }

   public void exceptionCaught(ChannelHandlerContext var1, Throwable var2) {
      long var3 = a ^ 1273968835479L;
      if (!vl.J(var2, Co.class)) {
         super.exceptionCaught(var1, var2);
      } else {
         boolean var5 = oS.J().z().P() || EO.P();
         if (var5 || this.K != null && this.K.U() != uy.HANDSHAKING) {
            if (oS.J().z().Z()) {
               String var6 = this.K != null ? this.K.U().name() : "null";
               String var7 = this.K != null ? this.K.E().f() : "null";
               oS.J().s().log(Level.WARNING, var2, this::lambda$exceptionCaught$0);
            } else {
               oS.J().m().A(var2.getMessage());
            }
         }

         if (oS.J().z().o()) {
            try {
               if (this.K != null) {
                  this.K.n(new s5(X.N("Invalid packet")));
               }
            } catch (Exception var8) {
            }

            var1.channel().close();
            if (this.A != null) {
               uD.r().m(this.A, (Plugin)oS.J().g(), this::lambda$exceptionCaught$1, (Runnable)null, 1L);
            }

            if (this.K != null && this.K.h().s() != null) {
               oS.J().m().A("Disconnected " + this.K.h().s() + " due to an invalid packet!");
            }
         }

      }
   }

   public void userEventTriggered(ChannelHandlerContext var1, Object var2) {
      if (CP.f != null && var2 == CP.f) {
         GR.w(var1.channel(), this, this.K);
         super.userEventTriggered(var1, var2);
      } else {
         super.userEventTriggered(var1, var2);
      }
   }

   private void lambda$exceptionCaught$1(Object var1) {
      long var2 = a ^ 92640791172078L;
      this.A.kickPlayer("Invalid packet");
   }

   private String lambda$exceptionCaught$0(String var1, String var2) {
      long var3 = a ^ 25473809997653L;
      return "An error occurred while processing a packet from " + this.K.h().s() + " (state: " + var1 + ", clientVersion: " + var2 + ", serverVersion: " + oS.J().g().w().q() + ")";
   }
}

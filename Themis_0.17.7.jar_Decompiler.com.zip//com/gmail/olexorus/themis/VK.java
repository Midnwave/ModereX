package com.gmail.olexorus.themis;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.tree.ArgumentCommandNode;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

public class VK<S> {
   protected final wi<?, ?, ?, ?, ?, ?> p;
   private final Map<Class<?>, ArgumentType<?>> g;
   private static final long a = kt.a(3251641252143185066L, 4686771802480670735L, MethodHandles.lookup().lookupClass()).a(79042664988298L);

   VK(wi<?, ?, ?, ?, ?, ?> var1) {
      long var2 = a ^ 120600677077964L;
      super();
      this.g = new HashMap();
      var1.v("brigadier");
      this.p = var1;
      this.E(String.class, StringArgumentType.word());
      this.E(Float.TYPE, FloatArgumentType.floatArg());
      this.E(Float.class, FloatArgumentType.floatArg());
      this.E(Double.TYPE, DoubleArgumentType.doubleArg());
      this.E(Double.class, DoubleArgumentType.doubleArg());
      this.E(Boolean.TYPE, BoolArgumentType.bool());
      this.E(Boolean.class, BoolArgumentType.bool());
      this.E(Integer.TYPE, IntegerArgumentType.integer());
      this.E(Integer.class, IntegerArgumentType.integer());
      this.E(Long.TYPE, IntegerArgumentType.integer());
      this.E(Long.class, IntegerArgumentType.integer());
   }

   <T> void E(Class<T> var1, ArgumentType<?> var2) {
      this.g.put(var1, var2);
   }

   ArgumentType<Object> k(AM var1) {
      return (ArgumentType)(var1.B ? StringArgumentType.greedyString() : (ArgumentType)this.g.getOrDefault(var1.g(), StringArgumentType.string()));
   }

   LiteralCommandNode<S> N(ti var1, LiteralCommandNode<S> var2, SuggestionProvider<S> var3, Command<S> var4, BiPredicate<ti, S> var5, BiPredicate<Bd, S> var6) {
      long var7 = a ^ 106216296076602L;
      LiteralArgumentBuilder var9 = (LiteralArgumentBuilder)LiteralArgumentBuilder.literal(var2.getLiteral()).requires(VK::lambda$register$0);
      Bd var10 = var1.E();
      if (var10 != null && var10.a == 0) {
         var9.executes(var4);
      }

      var2 = var9.build();
      boolean var11 = var1.y() instanceof NN;
      if (var10 != null) {
         this.T(var10, var2, var3, var4, var6);
      }

      Iterator var12 = var1.M().entries().iterator();

      while(true) {
         Entry var13;
         do {
            do {
               if (!var12.hasNext()) {
                  return var2;
               }

               var13 = (Entry)var12.next();
            } while(Nk.T((String)var13.getKey()) && !var11);
         } while(!((String)var13.getKey()).equals("help") && ((Bd)var13.getValue()).y.equals("help"));

         String var14 = (String)var13.getKey();
         Object var15 = var2;
         Predicate var17 = VK::lambda$register$1;
         Object var16;
         if (var11) {
            var16 = var2;
         } else {
            if (var14.contains(" ")) {
               String[] var18 = nQ.J.split(var14);

               for(int var19 = 0; var19 < var18.length - 1; ++var19) {
                  if (((CommandNode)var15).getChild(var18[var19]) == null) {
                     LiteralCommandNode var20 = ((LiteralArgumentBuilder)LiteralArgumentBuilder.literal(var18[var19]).requires(var17)).build();
                     ((CommandNode)var15).addChild(var20);
                     var15 = var20;
                  } else {
                     var15 = ((CommandNode)var15).getChild(var18[var19]);
                  }
               }

               var14 = var18[var18.length - 1];
            }

            var16 = ((CommandNode)var15).getChild(var14);
            if (var16 == null) {
               LiteralArgumentBuilder var21 = (LiteralArgumentBuilder)LiteralArgumentBuilder.literal(var14).requires(var17);
               if (((Bd)var13.getValue()).a == 0) {
                  var21.executes(var4);
               }

               var16 = var21.build();
            }
         }

         this.T((Bd)var13.getValue(), (CommandNode)var16, var3, var4, var6);
         if (!var11) {
            ((CommandNode)var15).addChild((CommandNode)var16);
         }
      }
   }

   void T(Bd var1, CommandNode<S> var2, SuggestionProvider<S> var3, Command<S> var4, BiPredicate<Bd, S> var5) {
      for(int var6 = 0; var6 < var1.z.length; ++var6) {
         AM var7 = var1.z[var6];
         AM var8 = var7.B();
         if (!var7.e() && (!var7.O() || var8 == null || var8.O())) {
            RequiredArgumentBuilder var9 = (RequiredArgumentBuilder)RequiredArgumentBuilder.argument(var7.G(), this.k(var7)).suggests(var3).requires(VK::lambda$registerParameters$2);
            if (var8 == null || var8.O()) {
               var9.executes(var4);
            }

            ArgumentCommandNode var10 = var9.build();
            ((CommandNode)var2).addChild(var10);
            var2 = var10;
         }
      }

   }

   private static boolean lambda$registerParameters$2(BiPredicate var0, Bd var1, Object var2) {
      return var0.test(var1, var2);
   }

   private static boolean lambda$register$1(BiPredicate var0, Entry var1, Object var2) {
      return var0.test((Bd)var1.getValue(), var2);
   }

   private static boolean lambda$register$0(BiPredicate var0, ti var1, Object var2) {
      return var0.test(var1, var2);
   }
}

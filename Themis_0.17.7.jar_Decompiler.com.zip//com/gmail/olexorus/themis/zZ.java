package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum zZ {
   V_1_7_2,
   V_1_7_4,
   V_1_7_5,
   V_1_7_6,
   V_1_7_7,
   V_1_7_8,
   V_1_7_9,
   V_1_7_10,
   V_1_8,
   V_1_8_3,
   V_1_8_8,
   V_1_9,
   V_1_9_1,
   V_1_9_2,
   V_1_9_4,
   V_1_10,
   V_1_10_1,
   V_1_10_2,
   V_1_11,
   V_1_11_2,
   V_1_12,
   V_1_12_1,
   V_1_12_2,
   V_1_13,
   V_1_13_1,
   V_1_13_2,
   V_1_14,
   V_1_14_1,
   V_1_14_2,
   V_1_14_3,
   V_1_14_4,
   V_1_15,
   V_1_15_1,
   V_1_15_2,
   V_1_16,
   V_1_16_1,
   V_1_16_2,
   V_1_16_3,
   V_1_16_4,
   V_1_16_5,
   V_1_17,
   V_1_17_1,
   V_1_18,
   V_1_18_1,
   V_1_18_2,
   V_1_19,
   V_1_19_1,
   V_1_19_2,
   V_1_19_3,
   V_1_19_4,
   V_1_20,
   V_1_20_1,
   V_1_20_2,
   V_1_20_3,
   V_1_20_4,
   V_1_20_5,
   V_1_20_6,
   V_1_21,
   V_1_21_1,
   V_1_21_2,
   V_1_21_3,
   V_1_21_4,
   V_1_21_5,
   V_1_21_6,
   V_1_21_7,
   V_1_21_8,
   V_1_21_9,
   V_1_21_10,
   V_1_21_11,
   ERROR;

   private static final zZ[] K;
   private static final zZ[] F;
   private final int n;
   private final String b;
   private vL x;
   private static final zZ[] H;

   private zZ(int var3) {
      this.n = var3;
      this.b = this.name().substring(2).replace("_", ".");
   }

   private zZ(int var3, boolean var4) {
      this.n = var3;
      if (var4) {
         this.b = this.name();
      } else {
         this.b = this.name().substring(2).replace("_", ".");
      }

   }

   public static zZ[] Y() {
      return F;
   }

   public static zZ e() {
      return F[1];
   }

   public static zZ J(int var0) {
      zZ[] var1 = K;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         zZ var4 = var1[var3];
         if (var4.n == var0) {
            return var4;
         }
      }

      return null;
   }

   public vL u() {
      if (this.x == null) {
         this.x = vL.e(this.n);
      }

      return this.x;
   }

   public String q() {
      return this.b;
   }

   public boolean g(zZ var1) {
      return this.ordinal() > var1.ordinal();
   }

   public boolean m(zZ var1) {
      return this.ordinal() < var1.ordinal();
   }

   public boolean i(zZ var1) {
      return this.ordinal() >= var1.ordinal();
   }

   public boolean R(zZ var1) {
      return this.ordinal() <= var1.ordinal();
   }

   public boolean K(ty var1, zZ var2) {
      // $FF: Couldn't be decompiled
   }

   private static zZ[] G() {
      return new zZ[]{V_1_7_2, V_1_7_4, V_1_7_5, V_1_7_6, V_1_7_7, V_1_7_8, V_1_7_9, V_1_7_10, V_1_8, V_1_8_3, V_1_8_8, V_1_9, V_1_9_1, V_1_9_2, V_1_9_4, V_1_10, V_1_10_1, V_1_10_2, V_1_11, V_1_11_2, V_1_12, V_1_12_1, V_1_12_2, V_1_13, V_1_13_1, V_1_13_2, V_1_14, V_1_14_1, V_1_14_2, V_1_14_3, V_1_14_4, V_1_15, V_1_15_1, V_1_15_2, V_1_16, V_1_16_1, V_1_16_2, V_1_16_3, V_1_16_4, V_1_16_5, V_1_17, V_1_17_1, V_1_18, V_1_18_1, V_1_18_2, V_1_19, V_1_19_1, V_1_19_2, V_1_19_3, V_1_19_4, V_1_20, V_1_20_1, V_1_20_2, V_1_20_3, V_1_20_4, V_1_20_5, V_1_20_6, V_1_21, V_1_21_1, V_1_21_2, V_1_21_3, V_1_21_4, V_1_21_5, V_1_21_6, V_1_21_7, V_1_21_8, V_1_21_9, V_1_21_10, V_1_21_11, ERROR};
   }

   static {
      long var0 = kt.a(-5282143898531496989L, 5814359911390633189L, MethodHandles.lookup().lookupClass()).a(188541883722572L) ^ 132525535788285L;
      V_1_7_2 = new zZ("V_1_7_2", 0, 4);
      V_1_7_4 = new zZ("V_1_7_4", 1, 4);
      V_1_7_5 = new zZ("V_1_7_5", 2, 4);
      V_1_7_6 = new zZ("V_1_7_6", 3, 5);
      V_1_7_7 = new zZ("V_1_7_7", 4, 5);
      V_1_7_8 = new zZ("V_1_7_8", 5, 5);
      V_1_7_9 = new zZ("V_1_7_9", 6, 5);
      V_1_7_10 = new zZ("V_1_7_10", 7, 5);
      V_1_8 = new zZ("V_1_8", 8, 47);
      V_1_8_3 = new zZ("V_1_8_3", 9, 47);
      V_1_8_8 = new zZ("V_1_8_8", 10, 47);
      V_1_9 = new zZ("V_1_9", 11, 107);
      V_1_9_1 = new zZ("V_1_9_1", 12, 108);
      V_1_9_2 = new zZ("V_1_9_2", 13, 109);
      V_1_9_4 = new zZ("V_1_9_4", 14, 110);
      V_1_10 = new zZ("V_1_10", 15, 210);
      V_1_10_1 = new zZ("V_1_10_1", 16, 210);
      V_1_10_2 = new zZ("V_1_10_2", 17, 210);
      V_1_11 = new zZ("V_1_11", 18, 315);
      V_1_11_2 = new zZ("V_1_11_2", 19, 316);
      V_1_12 = new zZ("V_1_12", 20, 335);
      V_1_12_1 = new zZ("V_1_12_1", 21, 338);
      V_1_12_2 = new zZ("V_1_12_2", 22, 340);
      V_1_13 = new zZ("V_1_13", 23, 393);
      V_1_13_1 = new zZ("V_1_13_1", 24, 401);
      V_1_13_2 = new zZ("V_1_13_2", 25, 404);
      V_1_14 = new zZ("V_1_14", 26, 477);
      V_1_14_1 = new zZ("V_1_14_1", 27, 480);
      V_1_14_2 = new zZ("V_1_14_2", 28, 485);
      V_1_14_3 = new zZ("V_1_14_3", 29, 490);
      V_1_14_4 = new zZ("V_1_14_4", 30, 498);
      V_1_15 = new zZ("V_1_15", 31, 573);
      V_1_15_1 = new zZ("V_1_15_1", 32, 575);
      V_1_15_2 = new zZ("V_1_15_2", 33, 578);
      V_1_16 = new zZ("V_1_16", 34, 735);
      V_1_16_1 = new zZ("V_1_16_1", 35, 736);
      V_1_16_2 = new zZ("V_1_16_2", 36, 751);
      V_1_16_3 = new zZ("V_1_16_3", 37, 753);
      V_1_16_4 = new zZ("V_1_16_4", 38, 754);
      V_1_16_5 = new zZ("V_1_16_5", 39, 754);
      V_1_17 = new zZ("V_1_17", 40, 755);
      V_1_17_1 = new zZ("V_1_17_1", 41, 756);
      V_1_18 = new zZ("V_1_18", 42, 757);
      V_1_18_1 = new zZ("V_1_18_1", 43, 757);
      V_1_18_2 = new zZ("V_1_18_2", 44, 758);
      V_1_19 = new zZ("V_1_19", 45, 759);
      V_1_19_1 = new zZ("V_1_19_1", 46, 760);
      V_1_19_2 = new zZ("V_1_19_2", 47, 760);
      V_1_19_3 = new zZ("V_1_19_3", 48, 761);
      V_1_19_4 = new zZ("V_1_19_4", 49, 762);
      V_1_20 = new zZ("V_1_20", 50, 763);
      V_1_20_1 = new zZ("V_1_20_1", 51, 763);
      V_1_20_2 = new zZ("V_1_20_2", 52, 764);
      V_1_20_3 = new zZ("V_1_20_3", 53, 765);
      V_1_20_4 = new zZ("V_1_20_4", 54, 765);
      V_1_20_5 = new zZ("V_1_20_5", 55, 766);
      V_1_20_6 = new zZ("V_1_20_6", 56, 766);
      V_1_21 = new zZ("V_1_21", 57, 767);
      V_1_21_1 = new zZ("V_1_21_1", 58, 767);
      V_1_21_2 = new zZ("V_1_21_2", 59, 768);
      V_1_21_3 = new zZ("V_1_21_3", 60, 768);
      V_1_21_4 = new zZ("V_1_21_4", 61, 769);
      V_1_21_5 = new zZ("V_1_21_5", 62, 770);
      V_1_21_6 = new zZ("V_1_21_6", 63, 771);
      V_1_21_7 = new zZ("V_1_21_7", 64, 772);
      V_1_21_8 = new zZ("V_1_21_8", 65, 772);
      V_1_21_9 = new zZ("V_1_21_9", 66, 773);
      V_1_21_10 = new zZ("V_1_21_10", 67, 773);
      V_1_21_11 = new zZ("V_1_21_11", 68, 774);
      ERROR = new zZ("ERROR", 69, -1, true);
      H = G();
      K = values();
      F = values();
      int var2 = 0;

      zZ var4;
      for(int var3 = F.length - 1; var3 > var2; F[var2++] = var4) {
         var4 = F[var3];
         F[var3--] = F[var2];
      }

   }
}

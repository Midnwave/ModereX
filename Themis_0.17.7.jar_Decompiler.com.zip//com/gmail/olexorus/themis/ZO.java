package com.gmail.olexorus.themis;

public class ZO extends Zh<ZO> {
}

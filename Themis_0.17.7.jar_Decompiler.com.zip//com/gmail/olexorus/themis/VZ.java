package com.gmail.olexorus.themis;

import java.util.function.Function;

final class VZ<T> implements Nn<T> {
   private final String J;
   private final Function<String, T> s;
   private final T z;
   private final boolean X;
   private boolean i;
   private T y;

   VZ(String var1, Function<String, T> var2, T var3, boolean var4) {
      this.J = var1;
      this.s = var2;
      this.z = var3;
      this.X = var4;
   }

   public T i() {
      if (!this.i) {
         String var1 = iL.D(this.J);
         String var2 = System.getProperty(var1, iL.U().getProperty(this.J));
         if (var2 != null) {
            this.y = this.s.apply(var2);
         }

         if (this.y == null) {
            if (this.X) {
               this.y = b.w.map(this::lambda$value$0).orElse(this.z);
            } else {
               this.y = this.z;
            }
         }

         this.i = true;
      }

      return this.y;
   }

   public boolean equals(Object var1) {
      return this == var1;
   }

   public int hashCode() {
      return this.J.hashCode();
   }

   private Object lambda$value$0(C6 var1) {
      return var1.I(this, this.z);
   }
}

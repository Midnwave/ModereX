package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class My {
   private static final N8<zl> P;
   public static final zl K;
   public static final zl E;
   private static final long a = kt.a(-2844589161004464797L, -8166824736884535679L, MethodHandles.lookup().lookupClass()).a(142561641414582L);

   public static zl r(String var0, gv var1, String var2) {
      long var3 = a ^ 85036699646009L;
      al var5 = new al("entity/nautilus/" + var2);
      return (zl)P.h(var0, My::lambda$define$0);
   }

   public static N8<zl> a() {
      return P;
   }

   private static iI lambda$define$0(gv var0, al var1, z2 var2) {
      return new iI(var2, var0, var1);
   }

   static {
      long var0 = a ^ 131721337094366L;
      P = new N8("zombie_nautilus_variant");
      K = r("temperate", gv.NORMAL, "zombie_nautilus");
      E = r("warm", gv.WARM, "zombie_nautilus_coral");
      P.f();
   }
}

package com.gmail.olexorus.themis;

public class sU extends lm<sU> {
   private int G;
   private int p;
   private int r;

   public void t() {
      this.G = this.a();
      this.p = this.Q();
      this.r = this.f();
   }

   public void d() {
      this.y(this.G);
      this.E(this.p);
      this.L(this.r);
   }

   public void b(sU var1) {
      this.G = var1.G;
      this.p = var1.p;
      this.r = var1.r;
   }
}

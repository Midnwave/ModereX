package com.gmail.olexorus.themis;

enum EN {
   public Boolean V(Boolean var1, Boolean var2) {
      return var2 == var1;
   }
}

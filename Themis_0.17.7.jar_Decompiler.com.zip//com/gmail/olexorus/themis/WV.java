package com.gmail.olexorus.themis;

import io.papermc.paper.threadedregions.scheduler.AsyncScheduler;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.concurrent.TimeUnit;
import org.bukkit.plugin.Plugin;

public class WV extends WY {
   private final AsyncScheduler m;
   private ScheduledTask L;

   public WV(AsyncScheduler var1) {
      this.m = var1;
   }

   public void Z(wr var1) {
      var1.Z(AsyncScheduler.class, this.m);
   }

   public void O(Plugin var1, Runnable var2, long var3) {
      this.m.runDelayed(var1, WV::lambda$createDelayedTask$0, var3 / 20L, TimeUnit.SECONDS);
   }

   public void P(Plugin var1, Runnable var2, long var3, long var5) {
      this.L = this.m.runAtFixedRate(var1, WV::lambda$createLocaleTask$1, var3 / 20L, var5 / 20L, TimeUnit.SECONDS);
   }

   public void g() {
      this.L.cancel();
   }

   private static void lambda$createLocaleTask$1(Runnable var0, ScheduledTask var1) {
      var0.run();
   }

   private static void lambda$createDelayedTask$0(Runnable var0, ScheduledTask var1) {
      var0.run();
   }
}

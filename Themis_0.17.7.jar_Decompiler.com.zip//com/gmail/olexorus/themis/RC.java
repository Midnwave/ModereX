package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum RC {
   LARGE,
   NONE,
   SMALL;

   // $FF: synthetic method
   private static RC[] k() {
      return new RC[]{LARGE, NONE, SMALL};
   }

   static {
      long var0 = kt.a(8722407001629133189L, 8704947261624401317L, MethodHandles.lookup().lookupClass()).a(174810190457903L) ^ 38543633850919L;
      LARGE = new RC("LARGE", 0);
      NONE = new RC("NONE", 1);
      SMALL = new RC("SMALL", 2);
   }
}

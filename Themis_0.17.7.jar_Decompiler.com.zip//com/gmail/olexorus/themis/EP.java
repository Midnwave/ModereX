package com.gmail.olexorus.themis;

public interface EP<R> extends Ol<R> {
   R b();
}

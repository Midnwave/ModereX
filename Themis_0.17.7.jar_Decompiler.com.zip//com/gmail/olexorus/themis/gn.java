package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public abstract class gn {
   protected final OU<?> Z;
   private static final long a = kt.a(6606777668107135940L, 117473033436444068L, MethodHandles.lookup().lookupClass()).a(175103542662205L);

   public gn(OU<?> var1) {
      this.Z = var1;
   }

   public static gn l(Rc var0, vL var1) {
      long var2 = a ^ 5404151310419L;
      RT var4 = (RT)var0;
      String var5 = var4.N("type");
      OU var6 = W4.C(var5);
      if (var6 == null) {
         throw new IllegalStateException("Can't find position source type with id " + var5);
      } else {
         return var6.G(var4, var1);
      }
   }

   public static Rc w(gn var0, vL var1) {
      return u(var0, var0.v(), var1);
   }

   public static <T extends gn> Rc u(T var0, OU<T> var1, vL var2) {
      long var3 = a ^ 52543003673329L;
      RT var5 = new RT();
      var5.j("type", new mZ(var1.f().toString()));
      var1.y(var0, var2, var5);
      return var5;
   }

   public OU<?> v() {
      return this.Z;
   }
}

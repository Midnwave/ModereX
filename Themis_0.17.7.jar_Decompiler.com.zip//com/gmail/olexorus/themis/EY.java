package com.gmail.olexorus.themis;

import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public final class EY {
   private static final Map<String, String> l;
   private static final Map<al, RT> v;
   private static final N8<mE> n;
   public static final mE V;
   public static final mE t;
   public static final mE R;
   public static final mE e;
   public static final mE d;
   public static final mE c;
   public static final mE h;
   public static final mE j;
   public static final mE M;
   public static final mE U;
   public static final mE q;
   public static final mE w;
   public static final mE T;
   public static final mE E;
   public static final mE G;
   public static final mE D;
   public static final mE P;
   public static final mE K;
   public static final mE a;
   public static final mE r;
   public static final mE f;
   public static final mE C;
   public static final mE L;
   public static final mE m;
   public static final mE Y;
   public static final mE Z;
   public static final mE x;
   public static final mE o;
   public static final mE X;
   public static final mE y;
   public static final mE i;
   public static final mE S;
   public static final mE Q;
   public static final mE F;
   public static final mE H;
   public static final mE b;
   public static final mE z;
   public static final mE W;
   public static final mE u;
   public static final mE g;
   public static final mE p;
   public static final mE k;
   public static final mE s;
   private static final long A = kt.a(7841108207996157646L, 1103084449648693667L, MethodHandles.lookup().lookupClass()).a(238018877167207L);

   public static mE V(String var0) {
      lm var1 = lm.s(vL.n());
      return (mE)n.h(var0, EY::lambda$define$0);
   }

   public static N8<mE> R() {
      return n;
   }

   private static mE lambda$define$0(lm var0, z2 var1) {
      long var2 = A ^ 110593819249385L;
      RT var4 = (RT)v.get(var1.m());
      if (var4 == null) {
         throw new IllegalArgumentException("Can't define enchantment " + var1.m() + ", no data found");
      } else {
         return mE.N(var4, var0, var1);
      }
   }

   static {
      long var0 = A ^ 100386474483240L;
      l = new HashMap();
      l.put("minecraft:sweeping", "minecraft:sweeping_edge");
      v = new HashMap();

      try {
         mC var2 = com.gmail.olexorus.themis.M.v("mappings/data/enchantment");

         try {
            var2.p();
            Iterator var3 = ((mC)var2.m().getValue()).iterator();

            while(var3.hasNext()) {
               Entry var4 = (Entry)var3.next();
               al var5 = new al((String)var4.getKey());
               v.put(var5, ((mC)var4.getValue()).P());
            }
         } catch (Throwable var7) {
            if (var2 != null) {
               try {
                  var2.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (var2 != null) {
            var2.close();
         }
      } catch (IOException var8) {
         throw new RuntimeException("Error while reading enchantment type data", var8);
      }

      n = new N8("enchantment");
      V = V("protection");
      t = V("fire_protection");
      R = V("feather_falling");
      e = V("blast_protection");
      d = V("projectile_protection");
      c = V("respiration");
      h = V("aqua_affinity");
      j = V("thorns");
      M = V("depth_strider");
      U = V("frost_walker");
      q = V("binding_curse");
      w = V("soul_speed");
      T = V("swift_sneak");
      E = V("sharpness");
      G = V("smite");
      D = V("bane_of_arthropods");
      P = V("knockback");
      K = V("fire_aspect");
      a = V("looting");
      r = V("sweeping_edge");
      f = V("efficiency");
      C = V("silk_touch");
      L = V("unbreaking");
      m = V("fortune");
      Y = V("power");
      Z = V("punch");
      x = V("flame");
      o = V("infinity");
      X = V("luck_of_the_sea");
      y = V("lure");
      i = V("loyalty");
      S = V("impaling");
      Q = V("riptide");
      F = V("channeling");
      H = V("multishot");
      b = V("quick_charge");
      z = V("piercing");
      W = V("mending");
      u = V("vanishing_curse");
      g = V("density");
      p = V("breach");
      k = V("wind_burst");
      s = V("lunge");
      v.clear();
      n.f();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum vL {
   V_1_7_2,
   V_1_7_10,
   V_1_8,
   V_1_9,
   V_1_9_1,
   V_1_9_2,
   V_1_9_3,
   V_1_10,
   V_1_11,
   V_1_11_1,
   V_1_12,
   V_1_12_1,
   V_1_12_2,
   V_1_13,
   V_1_13_1,
   V_1_13_2,
   V_1_14,
   V_1_14_1,
   V_1_14_2,
   V_1_14_3,
   V_1_14_4,
   V_1_15,
   V_1_15_1,
   V_1_15_2,
   V_1_16,
   V_1_16_1,
   V_1_16_2,
   V_1_16_3,
   V_1_16_4,
   V_1_17,
   V_1_17_1,
   V_1_18,
   V_1_18_2,
   V_1_19,
   V_1_19_1,
   V_1_19_3,
   V_1_19_4,
   V_1_20,
   V_1_20_2,
   V_1_20_3,
   V_1_20_5,
   V_1_21,
   V_1_21_2,
   V_1_21_4,
   V_1_21_5,
   V_1_21_6,
   V_1_21_7,
   V_1_21_9,
   V_1_21_11,
   LOWER_THAN_SUPPORTED_VERSIONS,
   HIGHER_THAN_SUPPORTED_VERSIONS,
   UNKNOWN;

   private static final vL[] z;
   private static final vL[] e;
   private static final int T;
   private static final int k;
   private final int S;
   private final String O;
   private zZ y;

   private vL(int var3) {
      this.S = var3;
      this.O = this.name().substring(2).replace("_", ".");
   }

   private vL(int var3, boolean var4) {
      this.S = var3;
      if (var4) {
         this.O = this.name();
      } else {
         this.O = this.name().substring(2).replace("_", ".");
      }

   }

   public static boolean e(int var0) {
      return var0 <= n().S && var0 >= S().S;
   }

   public boolean x() {
      return e(this.S);
   }

   public String f() {
      return this.O;
   }

   public static vL e(int var0) {
      if (var0 < T) {
         return S();
      } else if (var0 > k) {
         return n();
      } else {
         vL[] var1 = z;
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            vL var4 = var1[var3];
            if (var4.S > var0) {
               break;
            }

            if (var4.S == var0) {
               return var4;
            }
         }

         return UNKNOWN;
      }
   }

   public static vL n() {
      return e[3];
   }

   public static vL S() {
      return z[0];
   }

   public zZ J() {
      if (this.y == null) {
         this.y = zZ.J(this.S);
      }

      return this.y;
   }

   public boolean K(vL var1) {
      return this.S >= var1.S;
   }

   public boolean X(vL var1) {
      return this.S < var1.S;
   }

   public boolean a(vL var1) {
      return this.S <= var1.S;
   }

   // $FF: synthetic method
   private static vL[] z() {
      return new vL[]{V_1_7_2, V_1_7_10, V_1_8, V_1_9, V_1_9_1, V_1_9_2, V_1_9_3, V_1_10, V_1_11, V_1_11_1, V_1_12, V_1_12_1, V_1_12_2, V_1_13, V_1_13_1, V_1_13_2, V_1_14, V_1_14_1, V_1_14_2, V_1_14_3, V_1_14_4, V_1_15, V_1_15_1, V_1_15_2, V_1_16, V_1_16_1, V_1_16_2, V_1_16_3, V_1_16_4, V_1_17, V_1_17_1, V_1_18, V_1_18_2, V_1_19, V_1_19_1, V_1_19_3, V_1_19_4, V_1_20, V_1_20_2, V_1_20_3, V_1_20_5, V_1_21, V_1_21_2, V_1_21_4, V_1_21_5, V_1_21_6, V_1_21_7, V_1_21_9, V_1_21_11, LOWER_THAN_SUPPORTED_VERSIONS, HIGHER_THAN_SUPPORTED_VERSIONS, UNKNOWN};
   }

   static {
      long var0 = kt.a(2485752436847969093L, 60203328948472780L, MethodHandles.lookup().lookupClass()).a(12626753141801L) ^ 44438136413480L;
      V_1_7_2 = new vL("V_1_7_2", 0, 4);
      V_1_7_10 = new vL("V_1_7_10", 1, 5);
      V_1_8 = new vL("V_1_8", 2, 47);
      V_1_9 = new vL("V_1_9", 3, 107);
      V_1_9_1 = new vL("V_1_9_1", 4, 108);
      V_1_9_2 = new vL("V_1_9_2", 5, 109);
      V_1_9_3 = new vL("V_1_9_3", 6, 110);
      V_1_10 = new vL("V_1_10", 7, 210);
      V_1_11 = new vL("V_1_11", 8, 315);
      V_1_11_1 = new vL("V_1_11_1", 9, 316);
      V_1_12 = new vL("V_1_12", 10, 335);
      V_1_12_1 = new vL("V_1_12_1", 11, 338);
      V_1_12_2 = new vL("V_1_12_2", 12, 340);
      V_1_13 = new vL("V_1_13", 13, 393);
      V_1_13_1 = new vL("V_1_13_1", 14, 401);
      V_1_13_2 = new vL("V_1_13_2", 15, 404);
      V_1_14 = new vL("V_1_14", 16, 477);
      V_1_14_1 = new vL("V_1_14_1", 17, 480);
      V_1_14_2 = new vL("V_1_14_2", 18, 485);
      V_1_14_3 = new vL("V_1_14_3", 19, 490);
      V_1_14_4 = new vL("V_1_14_4", 20, 498);
      V_1_15 = new vL("V_1_15", 21, 573);
      V_1_15_1 = new vL("V_1_15_1", 22, 575);
      V_1_15_2 = new vL("V_1_15_2", 23, 578);
      V_1_16 = new vL("V_1_16", 24, 735);
      V_1_16_1 = new vL("V_1_16_1", 25, 736);
      V_1_16_2 = new vL("V_1_16_2", 26, 751);
      V_1_16_3 = new vL("V_1_16_3", 27, 753);
      V_1_16_4 = new vL("V_1_16_4", 28, 754);
      V_1_17 = new vL("V_1_17", 29, 755);
      V_1_17_1 = new vL("V_1_17_1", 30, 756);
      V_1_18 = new vL("V_1_18", 31, 757);
      V_1_18_2 = new vL("V_1_18_2", 32, 758);
      V_1_19 = new vL("V_1_19", 33, 759);
      V_1_19_1 = new vL("V_1_19_1", 34, 760);
      V_1_19_3 = new vL("V_1_19_3", 35, 761);
      V_1_19_4 = new vL("V_1_19_4", 36, 762);
      V_1_20 = new vL("V_1_20", 37, 763);
      V_1_20_2 = new vL("V_1_20_2", 38, 764);
      V_1_20_3 = new vL("V_1_20_3", 39, 765);
      V_1_20_5 = new vL("V_1_20_5", 40, 766);
      V_1_21 = new vL("V_1_21", 41, 767);
      V_1_21_2 = new vL("V_1_21_2", 42, 768);
      V_1_21_4 = new vL("V_1_21_4", 43, 769);
      V_1_21_5 = new vL("V_1_21_5", 44, 770);
      V_1_21_6 = new vL("V_1_21_6", 45, 771);
      V_1_21_7 = new vL("V_1_21_7", 46, 772);
      V_1_21_9 = new vL("V_1_21_9", 47, 773);
      V_1_21_11 = new vL("V_1_21_11", 48, 774);
      LOWER_THAN_SUPPORTED_VERSIONS = new vL("LOWER_THAN_SUPPORTED_VERSIONS", 49, V_1_7_2.S - 1, true);
      HIGHER_THAN_SUPPORTED_VERSIONS = new vL("HIGHER_THAN_SUPPORTED_VERSIONS", 50, V_1_21_11.S + 1, true);
      UNKNOWN = new vL("UNKNOWN", 51, -1, true);
      z = values();
      List var2 = Arrays.asList(values());
      Collections.reverse(var2);
      e = (vL[])var2.toArray(new vL[0]);
      T = LOWER_THAN_SUPPORTED_VERSIONS.S + 1;
      k = HIGHER_THAN_SUPPORTED_VERSIONS.S - 1;
   }
}

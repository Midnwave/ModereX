package com.gmail.olexorus.themis;

public interface OU<T extends gn> extends GL {
   T K(lm<?> var1);

   void m(lm<?> var1, T var2);

   T G(RT var1, vL var2);

   void y(T var1, vL var2, RT var3);
}

package com.gmail.olexorus.themis;

import java.util.List;
import java.util.Optional;

public class Mr {
   private byte H;
   private List<Integer> C;
   private int G;
   private Optional<String> Q;
   private Optional<ie> t;
   private Optional<List<Object>> z;
   private Optional<al> K;

   public Mr(byte var1, List<Integer> var2, int var3, String var4, ie var5, List<Object> var6, al var7) {
      this.H = var1;
      this.C = var2;
      this.G = var3;
      this.Q = Optional.ofNullable(var4);
      this.t = Optional.ofNullable(var5);
      this.z = Optional.ofNullable(var6);
      this.K = Optional.ofNullable(var7);
   }

   public byte F() {
      return this.H;
   }

   public List<Integer> c() {
      return this.C;
   }

   public int w() {
      return this.G;
   }

   public Optional<String> K() {
      return this.Q;
   }

   public Optional<ie> i() {
      return this.t;
   }

   public Optional<List<Object>> f() {
      return this.z;
   }

   public Optional<al> t() {
      return this.K;
   }

   private static ie lambda$setParserID$1(Integer var0) {
      return Ow.A(oS.J().g().w().u(), var0);
   }

   private static Integer lambda$getParserID$0(ie var0) {
      return var0.f(oS.J().g().w().u());
   }
}

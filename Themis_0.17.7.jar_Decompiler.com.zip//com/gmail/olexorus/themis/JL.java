package com.gmail.olexorus.themis;

import java.util.Optional;

public class JL {
   private int h;
   private cG Q;

   public JL(cG var1) {
      this.h = -1;
      this.Q = var1;
   }

   public JL(int var1) {
      this.h = var1;
      this.Q = null;
   }

   public int N() {
      return this.h;
   }

   public Optional<cG> k() {
      return Optional.ofNullable(this.Q);
   }
}

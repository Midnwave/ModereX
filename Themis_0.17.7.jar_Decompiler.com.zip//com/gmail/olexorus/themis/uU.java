package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class uU extends us<uU> {
   private tO<?> e;
   private tO<?> f;
   private tO<?> w;
   private static final long a = kt.a(3897479761683631528L, 5829286063585336288L, MethodHandles.lookup().lookupClass()).a(57394191775189L);

   public uU(tO<?> var1, tO<?> var2, tO<?> var3) {
      super(vD.O);
      this.e = var1;
      this.f = var2;
      this.w = var3;
   }

   public static uU n(lm<?> var0) {
      tO var1 = tO.X(var0);
      tO var2 = tO.X(var0);
      tO var3 = tO.X(var0);
      return new uU(var1, var2, var3);
   }

   public static void b(lm<?> var0, uU var1) {
      tO.A(var0, var1.e);
      tO.A(var0, var1.f);
      tO.A(var0, var1.w);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof uU)) {
         return false;
      } else {
         uU var2 = (uU)var1;
         if (!this.e.equals(var2.e)) {
            return false;
         } else {
            return !this.f.equals(var2.f) ? false : this.w.equals(var2.w);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.e, this.f, this.w});
   }

   public String toString() {
      long var1 = a ^ 132288545028322L;
      return "StonecutterRecipeDisplay{input=" + this.e + ", result=" + this.f + ", craftingStation=" + this.w + '}';
   }
}

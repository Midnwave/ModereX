package com.gmail.olexorus.themis;

public class ii extends id implements ap {
   public ii(z2 var1) {
      super(var1);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum A6 implements ou, CA {
   HANDSHAKE,
   LEGACY_SERVER_LIST_PING;

   private final int Z;
   private final Class<? extends lm<?>> z;
   private static final A6[] f;

   private A6(int var3, Class<? extends lm<?>> var4) {
      this.Z = var3;
      this.z = var4;
   }

   public static wC N(int var0) {
      if (var0 == 0) {
         return HANDSHAKE;
      } else {
         return var0 == 254 ? LEGACY_SERVER_LIST_PING : null;
      }
   }

   public int d() {
      return this.Z;
   }

   public RW R() {
      return RW.CLIENT;
   }

   private static A6[] g() {
      return new A6[]{HANDSHAKE, LEGACY_SERVER_LIST_PING};
   }

   static {
      long var0 = kt.a(-1841088794634557813L, 8032895540688918218L, MethodHandles.lookup().lookupClass()).a(41736063074503L) ^ 62518516721611L;
      HANDSHAKE = new A6("HANDSHAKE", 0, 0, Zj.class);
      LEGACY_SERVER_LIST_PING = new A6("LEGACY_SERVER_LIST_PING", 1, 254, (Class)null);
      f = g();
   }
}

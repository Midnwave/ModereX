package com.gmail.olexorus.themis;

public class Co extends RuntimeException {
   public Co(Throwable var1) {
      super(var1);
   }

   public Co(String var1) {
      super(var1);
   }
}

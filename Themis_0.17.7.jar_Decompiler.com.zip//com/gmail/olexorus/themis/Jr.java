package com.gmail.olexorus.themis;

import java.time.Instant;

public final class Jr {
   public static final Instant j = Instant.ofEpochMilli(1765310792741L);
   public static final uo k = new uo(2, 11, 0, (String)null);
   public static final uo S = new uo(0, 0, 0);
}

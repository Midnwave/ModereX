package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum Tp {
   PERFORM_RESPAWN,
   REQUEST_STATS,
   OPEN_INVENTORY_ACHIEVEMENT;

   private static final Tp[] i;
   private static final Tp[] K;

   public static Tp f(int var0) {
      return i[var0];
   }

   private static Tp[] E() {
      return new Tp[]{PERFORM_RESPAWN, REQUEST_STATS, OPEN_INVENTORY_ACHIEVEMENT};
   }

   static {
      long var0 = kt.a(-6386384521640467263L, -6159553736029407186L, MethodHandles.lookup().lookupClass()).a(112375962887336L) ^ 34288443502429L;
      PERFORM_RESPAWN = new Tp("PERFORM_RESPAWN", 0);
      REQUEST_STATS = new Tp("REQUEST_STATS", 1);
      OPEN_INVENTORY_ACHIEVEMENT = new Tp("OPEN_INVENTORY_ACHIEVEMENT", 2);
      K = E();
      i = values();
   }
}

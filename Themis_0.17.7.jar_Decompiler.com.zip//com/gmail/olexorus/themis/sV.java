package com.gmail.olexorus.themis;

public class sV extends lm<sV> {
   private int D;
   private double r;
   private double j;
   private double T;
   private float W;
   private float L;
   private boolean i;

   public sV(aE var1) {
      super(var1);
   }

   public void t() {
      this.D = this.Q();
      if (this.I.i(zZ.V_1_9)) {
         this.r = (double)this.x() / 4096.0D;
         this.j = (double)this.x() / 4096.0D;
         this.T = (double)this.x() / 4096.0D;
      } else {
         this.r = (double)this.M() / 32.0D;
         this.j = (double)this.M() / 32.0D;
         this.T = (double)this.M() / 32.0D;
      }

      this.W = (float)this.M() / 0.7111111F;
      this.L = (float)this.M() / 0.7111111F;
      this.i = this.P();
   }

   public void d() {
      this.E(this.D);
      if (this.I.i(zZ.V_1_9)) {
         this.f((short)((int)(this.r * 4096.0D)));
         this.f((short)((int)(this.j * 4096.0D)));
         this.f((short)((int)(this.T * 4096.0D)));
      } else {
         this.u((byte)((int)(this.r * 32.0D)));
         this.u((byte)((int)(this.j * 32.0D)));
         this.u((byte)((int)(this.T * 32.0D)));
      }

      this.u((int)(this.W * 0.7111111F));
      this.u((int)(this.L * 0.7111111F));
      this.I(this.i);
   }

   public void m(sV var1) {
      this.D = var1.D;
      this.r = var1.r;
      this.j = var1.j;
      this.T = var1.T;
      this.W = var1.W;
      this.L = var1.L;
      this.i = var1.i;
   }

   public int w() {
      return this.D;
   }

   public double z() {
      return this.r;
   }

   public double V() {
      return this.j;
   }

   public double P() {
      return this.T;
   }
}

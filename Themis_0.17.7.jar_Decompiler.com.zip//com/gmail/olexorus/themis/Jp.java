package com.gmail.olexorus.themis;

public interface Jp extends MC {
   uX<? extends Jp> y();
}

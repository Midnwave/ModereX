package com.gmail.olexorus.themis;

import java.net.SocketAddress;
import java.util.Arrays;
import java.util.List;

public class lC {
   public static SocketAddress q(Object var0) {
      return oS.J().T().O().D(var0);
   }

   public static boolean u(Object var0) {
      return oS.J().T().O().t(var0);
   }

   public static Object A(Object var0, Object var1) {
      return oS.J().T().O().K(var0, var1);
   }

   public static List<String> J(Object var0) {
      return oS.J().T().O().P(var0);
   }

   public static String M(Object var0) {
      return Arrays.toString(J(var0).toArray(new String[0]));
   }

   public static Object E(Object var0) {
      return oS.J().T().O().K(var0);
   }

   public static Object z(Object var0) {
      return oS.J().T().O().y(var0);
   }
}

package com.gmail.olexorus.themis;

import com.google.gson.TypeAdapter;
import java.lang.invoke.MethodHandles;

final class Tl {
   static final TypeAdapter<bj<?>> I;

   static {
      long var0 = kt.a(1925111905938216259L, 5204719055583545636L, MethodHandles.lookup().lookupClass()).a(154897228530417L) ^ 67697629417487L;
      I = u6.q("hover action", bj.T);
   }
}

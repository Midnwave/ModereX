package com.gmail.olexorus.themis;

import java.util.List;

class BF extends Bw {
   BF(List var1, boolean var2) {
      super(var1, var2);
   }
}

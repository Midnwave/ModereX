package com.gmail.olexorus.themis;

public final class cm {
   private final VC f;

   public cm(VC var1) {
      this.f = var1;
   }

   public static cm D(lm<?> var0) {
      VC var1 = var0.M();
      return new cm(var1);
   }

   public static void t(lm<?> var0, cm var1) {
      var0.o(var1.f);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum Rf {
   PROGRESS,
   NOTCHED_6,
   NOTCHED_10,
   NOTCHED_12,
   NOTCHED_20;

   public static final l3<String, Rf> NAMES;
   private final String b;
   private static final Rf[] e;

   private Rf(String var3) {
      this.b = var3;
   }

   private static String lambda$static$0(Rf var0) {
      return var0.b;
   }

   private static Rf[] R() {
      return new Rf[]{PROGRESS, NOTCHED_6, NOTCHED_10, NOTCHED_12, NOTCHED_20};
   }

   static {
      long var0 = kt.a(-1960134642662412120L, 5111439703212435559L, MethodHandles.lookup().lookupClass()).a(175601601571278L) ^ 99971551019458L;
      PROGRESS = new Rf("PROGRESS", 0, "progress");
      NOTCHED_6 = new Rf("NOTCHED_6", 1, "notched_6");
      NOTCHED_10 = new Rf("NOTCHED_10", 2, "notched_10");
      NOTCHED_12 = new Rf("NOTCHED_12", 3, "notched_12");
      NOTCHED_20 = new Rf("NOTCHED_20", 4, "notched_20");
      e = R();
      NAMES = l3.Q(Rf.class, Rf::lambda$static$0);
   }
}

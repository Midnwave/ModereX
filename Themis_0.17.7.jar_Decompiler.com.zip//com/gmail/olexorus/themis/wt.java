package com.gmail.olexorus.themis;

public interface wt<C, V> {
   static <K, E> Vv<K, E> k() {
      return new EA();
   }

   V M(Class<? extends C> var1);
}

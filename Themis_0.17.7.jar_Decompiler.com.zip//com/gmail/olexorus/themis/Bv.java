package com.gmail.olexorus.themis;

import java.time.Instant;

public class Bv {
   private final Wi f;
   private final Instant e;
   private boolean z;

   public Bv(Wi var1, Instant var2) {
      this.f = var1;
      this.e = var2;
   }

   public Wi I() {
      return this.f;
   }

   public Instant Z() {
      return this.e;
   }

   public boolean X() {
      return this.z;
   }

   public void d(boolean var1) {
      this.z = var1;
   }
}

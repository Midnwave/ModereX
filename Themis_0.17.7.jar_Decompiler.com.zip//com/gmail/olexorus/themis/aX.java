package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum aX {
   PEACEFUL,
   EASY,
   NORMAL,
   HARD;

   private static final aX[] r;

   public int W() {
      return this.ordinal();
   }

   public static aX B(int var0) {
      return r[var0];
   }

   // $FF: synthetic method
   private static aX[] y() {
      return new aX[]{PEACEFUL, EASY, NORMAL, HARD};
   }

   static {
      long var0 = kt.a(5676817852251112843L, -5352684236213219538L, MethodHandles.lookup().lookupClass()).a(269181619335184L) ^ 114466518314197L;
      PEACEFUL = new aX("PEACEFUL", 0);
      EASY = new aX("EASY", 1);
      NORMAL = new aX("NORMAL", 2);
      HARD = new aX("HARD", 3);
      r = values();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class gi {
   private static final N8<GD<?>> K;
   public static final GD<WC> l;
   public static final GD<Wd> Z;
   public static final GD<WD> M;
   public static final GD<WJ> k;
   public static final GD<WL> y;

   public static <T extends WZ<?>> GD<T> J(String var0, MO<T> var1, Gw<T> var2) {
      return (GD)K.h(var0, gi::lambda$define$0);
   }

   public static N8<GD<?>> X() {
      return K;
   }

   private static is lambda$define$0(MO var0, Gw var1, z2 var2) {
      return new is(var2, var0, var1);
   }

   static {
      long var0 = kt.a(-1490982329120704893L, -1011128664264443863L, MethodHandles.lookup().lookupClass()).a(6243798231806L) ^ 131403668619792L;
      K = new N8("consume_effect_type");
      l = J("apply_effects", WC::f, WC::T);
      Z = J("remove_effects", Wd::K, Wd::s);
      M = J("clear_all_effects", WD::L, WD::M);
      k = J("teleport_randomly", WJ::w, WJ::L);
      y = J("play_sound", WL::I, WL::X);
      K.f();
   }
}

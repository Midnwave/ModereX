package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum Ba {
   DOWN,
   UP;

   // $FF: synthetic method
   private static Ba[] e() {
      return new Ba[]{DOWN, UP};
   }

   static {
      long var0 = kt.a(-4154310026653887871L, 8461368839334564815L, MethodHandles.lookup().lookupClass()).a(78724618764930L) ^ 109058334129573L;
      DOWN = new Ba("DOWN", 0);
      UP = new Ba("UP", 1);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.Objects;

final class ET extends Eq<rF, NO> implements rF {
   private final Ma q;
   private static final long c = kt.a(-4142469762279593018L, 8988985502870474336L, MethodHandles.lookup().lookupClass()).a(81370600507211L);

   static rF Y(List<? extends lv> var0, WR var1, String var2, boolean var3, lv var4, Ma var5) {
      long var6 = c ^ 89395819770075L;
      return new ET(lv.Z(var0, p), (WR)Objects.requireNonNull(var1, "style"), (String)Objects.requireNonNull(var2, "nbtPath"), var3, lv.z(var4), (Ma)Objects.requireNonNull(var5, "pos"));
   }

   ET(List<X> var1, WR var2, String var3, boolean var4, X var5, Ma var6) {
      super(var1, var2, var3, var4, var5);
      this.q = var6;
   }

   public X V() {
      return this.i;
   }

   public Ma Z() {
      return this.q;
   }

   public rF j(List<? extends lv> var1) {
      return Y(var1, this.F, this.v, this.X, this.i, this.q);
   }

   public rF b(WR var1) {
      return Y(this.E, var1, this.v, this.X, this.i, this.q);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof rF)) {
         return false;
      } else if (!super.equals(var1)) {
         return false;
      } else {
         rF var2 = (rF)var1;
         return Objects.equals(this.q, var2.Z());
      }
   }

   public int hashCode() {
      int var1 = super.hashCode();
      var1 = 31 * var1 + this.q.hashCode();
      return var1;
   }

   public String toString() {
      return cH.M(this);
   }

   public NO l() {
      return new A0(this);
   }
}

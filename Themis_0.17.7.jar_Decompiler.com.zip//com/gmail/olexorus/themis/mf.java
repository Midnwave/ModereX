package com.gmail.olexorus.themis;

public final class mf implements Mn {
   public static final mf h = new mf();

   private mf() {
   }

   public static mf u(lm<?> var0) {
      return h;
   }

   public static void b(lm<?> var0, mf var1) {
   }

   public aB<mf> B() {
      return Vw.n;
   }
}

package com.gmail.olexorus.themis;

public interface MR extends Vj {
   static MR j(float var0) {
      return new B2(var0);
   }

   default uX<MR> y() {
      return tq.I;
   }

   float t();
}

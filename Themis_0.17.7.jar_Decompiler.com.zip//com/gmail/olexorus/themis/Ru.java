package com.gmail.olexorus.themis;

import java.lang.annotation.Annotation;

public interface Ru extends Annotation {
}

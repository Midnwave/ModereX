package com.gmail.olexorus.themis;

import java.util.Objects;

public class zO {
   private lr o;

   public zO(lr var1) {
      this.o = var1;
   }

   public static zO D(lm<?> var0) {
      lr var1 = (lr)var0.y((VD)R_.G());
      return new zO(var1);
   }

   public static void c(lm<?> var0, zO var1) {
      var0.j((GL)var1.o);
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof zO)) {
         return false;
      } else {
         zO var2 = (zO)var1;
         return this.o.equals(var2.o);
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.o);
   }
}

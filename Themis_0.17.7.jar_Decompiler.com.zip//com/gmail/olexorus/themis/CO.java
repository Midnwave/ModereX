package com.gmail.olexorus.themis;

public class CO<T> {
   private final int x;
   private final T V;

   public CO(int var1, T var2) {
      this.x = var1;
      this.V = var2;
   }

   public static <T> tw<CO<T>> p(tw<T> var0) {
      return (new gF(var0)).I();
   }

   static int G(CO var0) {
      return var0.x;
   }

   static Object l(CO var0) {
      return var0.V;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import org.bukkit.entity.Player;

final class nV extends n9 implements EP<y> {
   final Player g;
   private static final long a = kt.a(-784421400891229458L, 5765951191053304078L, MethodHandles.lookup().lookupClass()).a(104828408459848L);

   nV(Player var1) {
      super(0);
      this.g = var1;
   }

   public final void i(Object[] param1) {
      // $FF: Couldn't be decompiled
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}

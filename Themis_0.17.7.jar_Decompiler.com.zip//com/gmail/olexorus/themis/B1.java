package com.gmail.olexorus.themis;

import java.io.InputStream;

public class B1 extends Br {
   private final lm<?> u;

   public B1(lm<?> var1) {
      super((InputStream)null);
      this.u = var1;
   }

   public int read() {
      return this.u.h();
   }

   public int read(byte[] var1) {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) {
      int var4 = NY.p(this.u.g);
      NY.H(this.u.g, var1, var2, var3);
      return NY.p(this.u.g) - var4;
   }

   public long skip(long var1) {
      int var3 = NY.p(this.u.g);
      NY.c(this.u.g, (int)var1);
      return (long)(NY.p(this.u.g) - var3);
   }

   public int available() {
      return NY.r(this.u.g);
   }

   public void close() {
   }

   public void mark(int var1) {
      throw new UnsupportedOperationException();
   }

   public void reset() {
      throw new UnsupportedOperationException();
   }

   public boolean markSupported() {
      return false;
   }
}

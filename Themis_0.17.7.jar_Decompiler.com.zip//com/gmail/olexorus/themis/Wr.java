package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.regex.Pattern;

final class Wr implements V2 {
   static final Pattern A;
   static final Pattern J;
   private static final ux[] T;
   private static final Optional<AJ> O;
   static final Consumer<Vp> k;
   private final char V;
   private final char u;
   private final GB j;
   private final boolean s;
   private final boolean c;
   private final wb g;
   private final t9 C;
   private static final long a = kt.a(-746173408098698107L, -1487068178453144858L, MethodHandles.lookup().lookupClass()).a(92462375407712L);

   Wr(char var1, char var2, GB var3, boolean var4, boolean var5, wb var6, t9 var7) {
      this.V = var1;
      this.u = var2;
      this.j = var3;
      this.s = var4;
      this.c = var5;
      this.g = var6;
      this.C = var7;
   }

   private nb q(char var1, String var2, int var3) {
      if (var3 >= 14) {
         int var4 = var3 - 14;
         int var5 = var3 - 13;
         if (var2.charAt(var4) == this.V && var2.charAt(var5) == 'x') {
            return nb.BUNGEECORD_UNUSUAL_HEX;
         }
      }

      if (var1 == this.u && var2.length() - var3 >= 6) {
         return nb.KYORI_HEX;
      } else {
         return this.C.I.indexOf(var1) != -1 ? nb.MOJANG_LEGACY : null;
      }
   }

   private JX s(char var1, String var2, int var3) {
      nb var4 = this.q(var1, var2, var3);
      if (var4 == null) {
         return null;
      } else {
         if (var4 == nb.KYORI_HEX) {
            BX var5 = O(var2.substring(var3, var3 + 6));
            if (var5 != null) {
               return new JX(var4, var5, (bz)null);
            }
         } else {
            if (var4 == nb.MOJANG_LEGACY) {
               return new JX(var4, (B5)this.C.V.get(this.C.I.indexOf(var1)), (bz)null);
            }

            if (var4 == nb.BUNGEECORD_UNUSUAL_HEX) {
               StringBuilder var7 = new StringBuilder(6);

               for(int var6 = var3 - 1; var6 >= var3 - 11; var6 -= 2) {
                  var7.append(var2.charAt(var6));
               }

               BX var8 = O(var7.reverse().toString());
               if (var8 != null) {
                  return new JX(var4, var8, (bz)null);
               }
            }
         }

         return null;
      }
   }

   private static BX O(String var0) {
      try {
         int var1 = Integer.parseInt(var0, 16);
         return BX.C(var1);
      } catch (NumberFormatException var2) {
         return null;
      }
   }

   private static boolean F(B5 var0) {
      return var0 instanceof BX && !(var0 instanceof oT);
   }

   private String P(B5 var1) {
      long var2 = a ^ 95331730019876L;
      if (F((B5)var1)) {
         BX var4 = (BX)var1;
         if (this.s) {
            String var5 = String.format("%06x", var4.Y());
            if (!this.c) {
               return this.u + var5;
            }

            StringBuilder var6 = new StringBuilder(String.valueOf('x'));
            int var7 = 0;

            for(int var8 = var5.length(); var7 < var8; ++var7) {
               var6.append(this.V).append(var5.charAt(var7));
            }

            return var6.toString();
         }

         if (!(var4 instanceof oT)) {
            var1 = BX.t(this.C.u, var4);
         }
      }

      int var9 = this.C.V.indexOf(var1);
      return var9 == -1 ? null : Character.toString(this.C.I.charAt(var9));
   }

   private Aa v(Aa var1) {
      if (this.j == null) {
         return var1;
      } else {
         X var2 = var1.t(this.j);
         return var2 instanceof Aa ? (Aa)var2 : (Aa)((nh)X.p().U(var2)).m();
      }
   }

   public Aa Q(String var1) {
      int var2 = var1.lastIndexOf(this.V, var1.length() - 2);
      if (var2 == -1) {
         return this.v(X.N(var1));
      } else {
         ArrayList var3 = new ArrayList();
         nh var4 = null;
         boolean var5 = false;
         int var6 = var1.length();

         do {
            JX var7 = this.s(var1.charAt(var2 + 1), var1, var2 + 2);
            if (var7 != null) {
               int var8 = var2 + (var7.o == nb.KYORI_HEX ? 8 : 2);
               if (var8 != var6) {
                  if (var4 != null) {
                     if (var5) {
                        var3.add((Aa)var4.m());
                        var5 = false;
                        var4 = X.p();
                     } else {
                        var4 = (nh)X.p().U(var4.m());
                     }
                  } else {
                     var4 = X.p();
                  }

                  var4.P(var1.substring(var8, var6));
               } else if (var4 == null) {
                  var4 = X.p();
               }

               if (!var5) {
                  var5 = a(var4, var7.T);
               }

               if (var7.o == nb.BUNGEECORD_UNUSUAL_HEX) {
                  var2 -= 12;
               }

               var6 = var2;
            }

            var2 = var1.lastIndexOf(this.V, var2 - 1);
         } while(var2 != -1);

         if (var4 != null) {
            var3.add((Aa)var4.m());
         }

         String var9 = var6 > 0 ? var1.substring(0, var6) : "";
         if (var3.size() == 1 && var9.isEmpty()) {
            return this.v((Aa)var3.get(0));
         } else {
            Collections.reverse(var3);
            return this.v((Aa)((nh)X.p().P(var9).y(var3)).m());
         }
      }
   }

   public String o(X var1) {
      o3 var2 = new o3(this, (bz)null);
      this.g.H(var1, var2);
      return var2.toString();
   }

   private static boolean a(nh var0, B5 var1) {
      long var2 = a ^ 83220051952996L;
      if (var1 instanceof BX) {
         var0.D((BX)var1);
         return true;
      } else if (var1 instanceof ux) {
         var0.Q((ux)var1, NW.TRUE);
         return false;
      } else if (var1 instanceof bL) {
         return true;
      } else {
         throw new IllegalArgumentException(String.format("unknown format '%s'", var1.getClass()));
      }
   }

   private static Consumer lambda$static$1() {
      return Wr::lambda$static$0;
   }

   private static void lambda$static$0(Vp var0) {
   }

   static String l(Wr var0, B5 var1) {
      return var0.P(var1);
   }

   static char n(Wr var0) {
      return var0.V;
   }

   static ux[] m() {
      return T;
   }

   static {
      long var0 = a ^ 38756232518133L;
      A = Pattern.compile("(?:(https?)://)?([-\\w_.]+\\.\\w{2,})(/([A-Za-z0-9\\-._~!$&'()*+,;=:@/]|%[0-9A-Fa-f]{2})*)?");
      J = Pattern.compile("^[a-z][a-z0-9+\\-.]*:");
      T = ux.values();
      O = Je.d(AJ.class);
      k = (Consumer)O.map(AJ::U).orElseGet(Wr::lambda$static$1);
   }
}

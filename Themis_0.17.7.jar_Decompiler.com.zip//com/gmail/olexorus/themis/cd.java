package com.gmail.olexorus.themis;

public class cd extends id implements bW {
   private final Wl C;

   public cd(z2 var1, Wl var2) {
      super(var1);
      this.C = var2;
   }

   public float k(float var1) {
      return this.C.p(var1);
   }
}

package com.gmail.olexorus.themis;

import java.util.List;
import java.util.Map;
import org.bukkit.command.CommandSender;

public class cg extends c7<cg, tN> {
   protected cg(Bd var1, AM var2, tN var3, List<String> var4, int var5, Map<String, Object> var6) {
      super(var1, var2, var3, var4, var5, var6);
   }

   public CommandSender V() {
      return ((tN)this.q).s();
   }
}

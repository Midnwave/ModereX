package com.gmail.olexorus.themis;

public class yz extends lm<yz> {
   private VC n;
   private int O;
   private boolean X;

   public void t() {
      this.n = new VC(this.k(), this.I);
      this.O = this.Q();
      this.X = this.P();
   }

   public void d() {
      this.A(this.n.E(this.I));
      this.E(this.O);
      this.I(this.X);
   }

   public void e(yz var1) {
      this.n = var1.n;
      this.O = var1.O;
      this.X = var1.X;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum b2 {
   TICK_DURATION;

   private static final b2[] l;

   private static b2[] v() {
      return new b2[]{TICK_DURATION};
   }

   static {
      long var0 = kt.a(7689661294697359139L, 3639495650661564008L, MethodHandles.lookup().lookupClass()).a(209788962881252L) ^ 52792723829875L;
      TICK_DURATION = new b2("TICK_DURATION", 0);
      l = v();
   }
}

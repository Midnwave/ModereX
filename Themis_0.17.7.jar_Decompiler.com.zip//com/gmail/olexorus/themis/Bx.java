package com.gmail.olexorus.themis;

public class Bx {
   private vL W = oS.J().g().w().u();
   private m2 l;
   private i J;
   private int k;
   private RT K;
   private nD Z;
   private int w;

   public Bx() {
      this.l = CC.k;
      this.J = z1.B6;
      this.k = 1;
      this.K = null;
      this.Z = null;
      this.w = -1;
   }

   public Bx s(i var1) {
      this.J = var1;
      return this;
   }

   public Bx A(int var1) {
      this.k = var1;
      return this;
   }

   public Bx k(RT var1) {
      this.K = var1;
      return this;
   }

   public Bx B(nD var1) {
      this.Z = var1;
      return this;
   }

   public Bx k(int var1) {
      this.w = var1;
      return this;
   }

   public Bx j(lm<?> var1) {
      vL var2 = var1.R().u();
      return this.G(var2).F(var1.T());
   }

   public Bx G(vL var1) {
      this.W = var1;
      return this;
   }

   public Bx F(m2 var1) {
      this.l = var1;
      return this;
   }

   public TU a() {
      return new TU(this.J, this.k, this.K, this.Z, this.w, this.W, this.l, (Td)null);
   }
}

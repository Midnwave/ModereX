package com.gmail.olexorus.themis;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.reflect.TypeToken;
import java.util.UUID;

final class zK implements TypeAdapterFactory {
   static final Class<v1> s = v1.class;
   static final Class<X> N = X.class;
   static final Class<WR> g = WR.class;
   static final Class<Bb> O = Bb.class;
   static final Class<bj> r = bj.class;
   static final Class<or> C = or.class;
   static final Class<tY> S = tY.class;
   static final Class<String> P = String.class;
   static final Class<wn> R = wn.class;
   static final Class<BX> y = BX.class;
   static final Class<?> w;
   static final Class<ux> k = ux.class;
   static final Class<Ma> a = Ma.class;
   static final Class<UUID> z = UUID.class;
   static final Class<?> X;
   static final Class<?> F;
   private final C b;
   private final ab D;
   private final VT l;

   zK(C var1, ab var2, VT var3) {
      this.b = var1;
      this.D = var2;
      this.l = var3;
   }

   public <T> TypeAdapter<T> create(Gson var1, TypeToken<T> var2) {
      Class var3 = var2.getRawType();
      if (N.isAssignableFrom(var3)) {
         return Gx.b(this.b, var1);
      } else if (s.isAssignableFrom(var3)) {
         return tn.B;
      } else if (g.isAssignableFrom(var3)) {
         return cN.D(this.D, this.l, this.b, var1);
      } else if (O.isAssignableFrom(var3)) {
         return Rm.F;
      } else if (r.isAssignableFrom(var3)) {
         return Tl.I;
      } else if (C.isAssignableFrom(var3)) {
         return TE.O(var1, this.b);
      } else if (S.isAssignableFrom(var3)) {
         return Od.z(var1, this.b);
      } else if (R.isAssignableFrom(var3)) {
         return Cg.s;
      } else if (y.isAssignableFrom(var3)) {
         return (Boolean)this.b.x(ci.B) ? vE.n : vE.M;
      } else if (Tb.J && w.isAssignableFrom(var3)) {
         return tf.c(this.b);
      } else if (k.isAssignableFrom(var3)) {
         return M0.S;
      } else if (a.isAssignableFrom(var3)) {
         return B6.O;
      } else if (z.isAssignableFrom(var3)) {
         return Ef.S(this.b);
      } else if (Tb.Z && X.isAssignableFrom(var3)) {
         return gu.Z(var1);
      } else {
         return Tb.A && F.isAssignableFrom(var3) ? mF.R : null;
      }
   }

   static {
      X = Tb.Z ? VE.class : null;
      w = Tb.J ? Vd.class : null;
      F = Tb.A ? mx.class : null;
   }
}

package com.gmail.olexorus.themis;

public class iV extends id implements M5 {
   public iV(z2 var1) {
      super(var1);
   }
}

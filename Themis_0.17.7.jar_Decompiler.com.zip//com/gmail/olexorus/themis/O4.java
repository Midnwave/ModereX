package com.gmail.olexorus.themis;

import java.util.List;

public interface O4<E extends Enum<E>> extends List<E>, lK {
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Optional;

public interface md extends GL, uW<md>, rp {
   long a = kt.a(-3464922083841188849L, 6559534231749570408L, MethodHandles.lookup().lookupClass()).a(14194569849786L);

   String a();

   w3 C();

   float a();

   GP U();

   bv s();

   static md B(lm<?> var0) {
      return (md)var0.y((VD)V5.h());
   }

   static void f(lm<?> var0, md var1) {
      var0.j((GL)var1);
   }

   static md v(Rc var0, vL var1, z2 var2) {
      long var3 = a ^ 59288620789672L;
      RT var5 = (RT)var0;
      String var6 = ((RT)var0).N("message_id");
      w3 var7 = (w3)rN.V(w3.ID_INDEX, ((RT)var0).N("scaling"));
      float var8 = ((RT)var0).N("exhaustion").b();
      GP var9 = (GP)Optional.ofNullable(var5.c("effects")).map(md::lambda$decode$0).orElse(GP.HURT);
      bv var10 = (bv)Optional.ofNullable(var5.c("death_message_type")).map(md::lambda$decode$1).orElse(bv.DEFAULT);
      return new cp(var2, var6, var7, var8, var9, var10);
   }

   private static bv lambda$decode$1(String var0) {
      return (bv)rN.V(bv.ID_INDEX, var0);
   }

   private static GP lambda$decode$0(String var0) {
      return (GP)rN.V(GP.ID_INDEX, var0);
   }
}

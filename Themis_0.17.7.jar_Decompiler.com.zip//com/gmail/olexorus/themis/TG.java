package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.stream.Stream;

public interface TG extends d<TG, W_>, Gl<TG> {
   long b = kt.a(1431036434046214346L, 4392484258908654154L, MethodHandles.lookup().lookupClass()).a(72791977835460L);

   String T();

   default Stream<? extends rE> T() {
      long var1 = b ^ 9268513603616L;
      return Stream.concat(Stream.of(rE.c("keybind", this.T())), d.super.T());
   }
}

package com.gmail.olexorus.themis;

import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Map.Entry;

public final class zW {
   private static final N8<Wa> pR;
   private static final Map<al, RT> pt;
   public static final Wa S;
   public static final Wa a;
   public static final Wa pW;
   public static final Wa pi;
   public static final Wa p0;
   public static final Wa c;
   public static final Wa K;
   public static final Wa T;
   public static final Wa pY;
   public static final Wa R;
   public static final Wa pp;
   public static final Wa p;
   public static final Wa pC;
   public static final Wa pk;
   public static final Wa k;
   public static final Wa pg;
   public static final Wa t;
   public static final Wa pe;
   public static final Wa pa;
   public static final Wa pq;
   public static final Wa A;
   public static final Wa r;
   public static final Wa F;
   public static final Wa E;
   public static final Wa B;
   public static final Wa W;
   public static final Wa Q;
   public static final Wa G;
   public static final Wa pc;
   public static final Wa pZ;
   public static final Wa pD;
   public static final Wa po;
   public static final Wa O;
   public static final Wa pE;
   public static final Wa pv;
   public static final Wa w;
   public static final Wa pu;
   public static final Wa N;
   public static final Wa b;
   public static final Wa m;
   public static final Wa p8;
   public static final Wa D;
   public static final Wa pS;
   public static final Wa pN;
   public static final Wa f;
   public static final Wa pK;
   public static final Wa U;
   public static final Wa q;
   public static final Wa pH;
   public static final Wa d;
   public static final Wa py;
   public static final Wa h;
   public static final Wa pV;
   public static final Wa x;
   public static final Wa pU;
   public static final Wa p7;
   public static final Wa C;
   public static final Wa V;
   public static final Wa Y;
   public static final Wa pw;
   public static final Wa pL;
   public static final Wa I;
   public static final Wa M;
   public static final Wa X;
   public static final Wa p_;
   public static final Wa u;
   public static final Wa pA;
   public static final Wa p4;
   public static final Wa pl;
   public static final Wa J;
   public static final Wa s;
   public static final Wa pQ;
   public static final Wa y;
   public static final Wa pd;
   public static final Wa pM;
   public static final Wa p1;
   public static final Wa p9;
   public static final Wa pT;
   public static final Wa pI;
   public static final Wa pJ;
   public static final Wa pb;
   public static final Wa v;
   public static final Wa g;
   public static final Wa j;
   public static final Wa e;
   public static final Wa z;
   public static final Wa Z;
   public static final Wa pf;
   public static final Wa px;
   public static final Wa L;
   public static final Wa p3;
   public static final Wa H;
   public static final Wa pj;
   public static final Wa pr;
   public static final Wa pO;
   public static final Wa pP;
   public static final Wa l;
   public static final Wa P;
   public static final Wa pz;
   public static final Wa i;
   public static final Wa pX;
   public static final Wa o;
   public static final Wa n;
   private static final long ab = kt.a(-3396414126011788567L, -3964187117455891734L, MethodHandles.lookup().lookupClass()).a(30117967696088L);

   public static Wa s(String var0) {
      return H(var0, false);
   }

   public static Wa H(String var0, boolean var1) {
      return (Wa)pR.h(var0, zW::lambda$define$0);
   }

   public static N8<Wa> V() {
      return pR;
   }

   private static Wa lambda$define$0(boolean var0, z2 var1) {
      long var2 = ab ^ 27511467521601L;
      RT var4 = (RT)pt.get(var1.m());
      if (var4 != null) {
         lm var6 = lm.s(vL.n());
         return (Wa)((Wa)Wa.B.n(var4, var6)).F(var1);
      } else if (var0) {
         Mm var5 = new Mm(12638463, 4159204, 329011, 7907327, OptionalInt.empty(), OptionalInt.empty(), bs.NONE, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty());
         return new cu(var1, true, 0.8F, R2.NONE, 0.4F, (W9)null, (Float)null, (Float)null, var5, BY.x);
      } else {
         throw new IllegalArgumentException("Can't define biome " + var1.m() + ", no data found");
      }
   }

   static {
      long var0 = ab ^ 95936500772591L;
      pR = new N8("worldgen/biome");
      pt = new HashMap();

      try {
         mC var2 = com.gmail.olexorus.themis.M.v("mappings/data/worldgen/biome");

         try {
            var2.p();
            Iterator var3 = ((mC)var2.m().getValue()).iterator();

            while(var3.hasNext()) {
               Entry var4 = (Entry)var3.next();
               al var5 = new al((String)var4.getKey());
               pt.put(var5, ((mC)var4.getValue()).P());
            }
         } catch (Throwable var7) {
            if (var2 != null) {
               try {
                  var2.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (var2 != null) {
            var2.close();
         }
      } catch (IOException var8) {
         throw new RuntimeException("Error while reading biome data", var8);
      }

      S = H("snowy_mountains", true);
      a = H("giant_spruce_taiga", true);
      pW = H("badlands_plateau", true);
      pi = H("desert_hills", true);
      p0 = H("snowy_taiga_hills", true);
      c = H("dark_forest_hills", true);
      K = H("mushroom_field_shore", true);
      T = H("tall_birch_forest", true);
      pY = H("snowy_taiga_mountains", true);
      R = H("taiga_mountains", true);
      pp = H("bamboo_jungle_hills", true);
      p = H("wooded_mountains", true);
      pC = H("taiga_hills", true);
      pk = H("modified_gravelly_mountains", true);
      k = H("modified_wooded_badlands_plateau", true);
      pg = H("deep_warm_ocean", true);
      t = H("giant_tree_taiga", true);
      pe = H("modified_jungle", true);
      pa = H("tall_birch_hills", true);
      pq = H("wooded_badlands_plateau", true);
      A = H("snowy_tundra", true);
      r = H("mountains", true);
      F = H("wooded_hills", true);
      E = H("gravelly_mountains", true);
      B = H("giant_spruce_taiga_hills", true);
      W = H("modified_badlands_plateau", true);
      Q = H("jungle_hills", true);
      G = H("jungle_edge", true);
      pc = H("modified_jungle_edge", true);
      pZ = H("swamp_hills", true);
      pD = H("giant_tree_taiga_hills", true);
      po = H("shattered_savanna", true);
      O = H("mountain_edge", true);
      pE = H("desert_lakes", true);
      pv = H("birch_forest_hills", true);
      w = H("shattered_savanna_plateau", true);
      pu = H("stone_shore", true);
      N = H("nether", true);
      b = s("badlands");
      m = s("bamboo_jungle");
      p8 = s("basalt_deltas");
      D = s("beach");
      pS = s("birch_forest");
      pN = s("cherry_grove");
      f = s("cold_ocean");
      pK = s("crimson_forest");
      U = s("dark_forest");
      q = s("deep_cold_ocean");
      pH = s("deep_dark");
      d = s("deep_frozen_ocean");
      py = s("deep_lukewarm_ocean");
      h = s("deep_ocean");
      pV = s("desert");
      x = s("dripstone_caves");
      pU = s("end_barrens");
      p7 = s("end_highlands");
      C = s("end_midlands");
      V = s("eroded_badlands");
      Y = s("flower_forest");
      pw = s("forest");
      pL = s("frozen_ocean");
      I = s("frozen_peaks");
      M = s("frozen_river");
      X = s("grove");
      p_ = s("ice_spikes");
      u = s("jagged_peaks");
      pA = s("jungle");
      p4 = s("lukewarm_ocean");
      pl = s("lush_caves");
      J = s("mangrove_swamp");
      s = s("meadow");
      pQ = s("mushroom_fields");
      y = s("nether_wastes");
      pd = s("ocean");
      pM = s("old_growth_birch_forest");
      p1 = s("old_growth_pine_taiga");
      p9 = s("old_growth_spruce_taiga");
      pT = s("plains");
      pI = s("river");
      pJ = s("savanna");
      pb = s("savanna_plateau");
      v = s("small_end_islands");
      g = s("snowy_beach");
      j = s("snowy_plains");
      e = s("snowy_slopes");
      z = s("snowy_taiga");
      Z = s("soul_sand_valley");
      pf = s("sparse_jungle");
      px = s("stony_peaks");
      L = s("stony_shore");
      p3 = s("sunflower_plains");
      H = s("swamp");
      pj = s("taiga");
      pr = s("the_end");
      pO = s("the_void");
      pP = s("warm_ocean");
      l = s("warped_forest");
      P = s("windswept_forest");
      pz = s("windswept_gravelly_hills");
      i = s("windswept_hills");
      pX = s("windswept_savanna");
      o = s("wooded_badlands");
      n = s("pale_garden");
      pt.clear();
      pR.f();
   }
}

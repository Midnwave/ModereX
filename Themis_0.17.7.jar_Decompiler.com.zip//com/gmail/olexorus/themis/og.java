package com.gmail.olexorus.themis;

import java.util.Objects;

public class og {
   private int M;
   private int C;
   private CB s;
   private CB j;
   private CB c;
   private float R;
   private float J;
   private CW Q;
   private CW V;

   public og(int var1, int var2, CB var3, CB var4, CB var5, float var6, float var7, CW var8, CW var9) {
      this.M = var1;
      this.C = var2;
      this.s = var3;
      this.j = var4;
      this.c = var5;
      this.R = var6;
      this.J = var7;
      this.Q = var8;
      this.V = var9;
   }

   public static og l(lm<?> var0) {
      int var1 = var0.Q();
      int var2 = var0.Q();
      CB var3 = (CB)var0.u(CB::G);
      CB var4 = (CB)var0.u(CB::G);
      CB var5 = (CB)var0.u(CB::G);
      float var6 = var0.L();
      float var7 = var0.L();
      CW var8 = (CW)var0.u(CW::B);
      CW var9 = (CW)var0.u(CW::B);
      return new og(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   public static void L(lm<?> var0, og var1) {
      var0.E(var1.M);
      var0.E(var1.C);
      var0.l(var1.s, CB::x);
      var0.l(var1.j, CB::x);
      var0.l(var1.c, CB::x);
      var0.S(var1.R);
      var0.S(var1.J);
      var0.l(var1.Q, CW::O);
      var0.l(var1.V, CW::O);
   }

   public boolean equals(Object var1) {
      if (var1 != null && this.getClass() == var1.getClass()) {
         og var2 = (og)var1;
         if (this.M != var2.M) {
            return false;
         } else if (this.C != var2.C) {
            return false;
         } else if (Float.compare(var2.R, this.R) != 0) {
            return false;
         } else if (Float.compare(var2.J, this.J) != 0) {
            return false;
         } else if (!Objects.equals(this.s, var2.s)) {
            return false;
         } else if (!Objects.equals(this.j, var2.j)) {
            return false;
         } else if (!Objects.equals(this.c, var2.c)) {
            return false;
         } else {
            return !Objects.equals(this.Q, var2.Q) ? false : Objects.equals(this.V, var2.V);
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.M, this.C, this.s, this.j, this.c, this.R, this.J, this.Q, this.V});
   }
}

package com.gmail.olexorus.themis;

public final class NV {
   public static final NV N = new NV(1);
   public static final NV U = new NV(2);
   public static final NV y = new NV(4);
   public static final NV H = new NV(8);
   public static final NV Y = new NV(16);
   public static final NV z = new NV(32);
   public static final NV L = new NV(64);
   public static final NV S;
   private final byte j;

   public NV(int var1) {
      this.j = (byte)var1;
   }

   public NV K(NV var1) {
      return new NV(this.j | var1.j);
   }

   public byte k() {
      return this.j;
   }

   public boolean Y(byte var1) {
      return (var1 & this.j) != 0;
   }

   static {
      S = N.K(U).K(y).K(H).K(Y).K(z).K(L);
   }
}

package com.gmail.olexorus.themis;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Qf extends lm<Qf> {
   private int i;
   private UUID b;
   private V a;
   private float L;
   private float e;
   private i K;
   private List<Tw<?>> M;

   public void t() {
      this.i = this.Q();
      this.b = this.V();
      boolean var1 = this.I.i(zZ.V_1_9);
      if (var1) {
         this.a = new V(this.o(), this.o(), this.o());
      } else {
         this.a = new V((double)this.f() / 32.0D, (double)this.f() / 32.0D, (double)this.f() / 32.0D);
      }

      this.L = (float)this.M() / 0.7111111F;
      this.e = (float)this.M() / 0.7111111F;
      if (!var1) {
         this.K = z1.Z(this.I.u(), this.x());
      } else {
         this.K = z1.B6;
      }

      if (this.I.m(zZ.V_1_15)) {
         this.M = this.n();
      } else {
         this.M = new ArrayList();
      }

   }

   public void d() {
      this.E(this.i);
      this.y(this.b);
      boolean var1 = this.I.i(zZ.V_1_9);
      if (var1) {
         this.v(this.a.o());
         this.v(this.a.h());
         this.v(this.a.D());
      } else {
         this.L(a8.J(this.a.o() * 32.0D));
         this.L(a8.J(this.a.h() * 32.0D));
         this.L(a8.J(this.a.D() * 32.0D));
      }

      this.u((byte)((int)(this.L * 0.7111111F)));
      this.u((byte)((int)(this.e * 0.7111111F)));
      if (!var1) {
         this.f(this.K.f(this.I.u()));
      }

      if (this.I.m(zZ.V_1_15)) {
         this.R(this.M);
      }

   }

   public void Y(Qf var1) {
      this.i = var1.i;
      this.b = var1.b;
      this.a = var1.a;
      this.L = var1.L;
      this.e = var1.e;
      this.K = var1.K;
      this.M = var1.M;
   }
}

package com.gmail.olexorus.themis;

import java.util.Iterator;

public final class v0 {
   public static final <T> Iterator<T> N(T[] var0) {
      return (Iterator)(new n2(var0));
   }
}

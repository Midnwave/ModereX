package com.gmail.olexorus.themis;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MP {
   private o9 F;
   private List<gl<?>> O;

   public MP() {
      this(new o9(), new ArrayList());
   }

   public MP(o9 var1, List<gl<?>> var2) {
      this.F = var1;
      this.O = var2;
   }

   public static MP v(lm<?> var0) {
      o9 var1 = o9.l(var0);
      List var2 = var0.j(gl::E);
      return new MP(var1, var2);
   }

   public static void a(lm<?> var0, MP var1) {
      o9.d(var0, var1.F);
      var0.D(var1.O, gl::L);
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof MP)) {
         return false;
      } else {
         MP var2 = (MP)var1;
         return !this.F.equals(var2.F) ? false : this.O.equals(var2.O);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.F, this.O});
   }
}

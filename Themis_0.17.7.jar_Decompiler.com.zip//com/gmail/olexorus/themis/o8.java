package com.gmail.olexorus.themis;

import org.bukkit.command.CommandSender;

public class o8 extends om<tN> {
   protected o8(Bd var1, tN var2, String var3, String var4, String[] var5) {
      super(var1, var2, var3, var4, var5);
   }

   public CommandSender C() {
      return (CommandSender)this.J().Q();
   }
}

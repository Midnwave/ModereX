package com.gmail.olexorus.themis;

import java.util.Objects;

public final class BI {
   public static final tw<BI> A = (new N7()).I();
   private final CW p;
   private final int r;
   private final int a;
   private final double P;

   public BI(CW var1, int var2, int var3, double var4) {
      this.p = var1;
      this.r = var2;
      this.a = var3;
      this.P = var4;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof BI)) {
         return false;
      } else {
         BI var2 = (BI)var1;
         if (this.r != var2.r) {
            return false;
         } else if (this.a != var2.a) {
            return false;
         } else {
            return Double.compare(var2.P, this.P) != 0 ? false : this.p.equals(var2.p);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.p, this.r, this.a, this.P});
   }

   static CW A(BI var0) {
      return var0.p;
   }

   static int M(BI var0) {
      return var0.r;
   }

   static int Z(BI var0) {
      return var0.a;
   }

   static double d(BI var0) {
      return var0.P;
   }
}

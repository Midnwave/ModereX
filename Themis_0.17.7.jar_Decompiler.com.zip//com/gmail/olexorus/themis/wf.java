package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum wf {
   NETHER,
   OVERWORLD,
   END,
   CUSTOM;

   private static final wf[] m;
   private final int l;
   private final String T;

   private wf(int var3, String var4) {
      this.l = var3;
      this.T = var4;
   }

   public static boolean d(String var0) {
      return RP.FLAT.w().equals(var0);
   }

   public static boolean j(String var0) {
      return RP.DEBUG_ALL_BLOCK_STATES.w().equals(var0);
   }

   // $FF: synthetic method
   private static wf[] R() {
      return new wf[]{NETHER, OVERWORLD, END, CUSTOM};
   }

   static {
      long var0 = kt.a(-4804556190535998553L, -4909069170607108893L, MethodHandles.lookup().lookupClass()).a(262018362537358L) ^ 16662786591608L;
      NETHER = new wf("NETHER", 0, -1, "minecraft:the_nether");
      OVERWORLD = new wf("OVERWORLD", 1, 0, "minecraft:overworld");
      END = new wf("END", 2, 1, "minecraft:the_end");
      CUSTOM = new wf("CUSTOM", 3, -999, "minecraft:custom");
      m = values();
   }
}

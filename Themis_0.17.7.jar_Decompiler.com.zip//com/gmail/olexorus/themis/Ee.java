package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class Ee {
   private static final N8<Gu<?>> F;
   public static final Gu<Tn> M;
   public static final Gu<Tn> d;
   public static final Gu<Tn> U;
   public static final Gu<Tn> i;
   public static final Gu<Tn> O;
   public static final Gu<Tn> Z;
   public static final Gu<Tn> A;
   public static final Gu<Tn> f;
   public static final Gu<Tn> S;
   public static final Gu<Tn> R;
   public static final Gu<Tn> N;
   public static final Gu<Tn> n;
   public static final Gu<Tn> B;
   public static final Gu<Tn> l;

   public static <T extends gz> Gu<T> l(String var0, MO<T> var1, Gw<T> var2) {
      return (Gu)F.h(var0, Ee::lambda$define$0);
   }

   public static N8<Gu<?>> e() {
      return F;
   }

   private static iX lambda$define$0(MO var0, Gw var1, z2 var2) {
      return new iX(var2, var0, var1);
   }

   static {
      long var0 = kt.a(-7292061583631249876L, 8034688502660246978L, MethodHandles.lookup().lookupClass()).a(267011616150531L) ^ 125455857355552L;
      F = new N8("data_component_predicate_type");
      M = l("damage", Tn::H, Tn::L);
      d = l("enchantments", Tn::H, Tn::L);
      U = l("stored_enchantments", Tn::H, Tn::L);
      i = l("potion_contents", Tn::H, Tn::L);
      O = l("custom_data", Tn::H, Tn::L);
      Z = l("container", Tn::H, Tn::L);
      A = l("bundle_contents", Tn::H, Tn::L);
      f = l("firework_explosion", Tn::H, Tn::L);
      S = l("fireworks", Tn::H, Tn::L);
      R = l("writable_book_content", Tn::H, Tn::L);
      N = l("written_book_content", Tn::H, Tn::L);
      n = l("attribute_modifiers", Tn::H, Tn::L);
      B = l("trim", Tn::H, Tn::L);
      l = l("jukebox_playable", Tn::H, Tn::L);
      F.f();
   }
}

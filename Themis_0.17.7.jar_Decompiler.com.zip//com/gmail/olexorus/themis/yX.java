package com.gmail.olexorus.themis;

public class yX extends yx {
}

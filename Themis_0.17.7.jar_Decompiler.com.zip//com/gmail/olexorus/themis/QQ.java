package com.gmail.olexorus.themis;

public class QQ extends lm<QQ> {
   public static boolean R = true;
   private X P;
   private X q;

   public void t() {
      this.P = this.a();
      this.q = this.a();
   }

   public void d() {
      this.G(this.P);
      this.G(this.q);
   }

   public void a(QQ var1) {
      this.P = var1.P;
      this.q = var1.q;
   }
}

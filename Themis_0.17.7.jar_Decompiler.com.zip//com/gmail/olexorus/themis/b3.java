package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collections;
import java.util.Objects;

public final class b3 {
   private static final uk V;
   private static final N8<OC> W;
   public static final OC N;
   public static final OC C;
   public static final OC w;

   public static OC q(String var0, OC var1) {
      N8 var10000 = W;
      Objects.requireNonNull(var1);
      return (OC)var10000.h(var0, var1::F);
   }

   public static N8<OC> d() {
      return W;
   }

   static {
      long var0 = kt.a(-3303298381357119129L, 3160822665478743500L, MethodHandles.lookup().lookupClass()).a(150207924999337L) ^ 108476220542932L;
      V = new uk(new Vy(X.D("gui.back"), (X)null, 200), (T9)null);
      W = new N8("dialog");
      N = q("server_links", new i5(new i_(X.D("menu.server_links.title"), X.D("menu.server_links"), true, true, ak.CLOSE, Collections.emptyList(), Collections.emptyList()), V, 1, 310));
      C = q("custom_options", new i7(new i_(X.D("menu.custom_options.title"), X.D("menu.custom_options"), true, true, ak.CLOSE, Collections.emptyList(), Collections.emptyList()), new gC(new al("pause_screen_additions")), V, 1, 310));
      w = q("quick_actions", new i7(new i_(X.D("menu.quick_actions.title"), X.D("menu.quick_actions"), true, true, ak.CLOSE, Collections.emptyList(), Collections.emptyList()), new gC(new al("quick_actions")), V, 1, 310));
      W.f();
   }
}

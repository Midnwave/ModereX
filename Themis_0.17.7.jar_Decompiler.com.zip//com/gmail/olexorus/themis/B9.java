package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public interface B9 extends nc {
   long a = kt.a(-3059434952517496562L, -8981760696336035698L, MethodHandles.lookup().lookupClass()).a(142696974258522L);

   static wT A(v1 var0, v1 var1) {
      long var2 = a ^ 28998950186735L;
      return new zV((v1)Objects.requireNonNull(var0, "atlas"), (v1)Objects.requireNonNull(var1, "sprite"));
   }

   static wT z(v1 var0) {
      long var1 = a ^ 94281771849712L;
      return new zV(wT.Q, (v1)Objects.requireNonNull(var0, "sprite"));
   }

   static A2 O() {
      return new W6();
   }
}

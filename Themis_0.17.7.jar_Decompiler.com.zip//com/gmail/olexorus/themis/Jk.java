package com.gmail.olexorus.themis;

import java.io.Serializable;
import java.lang.invoke.MethodHandles;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public final class Jk implements List, Serializable, RandomAccess, lK {
   public static final Jk Q = new Jk();
   private static final long serialVersionUID = -7390468764508069838L;
   private static final long a = kt.a(-4744062709881517949L, 6332991329479049701L, MethodHandles.lookup().lookupClass()).a(116312669221487L);

   private Jk() {
   }

   public boolean equals(Object var1) {
      return var1 instanceof List && ((List)var1).isEmpty();
   }

   public int hashCode() {
      return 1;
   }

   public String toString() {
      long var1 = a ^ 108438114494425L;
      return "[]";
   }

   public int M() {
      return 0;
   }

   public boolean isEmpty() {
      return true;
   }

   public boolean X(Void var1) {
      return false;
   }

   public boolean containsAll(Collection var1) {
      return var1.isEmpty();
   }

   public Void b(int var1) {
      long var2 = a ^ 25880842909557L;
      throw new IndexOutOfBoundsException("Empty list doesn't contain element at index " + var1 + '.');
   }

   public int i(Void var1) {
      return -1;
   }

   public int B(Void var1) {
      return -1;
   }

   public Iterator iterator() {
      return (Iterator)rh.u;
   }

   public ListIterator listIterator() {
      return (ListIterator)rh.u;
   }

   public ListIterator listIterator(int var1) {
      long var2 = a ^ 123442859091640L;
      if (var1 != 0) {
         throw new IndexOutOfBoundsException("Index: " + var1);
      } else {
         return (ListIterator)rh.u;
      }
   }

   public List subList(int var1, int var2) {
      long var3 = a ^ 10366456062138L;
      if (var1 == 0 && var2 == 0) {
         return (List)this;
      } else {
         throw new IndexOutOfBoundsException("fromIndex: " + var1 + ", toIndex: " + var2);
      }
   }

   private final Object readResolve() {
      return Q;
   }

   public boolean addAll(int var1, Collection var2) {
      long var3 = a ^ 100148418585149L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean addAll(Collection var1) {
      long var2 = a ^ 68764952234765L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public void clear() {
      long var1 = a ^ 43865142383606L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean remove(Object var1) {
      long var2 = a ^ 33352470505161L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean removeAll(Collection var1) {
      long var2 = a ^ 118196481015009L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean retainAll(Collection var1) {
      long var2 = a ^ 87619097096325L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public <T> T[] toArray(T[] var1) {
      return z8.s((Collection)this, var1);
   }

   public Object[] toArray() {
      return z8.t((Collection)this);
   }
}

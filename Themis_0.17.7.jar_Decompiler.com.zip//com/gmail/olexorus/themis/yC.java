package com.gmail.olexorus.themis;

public class yC extends lm<yC> {
   private boolean z;

   public void t() {
      this.z = this.P();
   }

   public void d() {
      this.I(this.z);
   }

   public void l(yC var1) {
      this.z = var1.z;
   }
}

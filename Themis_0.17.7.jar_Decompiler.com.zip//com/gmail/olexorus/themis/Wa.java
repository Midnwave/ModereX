package com.gmail.olexorus.themis;

public interface Wa extends GL, uW<Wa>, rp {
   tw<Wa> B = (new bS()).I();

   boolean l();

   ia c();

   float h();

   R2 B();

   float Z();

   W9 N();

   Float L();

   Float q();

   Mm K();

   BY R();
}

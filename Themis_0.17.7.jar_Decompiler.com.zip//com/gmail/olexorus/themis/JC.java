package com.gmail.olexorus.themis;

public final class JC {
   public static final JC W = new JC();

   private JC() {
   }

   public static JC b(lm<?> var0) {
      return W;
   }

   public static void i(lm<?> var0, JC var1) {
   }
}

package com.gmail.olexorus.themis;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

class cn implements bg<BY> {
   public BY j(RT var1, lm<?> var2) {
      N8 var3 = Bg.d();
      vL var4 = var2.R().u();
      HashMap var5 = new HashMap();
      Iterator var6 = var1.d().iterator();

      while(var6.hasNext()) {
         String var7 = (String)var6.next();
         Jf var8 = (Jf)var3.F(var4, var7);
         if (var8.i()) {
            var5.put(var8, (r4)var1.g(var7, r4.V(var8), var2));
         }
      }

      return new BY(var5, (cn)null);
   }

   public void t(RT var1, lm<?> var2, BY var3) {
      Iterator var4 = BY.P(var3).entrySet().iterator();

      while(var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         if (((Jf)var5.getKey()).i()) {
            this.q(var1, (Jf)var5.getKey(), (r4)var5.getValue(), var2);
         }
      }

   }

   private <T> void q(RT var1, Jf<?> var2, r4<T, ?> var3, lm<?> var4) {
      var1.X(var2.f().toString(), var3, r4.V(var2), var4);
   }
}

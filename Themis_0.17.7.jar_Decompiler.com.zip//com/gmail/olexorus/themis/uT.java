package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class uT extends us<uT> {
   private tO<?> F;
   private tO<?> z;
   private tO<?> s;
   private tO<?> n;
   private tO<?> r;
   private static final long a = kt.a(2708491904514811341L, 5219443669343874759L, MethodHandles.lookup().lookupClass()).a(276578069831856L);

   public uT(tO<?> var1, tO<?> var2, tO<?> var3, tO<?> var4, tO<?> var5) {
      super(vD.C);
      this.F = var1;
      this.z = var2;
      this.s = var3;
      this.n = var4;
      this.r = var5;
   }

   public static uT B(lm<?> var0) {
      tO var1 = tO.X(var0);
      tO var2 = tO.X(var0);
      tO var3 = tO.X(var0);
      tO var4 = tO.X(var0);
      tO var5 = tO.X(var0);
      return new uT(var1, var2, var3, var4, var5);
   }

   public static void Y(lm<?> var0, uT var1) {
      tO.A(var0, var1.F);
      tO.A(var0, var1.z);
      tO.A(var0, var1.s);
      tO.A(var0, var1.n);
      tO.A(var0, var1.r);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof uT)) {
         return false;
      } else {
         uT var2 = (uT)var1;
         if (!this.F.equals(var2.F)) {
            return false;
         } else if (!this.z.equals(var2.z)) {
            return false;
         } else if (!this.s.equals(var2.s)) {
            return false;
         } else {
            return !this.n.equals(var2.n) ? false : this.r.equals(var2.r);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.F, this.z, this.s, this.n, this.r});
   }

   public String toString() {
      long var1 = a ^ 5055917969402L;
      return "SmithingRecipeDisplay{template=" + this.F + ", base=" + this.z + ", addition=" + this.s + ", result=" + this.n + ", craftingStation=" + this.r + '}';
   }
}

package com.gmail.olexorus.themis;

public class yY extends lm<yY> {
   private float B;
   private float i;
   private byte n;

   public void t() {
      this.B = this.L();
      this.i = this.L();
      this.n = this.M();
   }

   public void d() {
      this.S(this.B);
      this.S(this.i);
      this.u(this.n);
   }

   public void P(yY var1) {
      this.B = var1.B;
      this.i = var1.i;
      this.n = var1.n;
   }
}

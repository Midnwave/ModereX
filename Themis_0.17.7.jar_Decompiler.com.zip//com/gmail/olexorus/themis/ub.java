package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum ub {
   ADD_PLAYER,
   INITIALIZE_CHAT,
   UPDATE_GAME_MODE,
   UPDATE_LISTED,
   UPDATE_LATENCY,
   UPDATE_DISPLAY_NAME,
   UPDATE_LIST_ORDER,
   UPDATE_HAT;

   public static final ub[] VALUES;
   private static final ub[] r;

   private static ub[] l() {
      return new ub[]{ADD_PLAYER, INITIALIZE_CHAT, UPDATE_GAME_MODE, UPDATE_LISTED, UPDATE_LATENCY, UPDATE_DISPLAY_NAME, UPDATE_LIST_ORDER, UPDATE_HAT};
   }

   static {
      long var0 = kt.a(-1940657388592530517L, 4918980041888961441L, MethodHandles.lookup().lookupClass()).a(243554439070559L) ^ 63836363032747L;
      ADD_PLAYER = new ub("ADD_PLAYER", 0);
      INITIALIZE_CHAT = new ub("INITIALIZE_CHAT", 1);
      UPDATE_GAME_MODE = new ub("UPDATE_GAME_MODE", 2);
      UPDATE_LISTED = new ub("UPDATE_LISTED", 3);
      UPDATE_LATENCY = new ub("UPDATE_LATENCY", 4);
      UPDATE_DISPLAY_NAME = new ub("UPDATE_DISPLAY_NAME", 5);
      UPDATE_LIST_ORDER = new ub("UPDATE_LIST_ORDER", 6);
      UPDATE_HAT = new ub("UPDATE_HAT", 7);
      r = l();
      VALUES = values();
   }
}

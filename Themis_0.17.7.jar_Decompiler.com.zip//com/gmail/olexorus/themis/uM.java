package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.stream.Stream;

public interface uM extends d<uM, V_>, Gl<uM> {
   long b = kt.a(7348554588024888237L, -3301144653558665213L, MethodHandles.lookup().lookupClass()).a(198180982070135L);

   String e();

   String E();

   String B();

   default Stream<? extends rE> T() {
      long var1 = b ^ 18938747994324L;
      return Stream.concat(Stream.of(rE.c("name", this.e()), rE.c("objective", this.E()), rE.c("value", this.B())), d.super.T());
   }
}

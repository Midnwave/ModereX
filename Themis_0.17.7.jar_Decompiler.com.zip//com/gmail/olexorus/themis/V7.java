package com.gmail.olexorus.themis;

public final class V7 {
   public static final <A, B> z0<A, B> w(A var0, B var1) {
      return new z0(var0, var1);
   }
}

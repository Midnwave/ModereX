package com.gmail.olexorus.themis;

import java.util.UUID;

public class yH extends lm<yH> {
   private UUID h;

   public void t() {
      this.h = this.V();
   }

   public void d() {
      this.y(this.h);
   }

   public void d(yH var1) {
      this.h = var1.h;
   }
}

package com.gmail.olexorus.themis;

import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;

class VM extends ChannelInitializer<Channel> {
   final BV l;

   VM(BV var1) {
      this.l = var1;
   }

   protected void initChannel(Channel var1) {
      GR.K(var1, uy.HANDSHAKING);
   }
}

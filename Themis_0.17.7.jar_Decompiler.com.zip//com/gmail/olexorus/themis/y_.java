package com.gmail.olexorus.themis;

public class y_ extends lm<y_> {
   private int D;
   private TU E;

   public void t() {
      this.D = this.I.i(zZ.V_1_20_5) ? this.C() : this.x();
      this.E = this.I.i(zZ.V_1_21_5) ? n1.S(this) : n1.A(this);
   }

   public void d() {
      this.f(this.D);
      if (this.I.i(zZ.V_1_21_5)) {
         n1.L(this, this.E);
      } else {
         n1.w(this, this.E);
      }

   }

   public void U(y_ var1) {
      this.D = var1.D;
      this.E = var1.E;
   }
}

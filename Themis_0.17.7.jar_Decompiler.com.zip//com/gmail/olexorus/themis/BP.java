package com.gmail.olexorus.themis;

public final class BP {
   private final AI r;

   public BP(AI var1) {
      this.r = var1;
   }

   public static BP u(lm<?> var0) {
      AI var1 = (AI)var0.w((Enum[])AI.values());
      return new BP(var1);
   }

   public static void b(lm<?> var0, BP var1) {
      var0.o((Enum)var1.r);
   }
}

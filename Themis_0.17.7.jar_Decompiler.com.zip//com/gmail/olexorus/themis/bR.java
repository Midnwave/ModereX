package com.gmail.olexorus.themis;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;

public class bR {
   private i V;
   private i c;
   private i o;
   private i b;

   private bR(Queue<Optional<i>> var1) {
      this(var1.isEmpty() ? null : (i)((Optional)var1.remove()).orElse((Object)null), var1.isEmpty() ? null : (i)((Optional)var1.remove()).orElse((Object)null), var1.isEmpty() ? null : (i)((Optional)var1.remove()).orElse((Object)null), var1.isEmpty() ? null : (i)((Optional)var1.remove()).orElse((Object)null));
   }

   public bR(i var1, i var2, i var3, i var4) {
      this.V = var1;
      this.c = var2;
      this.o = var3;
      this.b = var4;
   }

   private List<Optional<i>> v() {
      return Arrays.asList(Optional.ofNullable(this.V), Optional.ofNullable(this.c), Optional.ofNullable(this.o), Optional.ofNullable(this.b));
   }

   private static Optional<i> p(lm<?> var0) {
      i var1 = (i)var0.e(z1::Z);
      return var1 == z1.ZM ? Optional.empty() : Optional.of(var1);
   }

   public static bR W(lm<?> var0) {
      Queue var1 = (Queue)var0.U(ArrayDeque::new, bR::p);
      return new bR(var1);
   }

   private static void T(lm<?> var0, Optional<i> var1) {
      var0.j((GL)var1.orElse(z1.ZM));
   }

   public static void E(lm<?> var0, bR var1) {
      var0.D(var1.v(), bR::T);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof bR)) {
         return false;
      } else {
         bR var2 = (bR)var1;
         if (!Objects.equals(this.V, var2.V)) {
            return false;
         } else if (!Objects.equals(this.c, var2.c)) {
            return false;
         } else {
            return !Objects.equals(this.o, var2.o) ? false : Objects.equals(this.b, var2.b);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.V, this.c, this.o, this.b});
   }
}

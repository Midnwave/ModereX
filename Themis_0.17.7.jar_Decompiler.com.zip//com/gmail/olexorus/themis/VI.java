package com.gmail.olexorus.themis;

public interface VI<T extends oh> extends GL {
   T J(lm<?> var1);

   void c(lm<?> var1, T var2);

   T h(RT var1, vL var2);

   void t(T var1, vL var2, RT var3);

   private default void lambda$writeDataFunction$0(lm var1, oh var2) {
      this.c(var1, var2);
   }
}

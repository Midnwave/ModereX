package com.gmail.olexorus.themis;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

public class zp<T> {
   private final Function<T, Locale> K;
   private Locale l;
   private final Map<Locale, C_> R = new HashMap();

   zp(Function<T, Locale> var1, Locale var2) {
      this.K = var1;
      this.l = var2;
   }

   public static <T> zp<T> Q(Function<T, Locale> var0) {
      return new zp(var0, Locale.ENGLISH);
   }

   public Locale t() {
      return this.l;
   }

   public boolean f(ClassLoader var1, String var2, Locale... var3) {
      if (var3.length == 0) {
         var3 = new Locale[]{this.l};
      }

      boolean var4 = false;
      Locale[] var5 = var3;
      int var6 = var3.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         Locale var8 = var5[var7];
         if (this.C(var8).A(var1, var2)) {
            var4 = true;
         }
      }

      return var4;
   }

   public String f(T var1, Oh var2) {
      Locale var3 = (Locale)this.K.apply(var1);
      String var4 = this.C(var3).r(var2);
      if (var4 == null && !var3.getCountry().isEmpty()) {
         var4 = this.C(new Locale(var3.getLanguage())).r(var2);
      }

      if (var4 == null && !Objects.equals(var3, this.l)) {
         var4 = this.C(this.l).r(var2);
      }

      return var4;
   }

   public C_ C(Locale var1) {
      return (C_)this.R.computeIfAbsent(var1, C_::new);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class k {
   private static vh[] W;
   private static final long a = kt.a(-4287501240401507066L, -4301797986845765048L, MethodHandles.lookup().lookupClass()).a(240147789746168L);

   private k() {
   }

   public final Themis n(Object[] param1) {
      // $FF: Couldn't be decompiled
   }

   public final boolean f(Object[] var1) {
      return Themis.N(new Object[0]);
   }

   public final boolean M(Object[] var1) {
      return Themis.h(new Object[0]);
   }

   public k(MH var1) {
      this();
   }

   public static void R(vh[] var0) {
      W = var0;
   }

   public static vh[] r() {
      return W;
   }

   static {
      if (r() == null) {
         R(new vh[5]);
      }

   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}

package com.gmail.olexorus.themis;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public interface uV {
   Map<UUID, Object> w = new ConcurrentHashMap();
   Map<Object, Gs> P = new ConcurrentHashMap();

   default Collection<Gs> f() {
      return P.values();
   }

   void x(Object var1, Object var2);

   default void n(Object var1, Object... var2) {
      Object[] var3 = var2;
      int var4 = var2.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         Object var6 = var3[var5];
         this.x(var1, var6);
      }

   }

   default Object[] X(lm<?> var1, Object var2, boolean var3) {
      lm[] var4 = O3.G(var1);
      Object[] var5 = new Object[var4.length];

      for(int var6 = 0; var6 < var4.length; ++var6) {
         lm var7 = var4[var6];
         synchronized(var7.l) {
            var7.R(var2, var3);
            var5[var6] = var7.g;
            var7.g = null;
         }
      }

      return var5;
   }

   default void l(Object var1, lm<?> var2) {
      Object[] var3 = this.X(var2, var1, true);
      this.n(var1, var3);
   }

   default Gs p(Object var1) {
      Object var2 = lC.E(var1);
      return (Gs)P.get(var2);
   }

   default Gs n(Object var1) {
      Object var2 = lC.E(var1);
      return (Gs)P.remove(var2);
   }

   default void o(Object var1, Gs var2) {
      synchronized(var1) {
         Object var4 = lC.E(var1);
         P.put(var4, var2);
      }

      oS.J().L().n(var1, var2);
   }

   default Object b(UUID var1) {
      return w.get(var1);
   }

   default void a(UUID var1, Object var2) {
      w.put(var1, var2);
   }

   default void s(Object var1) {
      w.values().remove(var1);
   }

   default void p(UUID var1) {
      w.remove(var1);
   }
}

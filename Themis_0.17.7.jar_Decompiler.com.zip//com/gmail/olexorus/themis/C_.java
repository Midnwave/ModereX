package com.gmail.olexorus.themis;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class C_ {
   private final Locale f;
   private final Map<Oh, String> s = new HashMap();

   C_(Locale var1) {
      this.f = var1;
   }

   public String l(Oh var1, String var2) {
      return (String)this.s.put(var1, var2);
   }

   public String r(Oh var1) {
      return (String)this.s.get(var1);
   }

   public boolean A(ClassLoader var1, String var2) {
      try {
         return this.H(ResourceBundle.getBundle(var2, this.f, var1, new AD()));
      } catch (MissingResourceException var4) {
         return false;
      }
   }

   public boolean H(ResourceBundle var1) {
      Iterator var2 = var1.keySet().iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         this.l(Oh.P(var3), var1.getString(var3));
      }

      return !var1.keySet().isEmpty();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class vK implements R9 {
   private final String D;
   private static final long a = kt.a(3382996584963595529L, 4922614711521374221L, MethodHandles.lookup().lookupClass()).a(100050818340708L);

   public vK(String var1) {
      this.D = var1;
   }

   public static vK V(RT var0, lm<?> var1) {
      long var2 = a ^ 135151717379918L;
      String var4 = var0.N("value");
      return new vK(var4);
   }

   public static void Y(RT var0, lm<?> var1, vK var2) {
      long var3 = a ^ 56087085975650L;
      var0.j("value", new mZ(var2.D));
   }

   public Ov<?> w() {
      return vs.o;
   }
}

package com.gmail.olexorus.themis;

public interface Vt<P1, P2, R> extends Ol<R> {
   R d(P1 var1, P2 var2);
}

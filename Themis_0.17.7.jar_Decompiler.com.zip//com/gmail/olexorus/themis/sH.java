package com.gmail.olexorus.themis;

public class sH extends lm<sH> {
   private int E;

   public void t() {
      this.E = this.Q();
   }

   public void d() {
      this.E(this.E);
   }

   public void C(sH var1) {
      this.E = var1.E;
   }
}

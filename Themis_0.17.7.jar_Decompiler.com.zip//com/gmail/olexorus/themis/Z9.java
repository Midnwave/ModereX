package com.gmail.olexorus.themis;

import java.util.HashSet;
import java.util.Set;

public class Z9 extends lm<Z9> {
   private Set<al> P;

   public void t() {
      this.P = (Set)this.U(HashSet::new, lm::R);
   }

   public void d() {
      this.d(this.P, lm::T);
   }

   public void m(Z9 var1) {
      this.P = var1.P;
   }
}

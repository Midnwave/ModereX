package com.gmail.olexorus.themis;

import org.bukkit.plugin.Plugin;

public class Gk {
   private static vX<Plugin> w;

   public static vX<Plugin> T(Plugin var0) {
      if (w == null) {
         w = j(var0);
      }

      return w;
   }

   public static vX<Plugin> j(Plugin var0) {
      return k(var0, new lo());
   }

   public static vX<Plugin> k(Plugin var0, lo var1) {
      return new vB(var1, var0);
   }
}

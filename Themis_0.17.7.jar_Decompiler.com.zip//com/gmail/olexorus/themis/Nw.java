package com.gmail.olexorus.themis;

import java.util.HashMap;
import java.util.Map;

public class Nw<I extends bJ> {
   private final I V;
   private final String X;
   private final Map<String, String> z;

   Nw(I var1, String var2) {
      this.V = var1;
      this.X = var2;
      this.z = new HashMap();
      if (var2 != null) {
         String[] var3 = nQ.D.split(var2);
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            String var6 = var3[var5];
            String[] var7 = nQ.R.split(var6, 2);
            this.z.put(var7[0], var7.length > 1 ? var7[1] : null);
         }
      }

   }
}

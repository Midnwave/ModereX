package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;

public class oA extends oh implements wG {
   private final int[] Z;
   private static final long a = kt.a(-3207820184974466618L, -7479676286032418144L, MethodHandles.lookup().lookupClass()).a(3075246040713L);

   public static oA N(int var0) {
      int[] var1 = new int[W(var0)];
      Arrays.fill(var1, 0);
      return new oA(var1);
   }

   public static oA a(int var0, int var1) {
      return new oA(new int[]{var0, var1});
   }

   public static oA h(int var0) {
      return new oA(new int[]{var0});
   }

   oA(int... var1) {
      this.Z = var1;
   }

   public void M(int var1) {
      long var2 = a ^ 67360764995744L;
      if (this.Z.length != W(var1)) {
         throw new IllegalArgumentException("Invalid size for type " + var1 + ": " + this.Z.length);
      }
   }

   public static int W(int var0) {
      if (var0 == 36) {
         return 2;
      } else {
         return var0 != 37 && var0 != 38 && var0 != 46 ? 0 : 1;
      }
   }

   public static oA K(lm<?> var0, int var1) {
      int[] var2 = new int[W(var1)];

      for(int var3 = 0; var3 < var2.length; ++var3) {
         var2[var3] = var0.Q();
      }

      return new oA(var2);
   }

   public static void N(lm<?> var0, int var1, oA var2) {
      var2.M(var1);

      for(int var3 = 0; var3 < var2.Z.length; ++var3) {
         var0.E(var2.Z[var3]);
      }

   }

   public boolean p() {
      return false;
   }

   public oA D(vL var1) {
      return new oA(this.Z);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class O1 extends Or {
   private static final long a = kt.a(-8573514704301541395L, 1510595733914133285L, MethodHandles.lookup().lookupClass()).a(46713720632564L);

   public static final String I(String var0, char... var1) {
      boolean var3 = false;
      CharSequence var4 = (CharSequence)var0;
      boolean var5 = false;
      int var6 = 0;
      int var7 = var4.length() - 1;
      boolean var8 = false;

      while(var6 <= var7) {
         int var9 = !var8 ? var6 : var7;
         char var10 = var4.charAt(var9);
         boolean var11 = false;
         boolean var12 = Ej.L(var1, var10);
         if (!var8) {
            if (!var12) {
               var8 = true;
            } else {
               ++var6;
            }
         } else {
            if (!var12) {
               break;
            }

            --var7;
         }
      }

      return var4.subSequence(var6, var7 + 1).toString();
   }

   public static final int g(CharSequence var0) {
      return var0.length() - 1;
   }

   public static final String i(CharSequence var0, GK var1) {
      return var0.subSequence(var1.f(), var1.y() + 1).toString();
   }

   public static final boolean z(CharSequence var0, int var1, CharSequence var2, int var3, int var4, boolean var5) {
      if (var3 >= 0 && var1 >= 0 && var1 <= var0.length() - var4 && var3 <= var2.length() - var4) {
         for(int var6 = 0; var6 < var4; ++var6) {
            if (!tM.L(var0.charAt(var1 + var6), var2.charAt(var3 + var6), var5)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private static final int z(CharSequence var0, CharSequence var1, int var2, int var3, boolean var4, boolean var5) {
      G0 var6 = !var5 ? (G0)(new GK(W3.u(var2, 0), W3.e(var3, var0.length()))) : W3.Y(W3.e(var2, OR.g(var0)), W3.u(var3, 0));
      int var7;
      int var8;
      int var9;
      if (var0 instanceof String && var1 instanceof String) {
         var7 = var6.Y();
         var8 = var6.W();
         var9 = var6.L();
         if (var9 > 0 && var7 <= var8 || var9 < 0 && var8 <= var7) {
            while(true) {
               if (OR.T((String)var1, 0, (String)var0, var7, var1.length(), var4)) {
                  return var7;
               }

               if (var7 == var8) {
                  break;
               }

               var7 += var9;
            }
         }
      } else {
         var7 = var6.Y();
         var8 = var6.W();
         var9 = var6.L();
         if (var9 > 0 && var7 <= var8 || var9 < 0 && var8 <= var7) {
            while(true) {
               if (OR.z(var1, 0, var0, var7, var1.length(), var4)) {
                  return var7;
               }

               if (var7 == var8) {
                  break;
               }

               var7 += var9;
            }
         }
      }

      return -1;
   }

   static int I(CharSequence var0, CharSequence var1, int var2, int var3, boolean var4, boolean var5, int var6, Object var7) {
      if ((var6 & 16) != 0) {
         var5 = false;
      }

      return z(var0, var1, var2, var3, var4, var5);
   }

   private static final z0<Integer, String> T(CharSequence var0, Collection<String> var1, int var2, boolean var3, boolean var4) {
      int var6;
      if (!var3 && var1.size() == 1) {
         String var16 = (String)wF.R((Iterable)var1);
         var6 = !var4 ? OR.v(var0, var16, var2, false, 4, (Object)null) : OR.T(var0, var16, var2, false, 4, (Object)null);
         return var6 < 0 ? null : V7.w(var6, var16);
      } else {
         G0 var5 = !var4 ? (G0)(new GK(W3.u(var2, 0), var0.length())) : W3.Y(W3.e(var2, OR.g(var0)), 0);
         int var7;
         int var8;
         String var9;
         Iterable var10;
         boolean var11;
         Iterator var12;
         Object var13;
         String var14;
         boolean var15;
         Object var10000;
         if (var0 instanceof String) {
            var6 = var5.Y();
            var7 = var5.W();
            var8 = var5.L();
            if (var8 > 0 && var6 <= var7 || var8 < 0 && var7 <= var6) {
               while(true) {
                  var10 = (Iterable)var1;
                  var11 = false;
                  var12 = var10.iterator();

                  while(true) {
                     if (!var12.hasNext()) {
                        var10000 = null;
                        break;
                     }

                     var13 = var12.next();
                     var14 = (String)var13;
                     var15 = false;
                     if (OR.T(var14, 0, (String)var0, var6, var14.length(), var3)) {
                        var10000 = var13;
                        break;
                     }
                  }

                  var9 = (String)var10000;
                  if (var9 != null) {
                     return V7.w(var6, var9);
                  }

                  if (var6 == var7) {
                     break;
                  }

                  var6 += var8;
               }
            }
         } else {
            var6 = var5.Y();
            var7 = var5.W();
            var8 = var5.L();
            if (var8 > 0 && var6 <= var7 || var8 < 0 && var7 <= var6) {
               while(true) {
                  var10 = (Iterable)var1;
                  var11 = false;
                  var12 = var10.iterator();

                  while(true) {
                     if (!var12.hasNext()) {
                        var10000 = null;
                        break;
                     }

                     var13 = var12.next();
                     var14 = (String)var13;
                     var15 = false;
                     if (OR.z((CharSequence)var14, 0, var0, var6, var14.length(), var3)) {
                        var10000 = var13;
                        break;
                     }
                  }

                  var9 = (String)var10000;
                  if (var9 != null) {
                     return V7.w(var6, var9);
                  }

                  if (var6 == var7) {
                     break;
                  }

                  var6 += var8;
               }
            }
         }

         return null;
      }
   }

   public static final int J(CharSequence var0, String var1, int var2, boolean var3) {
      return !var3 && var0 instanceof String ? ((String)var0).indexOf(var1, var2) : I(var0, (CharSequence)var1, var2, var0.length(), var3, false, 16, (Object)null);
   }

   public static int v(CharSequence var0, String var1, int var2, boolean var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return OR.J(var0, var1, var2, var3);
   }

   public static final int a(CharSequence var0, String var1, int var2, boolean var3) {
      return !var3 && var0 instanceof String ? ((String)var0).lastIndexOf(var1, var2) : z(var0, (CharSequence)var1, var2, 0, var3, true);
   }

   public static int T(CharSequence var0, String var1, int var2, boolean var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = OR.g(var0);
      }

      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return OR.a(var0, var1, var2, var3);
   }

   public static final boolean d(CharSequence var0, CharSequence var1, boolean var2) {
      return var1 instanceof String ? OR.v(var0, (String)var1, 0, var2, 2, (Object)null) >= 0 : I(var0, var1, 0, var0.length(), var2, false, 16, (Object)null) >= 0;
   }

   public static boolean Y(CharSequence var0, CharSequence var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return OR.d(var0, var1, var2);
   }

   private static final EL<GK> b(CharSequence var0, String[] var1, int var2, boolean var3, int var4) {
      OR.k(var4);
      List var5 = Ej.J(var1);
      return (EL)(new zP(var0, var2, var4, (Vt)(new ni(var5, var3))));
   }

   static EL X(CharSequence var0, String[] var1, int var2, boolean var3, int var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var2 = 0;
      }

      if ((var5 & 4) != 0) {
         var3 = false;
      }

      if ((var5 & 8) != 0) {
         var4 = 0;
      }

      return b(var0, var1, var2, var3, var4);
   }

   public static final void k(int var0) {
      long var1 = a ^ 45390429008960L;
      boolean var3 = var0 >= 0;
      if (!var3) {
         boolean var4 = false;
         String var5 = "Limit must be non-negative, but was " + var0;
         throw new IllegalArgumentException(var5.toString());
      }
   }

   public static final List<String> a(CharSequence var0, String[] var1, boolean var2, int var3) {
      if (var1.length == 1) {
         String var4 = var1[0];
         if (((CharSequence)var4).length() != 0) {
            return F(var0, var4, var2, var3);
         }
      }

      Iterable var14 = JE.G(X(var0, var1, 0, var2, var3, 2, (Object)null));
      boolean var5 = false;
      Collection var7 = (Collection)(new ArrayList(wF.w(var14, 10)));
      boolean var8 = false;
      Iterator var9 = var14.iterator();

      while(var9.hasNext()) {
         Object var10 = var9.next();
         GK var11 = (GK)var10;
         boolean var12 = false;
         var7.add(OR.i(var0, var11));
      }

      return (List)var7;
   }

   public static List U(CharSequence var0, String[] var1, boolean var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = false;
      }

      if ((var4 & 4) != 0) {
         var3 = 0;
      }

      return OR.a(var0, var1, var2, var3);
   }

   private static final List<String> F(CharSequence var0, String var1, boolean var2, int var3) {
      OR.k(var3);
      int var4 = 0;
      int var5 = OR.J(var0, var1, var4, var2);
      if (var5 != -1 && var3 != 1) {
         boolean var6 = var3 > 0;
         ArrayList var7 = new ArrayList(var6 ? W3.e(var3, 10) : 10);

         do {
            var7.add(var0.subSequence(var4, var5).toString());
            var4 = var5 + var1.length();
            if (var6 && var7.size() == var3 - 1) {
               break;
            }

            var5 = OR.J(var0, var1, var4, var2);
         } while(var5 != -1);

         var7.add(var0.subSequence(var4, var0.length()).toString());
         return (List)var7;
      } else {
         return wF.n(var0.toString());
      }
   }

   public static final z0 x(CharSequence var0, Collection var1, int var2, boolean var3, boolean var4) {
      return T(var0, var1, var2, var3, var4);
   }
}

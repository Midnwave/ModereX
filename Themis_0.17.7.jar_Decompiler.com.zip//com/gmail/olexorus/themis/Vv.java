package com.gmail.olexorus.themis;

public interface Vv<C, V> extends vr<wt<C, V>> {
   Vv<C, V> T(boolean var1);

   Vv<C, V> A(Class<? extends C> var1, V var2);
}

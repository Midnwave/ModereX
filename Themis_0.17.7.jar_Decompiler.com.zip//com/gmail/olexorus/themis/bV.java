package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum bV {
   ALWAYS,
   NEVER,
   HIDE_FOR_OTHER_TEAMS,
   HIDE_FOR_OWN_TEAM;

   private final String x;
   private static final bV[] V;

   private bV(String var3) {
      this.x = var3;
   }

   public static bV h(String var0) {
      bV[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         bV var4 = var1[var3];
         if (var4.x.equalsIgnoreCase(var0)) {
            return var4;
         }
      }

      return null;
   }

   public String O() {
      return this.x;
   }

   private static bV[] p() {
      return new bV[]{ALWAYS, NEVER, HIDE_FOR_OTHER_TEAMS, HIDE_FOR_OWN_TEAM};
   }

   static String I(bV var0) {
      return var0.x;
   }

   static {
      long var0 = kt.a(5189763728404839080L, -8158778540153445554L, MethodHandles.lookup().lookupClass()).a(236224385659795L) ^ 19248100560645L;
      ALWAYS = new bV("ALWAYS", 0, "always");
      NEVER = new bV("NEVER", 1, "never");
      HIDE_FOR_OTHER_TEAMS = new bV("HIDE_FOR_OTHER_TEAMS", 2, "hideForOtherTeams");
      HIDE_FOR_OWN_TEAM = new bV("HIDE_FOR_OWN_TEAM", 3, "hideForOwnTeam");
      V = p();
   }
}

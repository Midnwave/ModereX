package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class Vw {
   private static final N8<aB<?>> o;
   public static final aB<mf> n;
   public static final aB<N0> K;
   public static final aB<t5> b;

   public static N8<aB<?>> J() {
      return o;
   }

   public static <T extends Mn> aB<T> Y(String var0, MO<T> var1, Gw<T> var2) {
      return (aB)o.h(var0, Vw::lambda$define$0);
   }

   private static ca lambda$define$0(MO var0, Gw var1, z2 var2) {
      return new ca(var2, var0, var1);
   }

   static {
      long var0 = kt.a(7430943314692036616L, -5098059240407266905L, MethodHandles.lookup().lookupClass()).a(87992935694216L) ^ 130041926567495L;
      o = new N8("number_format_type");
      n = Y("blank", mf::u, mf::b);
      K = Y("styled", N0::I, N0::Z);
      b = Y("fixed", t5::K, t5::C);
      o.f();
   }
}

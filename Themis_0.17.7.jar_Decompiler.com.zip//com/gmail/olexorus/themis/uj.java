package com.gmail.olexorus.themis;

public final class uj extends RuntimeException {
   private static final long serialVersionUID = -5413304087321449434L;
   private final String j;
   private final String t;

   uj(String var1, String var2, String var3) {
      super(var3);
      this.j = var1;
      this.t = var2;
   }
}

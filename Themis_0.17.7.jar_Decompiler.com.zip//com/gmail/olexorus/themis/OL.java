package com.gmail.olexorus.themis;

public interface OL extends lv {
   VE Q();

   default X T() {
      return this.Q().T();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Locale;

public class lH extends lM {
   private final wr N;
   private static final long a = kt.a(-3261608202230632020L, 5848558736519337545L, MethodHandles.lookup().lookupClass()).a(87543520218953L);

   public lH(wr var1) {
      super(var1);
      this.N = var1;
      this.u(this.N.W().getClass().getClassLoader());
   }

   public void r() {
      long var1 = a ^ 34621732942920L;
      super.r();
      String var3 = "acf-" + this.N.q.getDescription().getName();
      this.f(new String[]{"acf-minecraft", var3, var3.toLowerCase(Locale.ENGLISH)});
   }
}

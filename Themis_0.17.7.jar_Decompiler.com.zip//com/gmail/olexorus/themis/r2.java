package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public final class r2 {
   private final int F;
   private final int u;
   private static final long a = kt.a(7812271396530460165L, 1706259975045312451L, MethodHandles.lookup().lookupClass()).a(177019538966952L);

   public r2(int var1, int var2) {
      this.F = var1;
      this.u = var2;
   }

   public static r2 h(Rc var0, lm<?> var1) {
      long var2 = a ^ 60376504795692L;
      RT var4 = (RT)var0;
      int var5 = var4.N("base").P();
      int var6 = var4.N("per_level_above_first").P();
      return new r2(var5, var6);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof r2)) {
         return false;
      } else {
         r2 var2 = (r2)var1;
         if (this.F != var2.F) {
            return false;
         } else {
            return this.u == var2.u;
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.F, this.u});
   }

   public String toString() {
      long var1 = a ^ 130224266705983L;
      return "EnchantmentCost{base=" + this.F + ", perLevelAboveFirst=" + this.u + '}';
   }
}

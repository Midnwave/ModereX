package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Set;

public enum mb {
   COLOR,
   SHADOW_COLOR,
   DECORATIONS,
   EVENTS,
   INSERTION,
   FONT;

   static final Set<mb> l;
   static final Set<mb> P;
   private static final mb[] Q;

   public static Set<mb> Y() {
      return l;
   }

   public static Set<mb> m(mb... var0) {
      return bd.m(mb.class, var0);
   }

   static boolean r(Set<mb> var0) {
      return var0.size() == l.size();
   }

   private static mb[] O() {
      return new mb[]{COLOR, SHADOW_COLOR, DECORATIONS, EVENTS, INSERTION, FONT};
   }

   static {
      long var0 = kt.a(-6346577209730806417L, -2299483477675852341L, MethodHandles.lookup().lookupClass()).a(28660475949345L) ^ 3391590992611L;
      COLOR = new mb("COLOR", 0);
      SHADOW_COLOR = new mb("SHADOW_COLOR", 1);
      DECORATIONS = new mb("DECORATIONS", 2);
      EVENTS = new mb("EVENTS", 3);
      INSERTION = new mb("INSERTION", 4);
      FONT = new mb("FONT", 5);
      Q = O();
      l = m(values());
      P = m(COLOR, DECORATIONS);
   }
}

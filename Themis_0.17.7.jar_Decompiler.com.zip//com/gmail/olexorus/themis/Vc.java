package com.gmail.olexorus.themis;

import java.util.Objects;

public class Vc {
   private zR N;
   private float g;

   public Vc(zR var1, float var2) {
      this.N = var1;
      this.g = var2;
   }

   public static Vc P(lm<?> var0) {
      zR var1 = zR.r(var0);
      float var2 = var0.L();
      return new Vc(var1, var2);
   }

   public static void X(lm<?> var0, Vc var1) {
      zR.g(var0, var1.N);
      var0.S(var1.g);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof Vc)) {
         return false;
      } else {
         Vc var2 = (Vc)var1;
         return Float.compare(var2.g, this.g) != 0 ? false : this.N.equals(var2.N);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.N, this.g});
   }
}

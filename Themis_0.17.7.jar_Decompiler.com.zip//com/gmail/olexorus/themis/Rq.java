package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;

public class Rq extends Rc {
   protected final byte[] C;
   private static final long a = kt.a(1781091173202979842L, 2738952238172514855L, MethodHandles.lookup().lookupClass()).a(221642271087683L);

   public Rq(byte[] var1) {
      this.C = var1;
   }

   public Ay<Rq> b() {
      return Ay.j;
   }

   public byte[] T() {
      return this.C;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 == null) {
         return false;
      } else if (this.getClass() != var1.getClass()) {
         return false;
      } else {
         Rq var2 = (Rq)var1;
         return Arrays.equals(this.C, var2.C);
      }
   }

   public int hashCode() {
      return Arrays.hashCode(this.C);
   }

   public Rq o() {
      byte[] var1 = new byte[this.C.length];
      System.arraycopy(this.C, 0, var1, 0, this.C.length);
      return new Rq(var1);
   }

   public String toString() {
      long var1 = a ^ 114451574011164L;
      return "ByteArray(" + Arrays.toString(this.C) + ")";
   }
}

package com.gmail.olexorus.themis;

public class s0 extends lm<s0> {
   private X M;
   private r0 u;

   public void t() {
      this.M = this.a();
      this.u = this.f();
   }

   public void d() {
      this.G(this.M);
      this.B(this.u);
   }

   public void O(s0 var1) {
      this.M = var1.M;
      this.u = var1.u;
   }
}

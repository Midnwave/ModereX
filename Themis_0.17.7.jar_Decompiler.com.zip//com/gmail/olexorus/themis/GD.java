package com.gmail.olexorus.themis;

public interface GD<T extends WZ<?>> extends GL {
   T E(lm<?> var1);

   void M(lm<?> var1, T var2);
}

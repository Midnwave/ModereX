package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class Nt {
   public static final al y;
   private al F;
   private VC f;

   public Nt(al var1, VC var2) {
      this.F = var1;
      this.f = var2;
   }

   public al U() {
      return this.F;
   }

   public VC z() {
      return this.f;
   }

   static {
      long var0 = kt.a(-4838677953631236531L, 3266639363870876074L, MethodHandles.lookup().lookupClass()).a(90375107811064L) ^ 91801917896033L;
      y = al.z("overworld");
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public interface X extends VH, lv, nc, AT<X>, Me, Eu<X> {
   BiPredicate<? super X, ? super X> d = Objects::equals;
   BiPredicate<? super X, ? super X> P = X::lambda$static$0;
   Predicate<? super X> p = X::lambda$static$1;
   long e = kt.a(-3611046067035726131L, -5150844544297783123L, MethodHandles.lookup().lookupClass()).a(125975312706694L);

   static Aa f() {
      return lA.M;
   }

   static NO L() {
      return new A0();
   }

   static vt N() {
      return new AK();
   }

   static W_ W() {
      return new AF();
   }

   static A7 S() {
      return new Ao();
   }

   static V_ l() {
      return new A3();
   }

   static m1 t() {
      return new A9();
   }

   static vy a() {
      return new Aw();
   }

   static nh p() {
      return new Aj();
   }

   static Aa N(String var0) {
      return var0.isEmpty() ? f() : f(var0, WR.O());
   }

   static Aa f(String var0, WR var1) {
      long var2 = e ^ 62294844798658L;
      return lA.w(Collections.emptyList(), (WR)Objects.requireNonNull(var1, "style"), var0);
   }

   static Aa N(boolean var0) {
      return N(String.valueOf(var0));
   }

   static Aa m(int var0) {
      return N(String.valueOf(var0));
   }

   static A4 Z() {
      return new AE();
   }

   static GY D(String var0) {
      return m(var0, WR.O());
   }

   static GY m(String var0, WR var1) {
      long var2 = e ^ 47707202093702L;
      return lO.N(Collections.emptyList(), (WR)Objects.requireNonNull(var1, "style"), var0, (String)null, Collections.emptyList());
   }

   static GY N(String var0, BX var1) {
      return m(var0, WR.c(var1));
   }

   List<X> C();

   X T(List<? extends lv> var1);

   WR o();

   X Z(WR var1);

   default X K(Consumer<Nr> var1) {
      return this.Z(this.o().Q(var1));
   }

   default v1 U() {
      return this.o().U();
   }

   default BX z() {
      return this.o().z();
   }

   default Vd K() {
      return this.o().K();
   }

   default X o(MJ var1) {
      return this.Z((WR)this.o().C(var1));
   }

   default X N(ux var1) {
      return (X)Eu.super.R(var1);
   }

   default NW m(ux var1) {
      return this.o().m(var1);
   }

   default X R(ux var1, boolean var2) {
      return (X)Eu.super.N(var1, var2);
   }

   default X p(ux var1, NW var2) {
      return this.Z(this.o().T(var1, var2));
   }

   default Eb Q() {
      return this.o().Q();
   }

   default mk<?> U() {
      return this.o().U();
   }

   default String L() {
      return this.o().L();
   }

   default boolean R() {
      return !this.o().A();
   }

   default X t(GB var1) {
      long var2 = e ^ 57553917296417L;
      Objects.requireNonNull(var1, "replacement");
      if (!(var1 instanceof Ah)) {
         throw new IllegalArgumentException("Provided replacement was a custom TextReplacementConfig implementation, which is not supported.");
      } else {
         return TQ.e.B(this, ((Ah)var1).R());
      }
   }

   default Iterator<X> E(i6 var1, Set<gG> var2) {
      long var3 = e ^ 53278559177684L;
      return new z(this, (i6)Objects.requireNonNull(var1, "type"), (Set)Objects.requireNonNull(var2, "flags"));
   }

   default Spliterator<X> x(i6 var1, Set<gG> var2) {
      return Spliterators.spliteratorUnknownSize(this.E(var1, var2), 1296);
   }

   default X T() {
      return this;
   }

   default mk<X> p(UnaryOperator<X> var1) {
      return mk.z((X)var1.apply(this));
   }

   default Stream<? extends rE> T() {
      long var1 = e ^ 95817412753908L;
      return Stream.of(rE.E("style", this.o()), rE.E("children", this.C()));
   }

   private static void lambda$replaceText$13(Pattern var0, Function var1, Bt var2, zx var3) {
      var3.M(var0).E(var1).Y(var2);
   }

   private static void lambda$replaceText$12(String var0, lv var1, Bt var2, zx var3) {
      var3.x(var0).R(var1).Y(var2);
   }

   private static void lambda$replaceText$11(Pattern var0, int var1, Function var2, zx var3) {
      var3.M(var0).B(var1).E(var2);
   }

   private static void lambda$replaceText$10(String var0, int var1, lv var2, zx var3) {
      var3.x(var0).B(var1).R(var2);
   }

   private static void lambda$replaceFirstText$9(Pattern var0, Function var1, zx var2) {
      var2.M(var0).m().E(var1);
   }

   private static void lambda$replaceFirstText$8(String var0, lv var1, zx var2) {
      var2.x(var0).m().R(var1);
   }

   private static void lambda$replaceText$7(Pattern var0, Function var1, zx var2) {
      var2.M(var0).E(var1);
   }

   private static void lambda$replaceText$6(String var0, lv var1, zx var2) {
      var2.x(var0).R(var1);
   }

   private default Spliterator lambda$iterable$5(i6 var1, Set var2) {
      return this.x(var1, var2);
   }

   private default Iterator lambda$iterable$4(i6 var1, Set var2) {
      return this.E(var1, var2);
   }

   private static nh lambda$toComponent$3(X var0, nh var1, nh var2) {
      List var3 = var1.X();
      nh var4 = (nh)p().y(var3);
      if (!var3.isEmpty()) {
         var4.U(var0);
      }

      var4.y(var2.X());
      return var4;
   }

   private static void lambda$toComponent$2(X var0, nh var1, X var2) {
      if (var0 != f() && !var1.X().isEmpty()) {
         var1.U(var0);
      }

      var1.U(var2);
   }

   private static boolean lambda$static$1(X var0) {
      return var0 != f();
   }

   private static boolean lambda$static$0(X var0, X var1) {
      return var0 == var1;
   }
}

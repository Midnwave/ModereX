package com.gmail.olexorus.themis;

final class wn {
   final BX N;
   final ux D;
   final boolean a;

   wn(BX var1, ux var2, boolean var3) {
      this.N = var1;
      this.D = var2;
      this.a = var3;
   }
}

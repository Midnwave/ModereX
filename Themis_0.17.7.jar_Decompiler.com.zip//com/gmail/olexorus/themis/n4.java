package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class n4 {
   private static final N8<tx> c;
   public static final tx b;
   public static final tx C;
   public static final tx l;
   public static final tx o;
   public static final tx y;
   public static final tx g;
   public static final tx W;
   public static final tx E;
   public static final tx N;
   public static final tx T;
   public static final tx Y;
   public static final tx P;
   public static final tx v;

   private static tx j(String var0) {
      return (tx)c.h(var0, c6::new);
   }

   public static N8<tx> C() {
      return c;
   }

   static {
      long var0 = kt.a(-751561365385350072L, 1247693363212440224L, MethodHandles.lookup().lookupClass()).a(259958659135285L) ^ 53152212245862L;
      c = new N8("recipe_book_category");
      b = j("crafting_building_blocks");
      C = j("crafting_redstone");
      l = j("crafting_equipment");
      o = j("crafting_misc");
      y = j("furnace_food");
      g = j("furnace_blocks");
      W = j("furnace_misc");
      E = j("blast_furnace_blocks");
      N = j("blast_furnace_misc");
      T = j("smoker_food");
      Y = j("stonecutter");
      P = j("smithing");
      v = j("campfire");
      c.f();
   }
}

package com.gmail.olexorus.themis;

public class l7 {
   private final Eh v;
   private final Bd I;
   private int y = 1;

   l7(Eh var1, Bd var2) {
      this.v = var1;
      this.I = var2;
   }

   Bd v() {
      return this.I;
   }

   public String z() {
      return this.I.W;
   }

   public String T(bJ var1) {
      String var2 = this.I.N(var1);
      return var2 != null ? var2 : "";
   }

   public String s() {
      return this.I.I();
   }

   public void U(int var1) {
      this.y = var1;
   }

   public boolean n() {
      return this.y > 0;
   }

   public int d() {
      return this.y;
   }

   public String A() {
      return this.I.B;
   }

   public AM[] L() {
      return this.I.z;
   }
}

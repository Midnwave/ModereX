package com.gmail.olexorus.themis;

class rG extends rE {
   final String x;
   final char E;

   rG(String var1, char var2) {
      super((rM)null);
      this.x = var1;
      this.E = var2;
   }

   public String X() {
      return this.x;
   }
}

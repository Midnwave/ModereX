package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

class rQ implements tw<vc> {
   private static final long a = kt.a(-3626974751484247700L, 641763639206706636L, MethodHandles.lookup().lookupClass()).a(203305601312738L);

   public vc L(Rc var1, lm<?> var2) {
      long var3 = a ^ 134450358703401L;
      if (var1 instanceof mZ) {
         String var5 = ((mZ)var1).b();
         if (!var5.isEmpty() && var5.charAt(0) == '#') {
            if (var5.length() - 1 != 8) {
               throw new to("Hex color is wrong, expected 8 digits but got " + var5);
            } else {
               try {
                  String var6 = var5.substring(1);
                  int var7 = Integer.parseUnsignedInt(var6, 16);
                  return new vc(var7);
               } catch (NumberFormatException var8) {
                  throw new to(var8);
               }
            }
         } else {
            throw new to("Hex color must begin with #");
         }
      } else {
         return var1 instanceof mh ? new vc(((mh)var1).P()) : vc.J;
      }
   }

   public Rc Z(lm<?> var1, vc var2) {
      return new mz(var2.V());
   }
}

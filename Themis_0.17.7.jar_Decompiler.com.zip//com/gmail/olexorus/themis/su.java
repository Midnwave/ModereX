package com.gmail.olexorus.themis;

public class su extends lm<su> {
   private int G;
   private Integer H;
   private X W;

   public void t() {
      this.G = this.Q();
      if (this.I.R(zZ.V_1_19_4)) {
         this.H = this.f();
      }

      this.W = this.a();
   }

   public void d() {
      this.E(this.G);
      if (this.I.R(zZ.V_1_19_4)) {
         int var1 = this.H != null ? this.H : 0;
         this.L(var1);
      }

      this.G(this.W);
   }

   public void i(su var1) {
      this.G = var1.G;
      this.H = var1.H;
      this.W = var1.W;
   }
}

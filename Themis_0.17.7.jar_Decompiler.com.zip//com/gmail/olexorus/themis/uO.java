package com.gmail.olexorus.themis;

public interface uO {
   Object n(Object var1);

   Gs c(Object var1);

   default void Q(Object var1, lm<?> var2) {
      oS.J().X().l(this.n(var1), var2);
   }
}

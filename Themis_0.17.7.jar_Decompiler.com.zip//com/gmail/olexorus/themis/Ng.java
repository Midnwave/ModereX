package com.gmail.olexorus.themis;

public interface Ng<T extends GL> {
   default gC<T> o(lm<?> var1, VD<T> var2) {
      vL var3 = var1.R().u();
      VD var4 = var1.T().W(var2, var3);
      return this.V(var3, var4);
   }

   default gC<T> C(vL var1, m2 var2, VD<T> var3) {
      VD var4 = var2.W(var3, var1);
      return this.V(var1, var4);
   }

   gC<T> V(vL var1, VD<T> var2);

   boolean u();
}

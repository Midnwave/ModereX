package com.gmail.olexorus.themis;

class uQ implements lV<T8> {
   public v2 V(v2 var1, T8 var2) {
      return var2.Y(var1);
   }

   public tw<T8> F(Jf<v2> var1) {
      return T8.J;
   }
}

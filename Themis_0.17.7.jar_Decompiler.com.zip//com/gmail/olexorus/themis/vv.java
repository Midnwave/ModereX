package com.gmail.olexorus.themis;

import com.gmail.olexorus.themis.api.CheckType;

// $FF: synthetic class
public final class vv {
   public static final O4<CheckType> P;
   private static String[] J;

   static {
      if (h() != null) {
         A(new String[4]);
      }

      P = Cz.x((Enum[])CheckType.values());
   }

   public static void A(String[] var0) {
      J = var0;
   }

   public static String[] h() {
      return J;
   }
}

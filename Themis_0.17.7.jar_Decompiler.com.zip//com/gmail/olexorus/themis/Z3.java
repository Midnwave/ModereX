package com.gmail.olexorus.themis;

public class Z3 extends lm<Z3> {
   private String H;
   private int x;

   public void t() {
      this.H = this.A();
      this.x = this.Q();
   }

   public void d() {
      this.I(this.H);
      this.E(this.x);
   }

   public void a(Z3 var1) {
      this.H = var1.H;
      this.x = var1.x;
   }
}

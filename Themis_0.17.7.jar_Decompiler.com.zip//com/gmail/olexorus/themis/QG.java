package com.gmail.olexorus.themis;

public class QG extends lm<QG> {
   private X T;
   private VC X;

   public void t() {
      this.T = this.a();
      this.X = (VC)this.u(VC::T);
   }

   public void d() {
      this.G(this.T);
      this.l(this.X, VC::M);
   }

   public void N(QG var1) {
      this.T = var1.T;
      this.X = var1.X;
   }
}

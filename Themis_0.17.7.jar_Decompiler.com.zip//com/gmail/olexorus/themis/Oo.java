package com.gmail.olexorus.themis;

import java.util.Iterator;

public final class Oo implements Iterable<T>, lK {
   final EL z;

   public Oo(EL var1) {
      this.z = var1;
   }

   public Iterator<T> iterator() {
      boolean var1 = false;
      return this.z.H();
   }
}

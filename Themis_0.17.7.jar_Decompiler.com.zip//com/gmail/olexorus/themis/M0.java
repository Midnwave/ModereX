package com.gmail.olexorus.themis;

import com.google.gson.TypeAdapter;
import java.lang.invoke.MethodHandles;

final class M0 {
   static final TypeAdapter<ux> S;

   static {
      long var0 = kt.a(-4540196875503467669L, 224248337414178348L, MethodHandles.lookup().lookupClass()).a(46230914688264L) ^ 104528639832762L;
      S = u6.x("text decoration", ux.NAMES);
   }
}

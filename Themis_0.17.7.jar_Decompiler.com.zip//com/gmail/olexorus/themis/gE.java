package com.gmail.olexorus.themis;

public class gE implements RI {
   private final String R;
   private final Gz S;
   private final Nl B;
   private final TU x;
   private final float F;
   private final int X;

   public gE(String var1, Gz var2, Nl var3, TU var4, float var5, int var6) {
      this.R = var1;
      this.S = var2;
      this.B = var3;
      this.x = var4;
      this.F = var5;
      this.X = var6;
   }

   public static gE A(lm<?> var0) {
      String var1 = var0.A();
      Gz var2 = var0.R().i(zZ.V_1_19_3) ? (Gz)var0.w((Enum[])Gz.values()) : Gz.MISC;
      Nl var3 = Nl.v(var0);
      TU var4 = var0.u();
      float var5 = var0.L();
      int var6 = var0.Q();
      return new gE(var1, var2, var3, var4, var5, var6);
   }

   public static void Y(lm<?> var0, gE var1) {
      var0.I(var1.R);
      if (var0.R().i(zZ.V_1_19_3)) {
         var0.o((Enum)var1.S);
      }

      Nl.F(var0, var1.B);
      var0.m(var1.x);
      var0.S(var1.F);
      var0.E(var1.X);
   }
}

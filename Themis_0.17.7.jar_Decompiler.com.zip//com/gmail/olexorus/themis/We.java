package com.gmail.olexorus.themis;

import java.util.HashMap;
import java.util.Map;

final class We implements No {
   private Map<String, MC> N;

   private Map<String, MC> K() {
      if (this.N == null) {
         this.N = new HashMap();
      }

      return this.N;
   }

   public No Q(String var1, MC var2) {
      this.K().put(var1, var2);
      return this;
   }

   public B w() {
      return (B)(this.N == null ? B.j() : new BN(new HashMap(this.N)));
   }
}

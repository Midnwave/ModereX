package com.gmail.olexorus.themis;

public final class Cz {
   public static final <E extends Enum<E>> O4<E> x(E[] var0) {
      return (O4)(new g_(var0));
   }
}

package com.gmail.olexorus.themis;

public final class P<T> {
   private final int D;
   private final T U;

   public P(int var1, T var2) {
      this.D = var1;
      this.U = var2;
   }

   public static <T> P<T> S(lm<?> var0, MO<T> var1) {
      int var2 = var0.Q();
      Object var3 = var1.apply(var0);
      return new P(var2, var3);
   }

   public static <T> void a(lm<?> var0, P<T> var1, Gw<T> var2) {
      var0.E(var1.D);
      var2.accept(var0, var1.U);
   }
}

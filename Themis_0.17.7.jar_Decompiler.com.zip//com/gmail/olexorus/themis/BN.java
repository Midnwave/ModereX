package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.stream.Stream;

final class BN extends BG implements B {
   static final B S = new BN(Collections.emptyMap());
   private final Map<String, MC> x;
   private final int q;
   private static final long a = kt.a(8038233931852185194L, -3108576002624902395L, MethodHandles.lookup().lookupClass()).a(3033514785620L);

   BN(Map<String, MC> var1) {
      this.x = Collections.unmodifiableMap(var1);
      this.q = var1.hashCode();
   }

   public boolean i(String var1, uX<?> var2) {
      MC var3 = (MC)this.x.get(var1);
      return var3 != null && var2.e(var3.y());
   }

   public Set<String> W() {
      return Collections.unmodifiableSet(this.x.keySet());
   }

   public MC E(String var1) {
      return (MC)this.x.get(var1);
   }

   public B Y(String var1, MC var2) {
      return this.s(BN::lambda$put$0);
   }

   public byte Z(String var1, byte var2) {
      return this.i(var1, tq.i) ? ((Vj)this.x.get(var1)).l() : var2;
   }

   public String C(String var1, String var2) {
      return this.i(var1, tq.c) ? ((BO)this.x.get(var1)).o() : var2;
   }

   public B H(String var1, B var2) {
      return this.i(var1, tq.w) ? (B)this.x.get(var1) : var2;
   }

   private B s(Consumer<Map<String, MC>> var1) {
      HashMap var2 = new HashMap(this.x);
      var1.accept(var2);
      return new BN(var2);
   }

   public boolean equals(Object var1) {
      return this == var1 || var1 instanceof BN && this.x.equals(((BN)var1).x);
   }

   public int hashCode() {
      return this.q;
   }

   public Stream<? extends rE> T() {
      long var1 = a ^ 45717597761880L;
      return Stream.of(rE.E("tags", this.x));
   }

   public Iterator<Entry<String, ? extends MC>> iterator() {
      return this.x.entrySet().iterator();
   }

   public void forEach(Consumer<? super Entry<String, ? extends MC>> var1) {
      long var2 = a ^ 128767249509983L;
      this.x.entrySet().forEach((Consumer)Objects.requireNonNull(var1, "action"));
   }

   private static void lambda$remove$3(String var0, Consumer var1, Map var2) {
      MC var3 = (MC)var2.remove(var0);
      if (var1 != null) {
         var1.accept(var3);
      }

   }

   private static void lambda$put$2(Map var0, Map var1) {
      var1.putAll(var0);
   }

   private static void lambda$put$1(B var0, Map var1) {
      Iterator var2 = var0.W().iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         var1.put(var3, var0.E(var3));
      }

   }

   private static void lambda$put$0(String var0, MC var1, Map var2) {
      var2.put(var0, var1);
   }
}

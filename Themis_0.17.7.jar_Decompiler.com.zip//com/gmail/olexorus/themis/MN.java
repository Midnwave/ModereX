package com.gmail.olexorus.themis;

abstract class MN implements gK {
   public String toString() {
      return cH.M(this);
   }
}

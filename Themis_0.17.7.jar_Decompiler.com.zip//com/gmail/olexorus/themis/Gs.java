package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Gs implements m2 {
   private final Object I;
   private uy N;
   private uy s;
   private vL i;
   private final Ml E;
   private int n = -1;
   private AR f;
   private final Map<al, VD<?>> v;
   private static final long a = kt.a(4608357564583619877L, -8315081237482443769L, MethodHandles.lookup().lookupClass()).a(192899654741530L);

   public Gs(Object var1, uy var2, vL var3, Ml var4) {
      this.f = BW.Q;
      this.v = new HashMap();
      this.I = var1;
      this.N = var2;
      this.s = var2;
      this.i = var3;
      this.E = var4;
   }

   public VD<?> z(al var1, vL var2) {
      return (VD)this.v.get(var1);
   }

   public void k(VD<?> var1) {
      this.v.put(var1.S(), var1);
   }

   public Object b() {
      return this.I;
   }

   public InetSocketAddress H() {
      return (InetSocketAddress)lC.q(this.I);
   }

   public uy W() {
      long var1 = a ^ 60781279725073L;
      uy var3 = this.N;
      uy var4 = this.s;
      if (var3 != var4) {
         throw new IllegalStateException("Can't get common connection state: " + var3 + " != " + var4);
      } else {
         return var3;
      }
   }

   public void u(uy var1) {
      this.V(var1);
      this.L(var1);
   }

   public uy U() {
      return this.N;
   }

   public void V(uy var1) {
      long var2 = a ^ 139360730140771L;
      this.N = var1;
      oS.J().m().n("Transitioned " + this.F() + "'s decoder into " + var1 + " state!");
   }

   public uy N() {
      return this.s;
   }

   public void L(uy var1) {
      long var2 = a ^ 48509752253044L;
      this.s = var1;
      oS.J().m().n("Transitioned " + this.F() + "'s encoder into " + var1 + " state!");
   }

   public vL E() {
      return this.i;
   }

   public void H(vL var1) {
      this.i = var1;
   }

   public Ml h() {
      return this.E;
   }

   public String F() {
      return this.E.s();
   }

   public UUID e() {
      return this.E.J();
   }

   public void c(int var1) {
      this.n = var1;
   }

   public void n(lm<?> var1) {
      oS.J().X().l(this.I, var1);
   }

   public int C() {
      return this.f.C();
   }

   public AR j() {
      return this.f;
   }

   public void P(AR var1) {
      this.f = var1;
   }
}

package com.gmail.olexorus.themis;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.Version;
import java.lang.invoke.MethodHandles;
import java.util.Map;

public class wS extends ChannelInboundHandlerAdapter {
   public static final uo F = new uo(4, 1, 24);
   public static boolean h;
   public static uo v;
   private static final long a = kt.a(2004746856386104686L, 4940693294110085739L, MethodHandles.lookup().lookupClass()).a(264149744150634L);

   private static uo w() {
      long var0 = a ^ 109289000096487L;
      Map var2 = Version.identify();
      Version var3 = (Version)var2.getOrDefault("netty-common", (Version)var2.get("netty-all"));
      if (var3 == null && !var2.values().isEmpty()) {
         var3 = (Version)var2.values().iterator().next();
      }

      if (var3 != null) {
         String var4 = var3.artifactVersion();
         var4 = var4.replaceAll("[^\\d.]", "");
         String[] var5 = var4.split("\\.");
         if (var5.length > 3) {
            var4 = var5[0] + "." + var5[1] + "." + var5[2];
         }

         var4 = var4.endsWith(".") ? var4.substring(0, var4.length() - 1) : var4;
         return uo.F(var4);
      } else {
         return null;
      }
   }

   public void channelRead(ChannelHandlerContext var1, Object var2) {
      Channel var3 = (Channel)var2;
      if (v == null && !h) {
         v = w();
         h = true;
      }

      if ((v == null || !v.L(F)) && !EO.NY) {
         var3.pipeline().addFirst(oS.A, new BV());
      } else {
         var3.pipeline().addLast(oS.A, new Wz());
      }

      super.channelRead(var1, var2);
   }
}

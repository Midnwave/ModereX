package com.gmail.olexorus.themis;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class t1 {
   private int j;
   private float b;
   private boolean z;
   private float k;
   private List<Vc> y;
   private TU B;

   public t1(int var1, float var2, boolean var3) {
      this(var1, var2, var3, 1.6F, Collections.emptyList());
   }

   public t1(int var1, float var2, boolean var3, float var4, List<Vc> var5) {
      this(var1, var2, var3, var4, var5, (TU)null);
   }

   public t1(int var1, float var2, boolean var3, float var4, List<Vc> var5, TU var6) {
      this.j = var1;
      this.b = var2;
      this.z = var3;
      this.k = var4;
      this.y = var5;
      this.B = var6;
   }

   public static t1 m(lm<?> var0) {
      int var1 = var0.Q();
      float var2 = var0.L();
      boolean var3 = var0.P();
      if (var0.R().i(zZ.V_1_21_2)) {
         return new t1(var1, var2, var3);
      } else {
         float var4 = var0.L();
         TU var5 = var0.R().i(zZ.V_1_21) ? (TU)var0.u(lm::u) : null;
         List var6 = var0.j(Vc::P);
         return new t1(var1, var2, var3, var4, var6, var5);
      }
   }

   public static void r(lm<?> var0, t1 var1) {
      var0.E(var1.j);
      var0.S(var1.b);
      var0.I(var1.z);
      if (var0.R().m(zZ.V_1_21_2)) {
         var0.S(var1.k);
         if (var0.R().i(zZ.V_1_21)) {
            var0.l(var1.B, lm::m);
         }

         var0.D(var1.y, Vc::X);
      }

   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof t1)) {
         return false;
      } else {
         t1 var2 = (t1)var1;
         if (this.j != var2.j) {
            return false;
         } else if (Float.compare(var2.b, this.b) != 0) {
            return false;
         } else if (this.z != var2.z) {
            return false;
         } else if (Float.compare(var2.k, this.k) != 0) {
            return false;
         } else {
            return !this.y.equals(var2.y) ? false : Objects.equals(this.B, var2.B);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.j, this.b, this.z, this.k, this.y, this.B});
   }
}

package com.gmail.olexorus.themis;

public class sh extends lm<sh> {
   public sh() {
      super((wC)rX.CHUNK_BATCH_BEGIN);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum TP {
   INIT,
   QUERY,
   SET,
   RESET,
   SAVE,
   EXPORT,
   RUN;

   private static final TP[] C;

   private static TP[] U() {
      return new TP[]{INIT, QUERY, SET, RESET, SAVE, EXPORT, RUN};
   }

   static {
      long var0 = kt.a(2105917170474740454L, 146856031467454242L, MethodHandles.lookup().lookupClass()).a(125599590739167L) ^ 54507144025242L;
      INIT = new TP("INIT", 0);
      QUERY = new TP("QUERY", 1);
      SET = new TP("SET", 2);
      RESET = new TP("RESET", 3);
      SAVE = new TP("SAVE", 4);
      EXPORT = new TP("EXPORT", 5);
      RUN = new TP("RUN", 6);
      C = U();
   }
}

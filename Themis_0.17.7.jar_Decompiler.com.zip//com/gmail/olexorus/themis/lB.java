package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.List;

class lB implements bg<mP<T>> {
   final tw Z;
   private static final long a = kt.a(3929916092895403978L, -8319078484829670427L, MethodHandles.lookup().lookupClass()).a(185104053966648L);

   lB(tw var1) {
      this.Z = var1;
   }

   public mP<T> t(RT var1, lm<?> var2) {
      long var3 = a ^ 65825110072400L;
      List var5 = (List)var1.g("keyframes", this.Z, var2);
      bW var6 = (bW)var1.P("ease", bW.i, tp.n, var2);
      return new mP(var5, var6);
   }

   public void E(RT var1, lm<?> var2, mP<T> var3) {
      long var4 = a ^ 78540546044679L;
      var1.X("keyframes", mP.p(var3), this.Z, var2);
      if (mP.l(var3) != tp.n) {
         var1.X("ease", mP.l(var3), bW.i, var2);
      }

   }
}

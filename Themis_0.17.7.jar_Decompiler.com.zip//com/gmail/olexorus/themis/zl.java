package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public interface zl extends GL, uW<zl>, rp {
   long a = kt.a(5579785180331109550L, -7147854337555851670L, MethodHandles.lookup().lookupClass()).a(1634192491002L);

   gv k();

   al t();

   static zl s(lm<?> var0) {
      return (zl)var0.y((VD)My.a());
   }

   static void w(lm<?> var0, zl var1) {
      var0.j((GL)var1);
   }

   static zl K(Rc var0, vL var1, z2 var2) {
      long var3 = a ^ 49898894586682L;
      RT var5 = (RT)var0;
      String var6 = var5.c("model");
      gv var7 = var6 != null ? gv.I(var6) : gv.NORMAL;
      al var8 = new al(var5.N("asset_id"));
      return new iI(var2, var7, var8);
   }
}

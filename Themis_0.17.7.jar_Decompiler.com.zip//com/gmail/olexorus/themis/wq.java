package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum wq {
   STANDING,
   SITTING,
   RUNNING,
   STAR;

   // $FF: synthetic method
   private static wq[] f() {
      return new wq[]{STANDING, SITTING, RUNNING, STAR};
   }

   static {
      long var0 = kt.a(7575965248784297999L, -4639920986883177812L, MethodHandles.lookup().lookupClass()).a(15152290978983L) ^ 31306021186376L;
      STANDING = new wq("STANDING", 0);
      SITTING = new wq("SITTING", 1);
      RUNNING = new wq("RUNNING", 2);
      STAR = new wq("STAR", 3);
   }
}

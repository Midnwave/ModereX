package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class B_ {
   private static final N8<rL<?>> I;
   public static final rL<tQ> T;
   public static final rL<t6> i;
   public static final rL<ta> r;
   public static final rL<tZ> v;
   public static final rL<tD> z;
   public static final rL<tC> n;
   public static final rL<tL> y;
   public static final rL<tz> H;

   private static <T extends tO<?>> rL<T> H(String var0, MO<T> var1, Gw<T> var2) {
      return (rL)I.h(var0, B_::lambda$register$0);
   }

   public static N8<rL<?>> o() {
      return I;
   }

   private static cQ lambda$register$0(MO var0, Gw var1, z2 var2) {
      return new cQ(var2, var0, var1);
   }

   static {
      long var0 = kt.a(-8576311631241992860L, 4183138239508823149L, MethodHandles.lookup().lookupClass()).a(234319694193073L) ^ 63385651000452L;
      I = new N8("slot_display");
      T = H("empty", tQ::t, tQ::n);
      i = H("any_fuel", t6::m, t6::p);
      r = H("item", ta::W, ta::l);
      v = H("item_stack", tZ::C, tZ::v);
      z = H("tag", tD::l, tD::N);
      n = H("smithing_trim", tC::r, tC::a);
      y = H("with_remainder", tL::h, tL::F);
      H = H("composite", tz::s, tz::a);
      I.f();
   }
}

package com.gmail.olexorus.themis;

public interface zm<T> {
   String x(Gq var1, T var2);
}

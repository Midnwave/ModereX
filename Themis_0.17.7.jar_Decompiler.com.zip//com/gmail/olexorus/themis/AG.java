package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.lang.ref.WeakReference;
import java.util.Map;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent.Result;
import org.bukkit.plugin.Plugin;

public class AG implements Listener {
   private final Plugin R;
   private static final long a = kt.a(-6272064186603297338L, -2429477369602867542L, MethodHandles.lookup().lookupClass()).a(18150213449872L);

   public AG(Plugin var1) {
      this.R = var1;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void Z(PlayerLoginEvent var1) {
      if (var1.getResult() == Result.ALLOWED) {
         this.Q(var1.getPlayer());
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void C(PlayerJoinEvent var1) {
      this.W(var1.getPlayer());
   }

   void Q(Player var1) {
      vX var2 = oS.J();
      Map var3 = ((VF)var2.v()).D;
      var3.put(var1.getUniqueId(), new WeakReference(var1));
   }

   void W(Player var1) {
      vX var2 = oS.J();
      Gs var3 = var2.v().c(var1);
      if (var3 != null) {
         NZ var5 = (NZ)oS.J().L();
         var5.q(var3.b(), var1);
         ((VF)var2.v()).D.remove(var1.getUniqueId());
      } else {
         ((VF)var2.v()).D.remove(var1.getUniqueId());
         Object var4 = var2.v().n(var1);
         if ((var4 == null || !rz.y(var4)) && (!var2.P() || var2.z().b())) {
            uD.r().m(var1, this.R, AG::lambda$onPostJoin$0, (Runnable)null, 0L);
         }
      }
   }

   private static void lambda$onPostJoin$0(Object var0, Player var1, Object var2) {
      long var3 = a ^ 137664149065831L;
      if (var0 != null) {
         if (!lC.u(var0)) {
            return;
         }
      } else if (!var1.isOnline()) {
         return;
      }

      var1.kickPlayer("PacketEvents failed to inject into a channel");
   }
}

package com.gmail.olexorus.themis;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.plugin.Plugin;

public class At {
   private static final Object V = new Object();
   private final Plugin M;
   private final Map<String, lQ> m = new HashMap(0);

   private At(Plugin var1) {
      this.M = var1;
   }

   public static At Z(Plugin var0) {
      return new At(var0);
   }
}

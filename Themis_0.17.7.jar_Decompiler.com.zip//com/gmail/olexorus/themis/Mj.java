package com.gmail.olexorus.themis;

import java.util.Map;

class Mj implements a5<C, V> {
   final Object Z;
   final Map r;
   final li o;

   Mj(li var1, Object var2, Map var3) {
      this.o = var1;
      this.Z = var2;
      this.r = var3;
   }

   public Map<C, V> c(boolean var1) {
      return var1 ? (Map)li.b(this.o).getOrDefault(this.Z, this.r) : li.t(this.o, this.Z);
   }

   public V remove(Object var1) {
      Map var2 = this.c(false);
      Object var3 = var2.remove(var1);
      li.F(this.o, this.Z, var2);
      return var3;
   }
}

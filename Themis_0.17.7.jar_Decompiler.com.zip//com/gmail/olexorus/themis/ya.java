package com.gmail.olexorus.themis;

import java.util.Optional;

public class ya extends lm<ya> {
   private int D;
   private u_ k;
   private Optional<r3> E;
   private uE z;
   private Optional<Boolean> w;

   public ya(aw var1) {
      super(var1);
   }

   public void t() {
      if (this.I.R(zZ.V_1_7_10)) {
         this.D = this.f();
         byte var1 = this.M();
         this.k = u_.VALUES[var1];
         this.E = Optional.empty();
         this.z = uE.MAIN_HAND;
         this.w = Optional.empty();
      } else {
         this.D = this.Q();
         int var5 = this.Q();
         this.k = u_.VALUES[var5];
         if (this.k == u_.INTERACT_AT) {
            float var2 = this.L();
            float var3 = this.L();
            float var4 = this.L();
            this.E = Optional.of(new r3(var2, var3, var4));
         } else {
            this.E = Optional.empty();
         }

         if (!this.I.i(zZ.V_1_9) || this.k != u_.INTERACT && this.k != u_.INTERACT_AT) {
            this.z = uE.MAIN_HAND;
         } else {
            int var6 = this.Q();
            this.z = uE.B(var6);
         }

         if (this.I.i(zZ.V_1_16)) {
            this.w = Optional.of(this.P());
         } else {
            this.w = Optional.empty();
         }
      }

   }

   public void d() {
      if (this.I.R(zZ.V_1_7_10)) {
         this.L(this.D);
         this.u(this.k.ordinal());
      } else {
         this.E(this.D);
         this.E(this.k.ordinal());
         if (this.k == u_.INTERACT_AT) {
            r3 var1 = (r3)this.E.orElse(new r3(0.0F, 0.0F, 0.0F));
            this.S(var1.E);
            this.S(var1.j);
            this.S(var1.D);
         }

         if (this.I.i(zZ.V_1_9) && (this.k == u_.INTERACT || this.k == u_.INTERACT_AT)) {
            this.E(this.z.p());
         }

         if (this.I.i(zZ.V_1_16)) {
            this.I((Boolean)this.w.orElse(false));
         }
      }

   }

   public void w(ya var1) {
      this.D = var1.D;
      this.k = var1.k;
      this.E = var1.E;
      this.z = var1.z;
      this.w = var1.w;
   }

   public u_ U() {
      return this.k;
   }
}

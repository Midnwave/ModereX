package com.gmail.olexorus.themis;

public class sW extends lm<sW> {
   private OK K;
   private float s;

   public void t() {
      this.K = OK.S(this.h());
      this.s = this.L();
   }

   public void d() {
      this.u(this.K.ordinal());
      this.S(this.s);
   }

   public void S(sW var1) {
      this.K = var1.K;
      this.s = var1.s;
   }
}

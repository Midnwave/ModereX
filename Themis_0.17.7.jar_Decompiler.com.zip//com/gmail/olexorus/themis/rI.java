package com.gmail.olexorus.themis;

class rI extends rE {
   final String v;
   final short B;

   rI(String var1, short var2) {
      super((rM)null);
      this.v = var1;
      this.B = var2;
   }

   public String X() {
      return this.v;
   }
}

package com.gmail.olexorus.themis;

public class ZT extends lm<ZT> {
   private int v;

   public void t() {
      this.v = this.a();
   }

   public void d() {
      this.y(this.v);
   }

   public void t(ZT var1) {
      this.v = var1.v;
   }
}

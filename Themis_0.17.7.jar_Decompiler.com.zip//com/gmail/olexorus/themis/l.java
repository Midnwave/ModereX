package com.gmail.olexorus.themis;

class l implements Runnable {
   final TI J;
   final RS t;
   final zk W;

   l(zk var1, TI var2, RS var3) {
      this.W = var1;
      this.J = var2;
      this.t = var3;
   }

   public void run() {
      try {
         this.J.Z(this.t.D, this.t.Q());
      } catch (Exception var2) {
      }

   }
}

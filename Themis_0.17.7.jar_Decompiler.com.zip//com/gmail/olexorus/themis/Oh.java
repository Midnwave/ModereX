package com.gmail.olexorus.themis;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class Oh implements t {
   private static final AtomicInteger X = new AtomicInteger(1);
   private static final Map<String, Oh> c = new ConcurrentHashMap();
   private final int B;
   private final String p;

   private Oh(String var1) {
      this.B = X.getAndIncrement();
      this.p = var1;
   }

   public static Oh P(String var0) {
      return (Oh)c.computeIfAbsent(var0.toLowerCase().intern(), Oh::new);
   }

   public int hashCode() {
      return this.B;
   }

   public boolean equals(Object var1) {
      return this == var1;
   }

   public String E() {
      return this.p;
   }

   public Oh n() {
      return this;
   }
}

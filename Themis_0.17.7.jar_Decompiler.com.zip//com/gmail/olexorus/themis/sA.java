package com.gmail.olexorus.themis;

public class sA extends lm<sA> {
   private int s;

   public void t() {
      this.s = this.Q();
   }

   public void d() {
      this.E(this.s);
   }

   public void n(sA var1) {
      this.s = var1.s;
   }
}

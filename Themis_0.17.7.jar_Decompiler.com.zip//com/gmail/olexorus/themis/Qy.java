package com.gmail.olexorus.themis;

import java.util.Map;

public class Qy extends lm<Qy> {
   private Map<String, Integer> M;

   public void t() {
      this.M = this.U(lm::A, lm::Q);
   }

   public void d() {
      this.o(this.M, lm::I, lm::E);
   }

   public void c(Qy var1) {
      this.M = var1.M;
   }
}

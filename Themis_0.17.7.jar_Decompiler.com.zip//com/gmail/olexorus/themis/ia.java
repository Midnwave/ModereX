package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum ia implements H {
   NONE,
   RAIN,
   SNOW;

   public static final tw<ia> CODEC;
   public static final l3<String, ia> ID_INDEX;
   private final String J;
   private static final ia[] U;

   private ia(String var3) {
      this.J = var3;
   }

   public String n() {
      return this.J;
   }

   public String g() {
      return this.J;
   }

   private static ia[] D() {
      return new ia[]{NONE, RAIN, SNOW};
   }

   static {
      long var0 = kt.a(8089969966944727296L, 3803621852288013831L, MethodHandles.lookup().lookupClass()).a(92999317944910L) ^ 106980312442786L;
      NONE = new ia("NONE", 0, "none");
      RAIN = new ia("RAIN", 1, "rain");
      SNOW = new ia("SNOW", 2, "snow");
      U = D();
      CODEC = g9.c(values());
      ID_INDEX = l3.Q(ia.class, ia::n);
   }
}

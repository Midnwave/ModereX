package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class zy implements R9 {
   private final String a;
   private static final long b = kt.a(-3694739881593814300L, 5470292951206458436L, MethodHandles.lookup().lookupClass()).a(213421004720463L);

   public zy(String var1) {
      this.a = var1;
   }

   public static zy G(RT var0, lm<?> var1) {
      long var2 = b ^ 12189361661955L;
      String var4 = var0.N("value");
      return new zy(var4);
   }

   public static void Y(RT var0, lm<?> var1, zy var2) {
      long var3 = b ^ 10957294986176L;
      var0.j("value", new mZ(var2.a));
   }

   public Ov<?> w() {
      return vs.x;
   }
}

package com.gmail.olexorus.themis;

import java.util.UUID;

public class Zw extends lm<Zw> {
   private UUID W;
   private String R;
   private String q;
   private boolean x;
   private X n;

   public void t() {
      if (this.I.i(zZ.V_1_20_3)) {
         this.W = this.V();
      }

      this.R = this.A();
      this.q = this.m(40);
      this.x = this.P();
      if (this.P()) {
         this.n = this.a();
      }

   }

   public void d() {
      if (this.I.i(zZ.V_1_20_3)) {
         this.y(this.W);
      }

      this.I(this.R);
      this.a(this.q, 40);
      this.I(this.x);
      if (this.n != null) {
         this.I(true);
         this.G(this.n);
      } else {
         this.I(false);
      }

   }

   public void E(Zw var1) {
      this.W = var1.W;
      this.R = var1.R;
      this.q = var1.q;
      this.x = var1.x;
      this.n = var1.n;
   }
}

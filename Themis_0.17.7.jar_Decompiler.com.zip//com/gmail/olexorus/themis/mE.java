package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Optional;

public interface mE extends GL, uW<mE>, rp {
   long c = kt.a(-4733244261195292700L, 4975622691544081455L, MethodHandles.lookup().lookupClass()).a(264265807859877L);

   X i();

   Go e();

   gC<mE> M();

   Ng<mE> f();

   zQ U();

   static mE N(Rc var0, lm<?> var1, z2 var2) {
      long var3 = c ^ 119554749850201L;
      RT var5 = (RT)var0;
      X var6 = (X)var5.g("description", var1.x(), var1);
      Go var7 = Go.G(var5, var1);
      Ng var8 = (Ng)Optional.ofNullable(var5.M("exclusive_set")).map(mE::lambda$decode$0).orElseGet(gC::l);
      zQ var9 = (zQ)Optional.ofNullable(var5.M("effects")).map(mE::lambda$decode$1).orElse(zQ.C);
      return new i2(var2, var6, var7, var8, var9);
   }

   private static zQ lambda$decode$1(lm var0, Rc var1) {
      return ra.k(var1, var0, Rs.O());
   }

   private static Ng lambda$decode$0(lm var0, Rc var1) {
      return gC.P(var1, var0);
   }
}

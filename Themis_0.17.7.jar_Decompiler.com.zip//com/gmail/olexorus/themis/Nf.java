package com.gmail.olexorus.themis;

public interface Nf extends l6 {
   int G();
}

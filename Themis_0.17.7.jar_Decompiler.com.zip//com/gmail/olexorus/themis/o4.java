package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class o4 {
   private static final long a = kt.a(3498066221458783759L, -8402969356504525554L, MethodHandles.lookup().lookupClass()).a(133411207197490L);

   public static String p(oT var0) {
      long var1 = a ^ 13074897937689L;
      String var3 = "§";
      if (var0 == null) {
         return var3 + "f";
      } else {
         String var4 = var0.toString();
         byte var5 = -1;
         switch(var4.hashCode()) {
         case -1852648987:
            if (var4.equals("dark_aqua")) {
               var5 = 3;
            }
            break;
         case -1852623997:
            if (var4.equals("dark_blue")) {
               var5 = 1;
            }
            break;
         case -1852469876:
            if (var4.equals("dark_gray")) {
               var5 = 8;
            }
            break;
         case -1846156123:
            if (var4.equals("dark_purple")) {
               var5 = 5;
            }
            break;
         case -1591987974:
            if (var4.equals("dark_green")) {
               var5 = 2;
            }
            break;
         case -734239628:
            if (var4.equals("yellow")) {
               var5 = 14;
            }
            break;
         case 112785:
            if (var4.equals("red")) {
               var5 = 12;
            }
            break;
         case 3002044:
            if (var4.equals("aqua")) {
               var5 = 11;
            }
            break;
         case 3027034:
            if (var4.equals("blue")) {
               var5 = 9;
            }
            break;
         case 3178592:
            if (var4.equals("gold")) {
               var5 = 6;
            }
            break;
         case 3181155:
            if (var4.equals("gray")) {
               var5 = 7;
            }
            break;
         case 93818879:
            if (var4.equals("black")) {
               var5 = 0;
            }
            break;
         case 98619139:
            if (var4.equals("green")) {
               var5 = 10;
            }
            break;
         case 113101865:
            if (var4.equals("white")) {
               var5 = 15;
            }
            break;
         case 1331038981:
            if (var4.equals("light_purple")) {
               var5 = 13;
            }
            break;
         case 1741368392:
            if (var4.equals("dark_red")) {
               var5 = 4;
            }
         }

         switch(var5) {
         case 0:
            return var3 + "0";
         case 1:
            return var3 + "1";
         case 2:
            return var3 + "2";
         case 3:
            return var3 + "3";
         case 4:
            return var3 + "4";
         case 5:
            return var3 + "5";
         case 6:
            return var3 + "6";
         case 7:
            return var3 + "7";
         case 8:
            return var3 + "8";
         case 9:
            return var3 + "9";
         case 10:
            return var3 + "a";
         case 11:
            return var3 + "b";
         case 12:
            return var3 + "c";
         case 13:
            return var3 + "d";
         case 14:
            return var3 + "e";
         case 15:
            return var3 + "f";
         default:
            return var3 + "f";
         }
      }
   }

   public static int Q(oT var0) {
      long var1 = a ^ 23251603661414L;
      if (var0 == null) {
         return -1;
      } else {
         String var3 = var0.toString();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -1852648987:
            if (var3.equals("dark_aqua")) {
               var4 = 3;
            }
            break;
         case -1852623997:
            if (var3.equals("dark_blue")) {
               var4 = 1;
            }
            break;
         case -1852469876:
            if (var3.equals("dark_gray")) {
               var4 = 8;
            }
            break;
         case -1846156123:
            if (var3.equals("dark_purple")) {
               var4 = 5;
            }
            break;
         case -1591987974:
            if (var3.equals("dark_green")) {
               var4 = 2;
            }
            break;
         case -734239628:
            if (var3.equals("yellow")) {
               var4 = 14;
            }
            break;
         case 112785:
            if (var3.equals("red")) {
               var4 = 12;
            }
            break;
         case 3002044:
            if (var3.equals("aqua")) {
               var4 = 11;
            }
            break;
         case 3027034:
            if (var3.equals("blue")) {
               var4 = 9;
            }
            break;
         case 3178592:
            if (var3.equals("gold")) {
               var4 = 6;
            }
            break;
         case 3181155:
            if (var3.equals("gray")) {
               var4 = 7;
            }
            break;
         case 93818879:
            if (var3.equals("black")) {
               var4 = 0;
            }
            break;
         case 98619139:
            if (var3.equals("green")) {
               var4 = 10;
            }
            break;
         case 113101865:
            if (var3.equals("white")) {
               var4 = 15;
            }
            break;
         case 1331038981:
            if (var3.equals("light_purple")) {
               var4 = 13;
            }
            break;
         case 1741368392:
            if (var3.equals("dark_red")) {
               var4 = 4;
            }
         }

         switch(var4) {
         case 0:
            return 0;
         case 1:
            return 1;
         case 2:
            return 2;
         case 3:
            return 3;
         case 4:
            return 4;
         case 5:
            return 5;
         case 6:
            return 6;
         case 7:
            return 7;
         case 8:
            return 8;
         case 9:
            return 9;
         case 10:
            return 10;
         case 11:
            return 11;
         case 12:
            return 12;
         case 13:
            return 13;
         case 14:
            return 14;
         case 15:
            return 15;
         default:
            return 15;
         }
      }
   }

   public static oT i(int var0) {
      if (var0 < 0) {
         return null;
      } else {
         switch(var0) {
         case 0:
            return oT.C;
         case 1:
            return oT.Q;
         case 2:
            return oT.u;
         case 3:
            return oT.R;
         case 4:
            return oT.O;
         case 5:
            return oT.f;
         case 6:
            return oT.w;
         case 7:
            return oT.q;
         case 8:
            return oT.X;
         case 9:
            return oT.Y;
         case 10:
            return oT.i;
         case 11:
            return oT.F;
         case 12:
            return oT.T;
         case 13:
            return oT.z;
         case 14:
            return oT.N;
         case 15:
            return oT.g;
         default:
            return oT.g;
         }
      }
   }
}

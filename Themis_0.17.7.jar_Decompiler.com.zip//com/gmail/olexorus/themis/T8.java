package com.gmail.olexorus.themis;

public final class T8 {
   public static final tw<T8> J = (new nF()).I();
   private final float U;
   private final float k;

   public T8(float var1, float var2) {
      this.U = var1;
      this.k = var2;
   }

   public vc Y(vc var1) {
      vc var2 = var1.Q().H(this.U);
      return var1.Q(var2, this.k);
   }

   public v2 Y(v2 var1) {
      v2 var2 = var1.s().z(this.U);
      return var1.W(var2, this.k);
   }

   static float A(T8 var0) {
      return var0.U;
   }

   static float k(T8 var0) {
      return var0.k;
   }
}

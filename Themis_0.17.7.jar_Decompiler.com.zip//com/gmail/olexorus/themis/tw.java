package com.gmail.olexorus.themis;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface tw<T> extends EV<T>, Oz<T> {
   default tw<T> a(Predicate<T> var1) {
      return new aP(this, var1);
   }

   default <Z> tw<Z> K(Function<T, Z> var1, Function<Z, T> var2) {
      return new w4(this, var1, var2);
   }

   default tw<List<T>> c() {
      return new O_(this);
   }
}

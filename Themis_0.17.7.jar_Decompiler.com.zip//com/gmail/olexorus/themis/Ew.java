package com.gmail.olexorus.themis;

public class Ew implements wU {
   public static final Ew T = new Ew();

   private Ew() {
   }

   public static Ew i(lm<?> var0) {
      return T;
   }

   public static void a(lm<?> var0, Ew var1) {
   }

   public Bu<?> U() {
      return cM.f;
   }
}

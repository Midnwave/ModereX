package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum uI {
   LOCKED,
   SCALED;

   // $FF: synthetic method
   private static uI[] H() {
      return new uI[]{LOCKED, SCALED};
   }

   static {
      long var0 = kt.a(6389774681126837033L, -5389376754268391679L, MethodHandles.lookup().lookupClass()).a(253724270847053L) ^ 80111424644053L;
      LOCKED = new uI("LOCKED", 0);
      SCALED = new uI("SCALED", 1);
   }
}

package com.gmail.olexorus.themis;

public interface Vh<T extends Rc, OUT> {
   default void D(OUT var1, T var2) {
      this.e(var1, var2, true);
   }

   void e(OUT var1, Rc var2, boolean var3);
}

package com.gmail.olexorus.themis;

public final class Cr {
   private final N3 c;
   private final float B;

   public Cr(N3 var1, float var2) {
      this.c = var1;
      this.B = var2;
   }

   public static Cr C(lm<?> var0) {
      N3 var1 = N3.F(var0);
      float var2 = var0.L();
      return new Cr(var1, var2);
   }

   public static void M(lm<?> var0, Cr var1) {
      N3.v(var0, var1.c);
      var0.S(var1.B);
   }
}

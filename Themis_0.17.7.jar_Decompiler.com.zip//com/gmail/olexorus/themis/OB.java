package com.gmail.olexorus.themis;

import java.util.HashMap;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.concurrent.ConcurrentSkipListSet;

class OB<K, V> extends HashMap<K, RS<K, V>> implements G2<K, V> {
   private static final long serialVersionUID = 1L;
   SortedSet<RS<K, V>> H;

   private OB() {
      this.H = new ConcurrentSkipListSet();
   }

   public void clear() {
      super.clear();
      this.H.clear();
   }

   public boolean containsValue(Object var1) {
      Iterator var2 = this.values().iterator();

      Object var4;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         RS var3 = (RS)var2.next();
         var4 = var3.T;
      } while(var4 != var1 && (var1 == null || !var1.equals(var4)));

      return true;
   }

   public RS<K, V> i() {
      return this.H.isEmpty() ? null : (RS)this.H.first();
   }

   public RS<K, V> B(K var1, RS<K, V> var2) {
      this.H.add(var2);
      return (RS)super.put(var1, var2);
   }

   public RS<K, V> L(Object var1) {
      RS var2 = (RS)super.remove(var1);
      if (var2 != null) {
         this.H.remove(var2);
      }

      return var2;
   }

   public void W(RS<K, V> var1) {
      this.H.remove(var1);
      var1.O();
      this.H.add(var1);
   }

   public Iterator<RS<K, V>> B() {
      return new cU(this);
   }

   OB(Ji var1) {
      this();
   }

   static Object T(OB var0, Object var1) {
      return var0.remove(var1);
   }
}

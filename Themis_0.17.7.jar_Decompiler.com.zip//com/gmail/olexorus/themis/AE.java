package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

final class AE extends Av<GY, A4> implements A4 {
   private String O;
   private String V;
   private List<VE> f = Collections.emptyList();
   private static final long b = kt.a(-8577229179504621223L, -9046954609442210169L, MethodHandles.lookup().lookupClass()).a(261058874120230L);

   AE() {
   }

   AE(GY var1) {
      super(var1);
      this.O = var1.p();
      this.f = var1.n();
      this.V = var1.R();
   }

   public A4 m(String var1) {
      this.O = var1;
      return this;
   }

   public A4 g(lv... var1) {
      long var2 = b ^ 39619615929308L;
      Objects.requireNonNull(var1, "args");
      return var1.length == 0 ? this.q(Collections.emptyList()) : this.q(Arrays.asList(var1));
   }

   public A4 q(List<? extends lv> var1) {
      long var2 = b ^ 69133207484485L;
      this.f = lO.L((List)Objects.requireNonNull(var1, "args"));
      return this;
   }

   public A4 R(String var1) {
      this.V = var1;
      return this;
   }

   public GY x() {
      long var1 = b ^ 122226250409990L;
      if (this.O == null) {
         throw new IllegalStateException("key must be set");
      } else {
         return lO.N(this.y, this.l(), this.O, this.V, this.f);
      }
   }
}

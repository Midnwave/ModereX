package com.gmail.olexorus.themis;

public class ZV extends lm<ZV> {
   private X J;

   public void t() {
      this.J = this.K();
   }

   public void d() {
      this.X(this.J);
   }

   public void Q(ZV var1) {
      this.J = var1.J;
   }
}

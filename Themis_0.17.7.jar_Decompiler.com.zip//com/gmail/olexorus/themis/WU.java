package com.gmail.olexorus.themis;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import java.lang.invoke.MethodHandles;

final class WU {
   private static final long a = kt.a(7953392671745388805L, -2581999469259453944L, MethodHandles.lookup().lookupClass()).a(277410612385954L);

   static boolean t(JsonElement var0) {
      return var0 == null || var0.isJsonNull() || var0.isJsonArray() && var0.getAsJsonArray().size() == 0 || var0.isJsonObject() && var0.getAsJsonObject().entrySet().isEmpty();
   }

   static boolean m(JsonReader var0) {
      long var1 = a ^ 90040055338337L;
      JsonToken var3 = var0.peek();
      if (var3 == JsonToken.BOOLEAN) {
         return var0.nextBoolean();
      } else if (var3 == JsonToken.STRING) {
         return Boolean.parseBoolean(var0.nextString());
      } else if (var3 == JsonToken.NUMBER) {
         return var0.nextString().equals("1");
      } else {
         throw new JsonParseException("Token of type " + var3 + " cannot be interpreted as a boolean");
      }
   }

   static String z(JsonReader var0) {
      long var1 = a ^ 99355896603142L;
      JsonToken var3 = var0.peek();
      if (var3 != JsonToken.STRING && var3 != JsonToken.NUMBER) {
         if (var3 == JsonToken.BOOLEAN) {
            return String.valueOf(var0.nextBoolean());
         } else {
            throw new JsonParseException("Token of type " + var3 + " cannot be interpreted as a string");
         }
      } else {
         return var0.nextString();
      }
   }
}

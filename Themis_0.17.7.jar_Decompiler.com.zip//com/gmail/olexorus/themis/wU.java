package com.gmail.olexorus.themis;

public interface wU {
   static wU I(lm<?> var0) {
      Bu var1 = (Bu)var0.y((VD)cM.U());
      return var1.M(var0);
   }

   static void Q(lm<?> var0, wU var1) {
      var0.j((GL)var1.U());
      var1.U().Q(var0, var1);
   }

   Bu<?> U();
}

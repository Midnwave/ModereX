package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public final class rh implements ListIterator, lK {
   public static final rh u = new rh();
   private static final long a = kt.a(6910426591032012143L, -7838388778476309014L, MethodHandles.lookup().lookupClass()).a(19561622066393L);

   private rh() {
   }

   public boolean hasNext() {
      return false;
   }

   public boolean hasPrevious() {
      return false;
   }

   public int nextIndex() {
      return 0;
   }

   public int previousIndex() {
      return -1;
   }

   public Void e() {
      throw new NoSuchElementException();
   }

   public Void J() {
      throw new NoSuchElementException();
   }

   public void remove() {
      long var1 = a ^ 40072446528407L;
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

final class nY extends n9 implements EP<y> {
   public static final nY n;
   private static final long a = kt.a(-2919001061336822450L, 4682123595341029733L, MethodHandles.lookup().lookupClass()).a(145195844527107L);
   private static final String b;

   nY() {
      super(0);
   }

   public final void L(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 ^= a;
      long var4 = var2 ^ 64074256780482L;
      Themis.g.n(new Object[]{var4}).getLogger().warning(b);
   }

   static {
      long var0 = a ^ 85526278214418L;
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)((int)(var0 >>> 56)), 0, 0, 0, 0, 0, 0, 0};

      for(int var3 = 1; var3 < 8; ++var3) {
         var10003[var3] = (byte)((int)(var0 << var3 * 8 >>> 56));
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var4 = var2.doFinal("&\u007f¡NÓ=æã\u0087\u0014Ò\u008d\u0019\u0016ù\u008f\u000b\u0005iýB»JHÄÎóüÂ¿µÒ\bäs:Àªôß\\è|\u001b^\u0016ä-\u0092S÷Ò¨âG\u0096âÑâ@ÁÀ\u001d\u000fCÌ\u0098\u009ayVp3\u001e÷7³Û!\u0091OH\u0015U\u008eZq\u008fà¹µ\u0082\u009bn\u0012Ê^".getBytes("ISO-8859-1"));
      String var5 = a(var4).intern();
      boolean var10001 = true;
      b = var5;
      n = new nY();
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for(int var4 = 0; var4 < var2; ++var4) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else {
            char var6;
            byte var7;
            if (var5 < 224) {
               var6 = (char)((char)(var5 & 31) << 6);
               ++var4;
               var7 = var0[var4];
               var6 |= (char)(var7 & 63);
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               var6 = (char)((char)(var5 & 15) << 12);
               ++var4;
               var7 = var0[var4];
               var6 = (char)(var6 | (char)(var7 & 63) << 6);
               ++var4;
               var7 = var0[var4];
               var6 |= (char)(var7 & 63);
               var3[var1++] = var6;
            }
         }
      }

      return new String(var3, 0, var1);
   }
}

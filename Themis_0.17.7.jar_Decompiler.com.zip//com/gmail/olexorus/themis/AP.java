package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum AP {
   MAIN_HAND,
   OFF_HAND,
   BOOTS,
   LEGGINGS,
   CHEST_PLATE,
   HELMET,
   BODY,
   SADDLE;

   private static final AP[] A;
   private final byte c;

   private AP(int var3) {
      this.c = (byte)var3;
   }

   public int q(zZ var1) {
      return this.K(var1.u());
   }

   public int K(vL var1) {
      return var1.X(vL.V_1_9) ? this.c : this.ordinal();
   }

   public static AP F(vL var0, int var1) {
      if (var0.X(vL.V_1_9)) {
         AP[] var2 = A;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            AP var5 = var2[var4];
            if (var5.K(var0) == var1) {
               return var5;
            }
         }

         return null;
      } else {
         return A[var1];
      }
   }

   public static AP Y(zZ var0, int var1) {
      return F(var0.u(), var1);
   }

   // $FF: synthetic method
   private static AP[] y() {
      return new AP[]{MAIN_HAND, OFF_HAND, BOOTS, LEGGINGS, CHEST_PLATE, HELMET, BODY, SADDLE};
   }

   static {
      long var0 = kt.a(-9115882085283928465L, -5269898934466401682L, MethodHandles.lookup().lookupClass()).a(2270314365545L) ^ 88556405909131L;
      MAIN_HAND = new AP("MAIN_HAND", 0, 0);
      OFF_HAND = new AP("OFF_HAND", 1, 0);
      BOOTS = new AP("BOOTS", 2, 1);
      LEGGINGS = new AP("LEGGINGS", 3, 2);
      CHEST_PLATE = new AP("CHEST_PLATE", 4, 3);
      HELMET = new AP("HELMET", 5, 4);
      BODY = new AP("BODY", 6, 0);
      SADDLE = new AP("SADDLE", 7, 0);
      A = values();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class bN {
   private static final N8<W2> b;
   public static final W2 i;
   public static final W2 D;
   public static final W2 J;
   public static final W2 x;
   public static final W2 p;
   public static final W2 a;
   public static final W2 X;
   public static final W2 f;
   public static final W2 v;
   public static final W2 l;
   public static final W2 Z;
   public static final W2 S;
   public static final W2 q;
   public static final W2 e;
   public static final W2 g;
   public static final W2 d;
   public static final W2 W;
   public static final W2 w;
   public static final W2 O;
   public static final W2 T;
   public static final W2 E;
   public static final W2 R;
   public static final W2 B;
   public static final W2 Q;
   public static final W2 c;
   public static final W2 o;
   public static final W2 z;
   public static final W2 y;
   public static final W2 j;
   public static final W2 u;
   public static final W2 N;
   public static final W2 G;
   public static final W2 H;
   public static final W2 A;
   public static final W2 K;
   public static final W2 P;
   public static final W2 L;
   public static final W2 t;
   public static final W2 h;
   public static final W2 M;
   public static final W2 C;
   public static final W2 s;
   public static final W2 I;
   public static final W2 r;
   public static final W2 U;
   public static final W2 k;
   public static final W2 m;
   public static final W2 F;
   public static final W2 n;
   public static final W2 Y;

   private static W2 Q(String var0) {
      return (W2)b.h(var0, ce::new);
   }

   public static N8<W2> Q() {
      return b;
   }

   public static W2 A(vL var0, int var1) {
      return (W2)b.e(var0, var1);
   }

   static {
      long var0 = kt.a(-1960209060105782934L, 8485238752388324463L, MethodHandles.lookup().lookupClass()).a(6704996401134L) ^ 140125121162278L;
      b = new N8("block_entity_type");
      i = Q("furnace");
      D = Q("chest");
      J = Q("trapped_chest");
      x = Q("ender_chest");
      p = Q("jukebox");
      a = Q("dispenser");
      X = Q("dropper");
      f = Q("sign");
      v = Q("hanging_sign");
      l = Q("mob_spawner");
      Z = Q("piston");
      S = Q("brewing_stand");
      q = Q("enchanting_table");
      e = Q("end_portal");
      g = Q("beacon");
      d = Q("skull");
      W = Q("daylight_detector");
      w = Q("hopper");
      O = Q("comparator");
      T = Q("banner");
      E = Q("structure_block");
      R = Q("end_gateway");
      B = Q("command_block");
      Q = Q("shulker_box");
      c = Q("bed");
      o = Q("conduit");
      z = Q("barrel");
      y = Q("smoker");
      j = Q("blast_furnace");
      u = Q("lectern");
      N = Q("bell");
      G = Q("jigsaw");
      H = Q("campfire");
      A = Q("beehive");
      K = Q("sculk_sensor");
      P = Q("calibrated_sculk_sensor");
      L = Q("sculk_catalyst");
      t = Q("sculk_shrieker");
      h = Q("chiseled_bookshelf");
      M = Q("suspicious_sand");
      C = Q("brushable_block");
      s = Q("decorated_pot");
      I = Q("crafter");
      r = Q("trial_spawner");
      U = Q("vault");
      k = Q("creaking_heart");
      m = Q("test_block");
      F = Q("test_instance_block");
      n = Q("shelf");
      Y = Q("copper_golem_statue");
      b.f();
   }
}

package com.gmail.olexorus.themis;

public interface nz {
   Object U(byte[] var1);

   Object k();
}

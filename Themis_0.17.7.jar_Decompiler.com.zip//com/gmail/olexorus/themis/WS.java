package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Map;

public class WS<K, V> extends WN<K, V> {
   private final V b;
   private static final long a = kt.a(3406190185646745903L, -7106759017005765657L, MethodHandles.lookup().lookupClass()).a(270010481627597L);

   public WS(K var1, V var2) {
      super(var1);
      this.b = var2;
   }

   public V L() {
      return this.b;
   }

   public void G(Map<K, V> var1) {
      var1.put(this.a(), this.L());
   }

   public String toString() {
      long var1 = a ^ 11556662594590L;
      return "+ " + this.a() + " : " + this.L();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.regex.MatchResult;
import java.util.regex.Pattern;

public interface zx extends vr<GB>, oP<GB> {
   long a = kt.a(7179977746505890786L, -1610370493886445689L, MethodHandles.lookup().lookupClass()).a(255079921552895L);

   default zx x(String var1) {
      return this.M(Pattern.compile(var1, 16));
   }

   zx M(Pattern var1);

   default zx m() {
      return this.B(1);
   }

   default zx B(int var1) {
      return this.Y(zx::lambda$times$0);
   }

   default zx Y(Bt<RM> var1) {
      return this.r(zx::lambda$condition$1);
   }

   zx r(bu var1);

   default zx R(lv var1) {
      X var2 = lv.z(var1);
      return this.S(zx::lambda$replacement$3);
   }

   default zx E(Function<nh, lv> var1) {
      long var2 = a ^ 119524967853701L;
      Objects.requireNonNull(var1, "replacement");
      return this.S(zx::lambda$replacement$4);
   }

   zx S(BiFunction<MatchResult, nh, lv> var1);

   private static lv lambda$replacement$4(Function var0, MatchResult var1, nh var2) {
      return (lv)var0.apply(var2);
   }

   private static lv lambda$replacement$3(X var0, MatchResult var1, nh var2) {
      return var0;
   }

   private static lv lambda$replacement$2(String var0, nh var1) {
      return var1.P(var0);
   }

   private static RM lambda$condition$1(Bt var0, MatchResult var1, int var2, int var3) {
      return (RM)var0.G(var2, var3);
   }

   private static RM lambda$times$0(int var0, int var1, int var2) {
      return var2 < var0 ? RM.REPLACE : RM.STOP;
   }
}

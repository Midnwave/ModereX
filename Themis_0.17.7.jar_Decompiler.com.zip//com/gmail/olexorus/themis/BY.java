package com.gmail.olexorus.themis;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class BY {
   public static final tw<BY> Y = (new cn()).I();
   public static final BY x = new BY(Collections.emptyMap());
   private final Map<Jf<?>, r4<?, ?>> j;

   private BY(Map<Jf<?>, r4<?, ?>> var1) {
      this.j = var1;
   }

   public static BY Y() {
      return new BY(new HashMap());
   }

   public BY m() {
      HashMap var1 = new HashMap(this.j);
      return new BY(Collections.unmodifiableMap(var1));
   }

   public <T> BY Y(Jf<T> var1, T var2) {
      this.y(var1, var2, bA.v());
      return this;
   }

   public <T, A> BY y(Jf<T> var1, A var2, bA<T, A> var3) {
      this.j.put(var1, new r4(var2, var3));
      return this;
   }

   public void e(BY var1) {
      this.j.putAll(var1.j);
   }

   public <T> T w(Jf<T> var1) {
      return this.B(var1, var1.F());
   }

   public <T> r4<T, ?> I(Jf<T> var1) {
      return (r4)this.j.get(var1);
   }

   public <T> T B(Jf<T> var1, T var2) {
      r4 var3 = this.I(var1);
      return var3 != null ? var3.W(var2) : var2;
   }

   public boolean z() {
      return this.j.isEmpty();
   }

   public boolean equals(Object var1) {
      return !(var1 instanceof BY) ? false : this.j.equals(((BY)var1).j);
   }

   public int hashCode() {
      return Objects.hashCode(this.j);
   }

   BY(Map var1, cn var2) {
      this(var1);
   }

   static Map P(BY var0) {
      return var0.j;
   }
}

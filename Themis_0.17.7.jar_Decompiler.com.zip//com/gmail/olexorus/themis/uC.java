package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class uC implements tw<List<? extends Rc>> {
   private static final long a = kt.a(-5686657534300544244L, -7820470146691033207L, MethodHandles.lookup().lookupClass()).a(182336380877370L);

   public List<? extends Rc> n(Rc var1, lm<?> var2) {
      long var3 = a ^ 11722211837077L;
      if (var1 instanceof m_) {
         return ((m_)var1).e();
      } else {
         ArrayList var6;
         int var8;
         int var9;
         if (var1 instanceof mW) {
            int[] var13 = ((mW)var1).F();
            var6 = new ArrayList(var13.length);
            int[] var15 = var13;
            var8 = var13.length;

            for(var9 = 0; var9 < var8; ++var9) {
               int var17 = var15[var9];
               var6.add(new mz(var17));
            }

            return var6;
         } else if (var1 instanceof Rq) {
            byte[] var12 = ((Rq)var1).T();
            var6 = new ArrayList(var12.length);
            byte[] var14 = var12;
            var8 = var12.length;

            for(var9 = 0; var9 < var8; ++var9) {
               byte var16 = var14[var9];
               var6.add(new mA(var16));
            }

            return var6;
         } else if (!(var1 instanceof mt)) {
            throw new to("Not a list: " + var1);
         } else {
            long[] var5 = ((mt)var1).i();
            var6 = new ArrayList(var5.length);
            long[] var7 = var5;
            var8 = var5.length;

            for(var9 = 0; var9 < var8; ++var9) {
               long var10 = var7[var9];
               var6.add(new mQ(var10));
            }

            return var6;
         }
      }
   }

   public Rc f(lm<?> var1, List<? extends Rc> var2) {
      if (var2.isEmpty()) {
         return new m_(Ay.Q, 0);
      } else {
         Ay var3 = m_.J(var2);
         m_ var7;
         if (var3 == Ay.K) {
            var7 = new m_(Ay.K, var2.size());
            Iterator var10 = var2.iterator();

            while(var10.hasNext()) {
               Rc var6 = (Rc)var10.next();
               var7.e(var6);
            }

            return var7;
         } else {
            int var5;
            if (var3 == Ay.X) {
               int[] var9 = new int[var2.size()];

               for(var5 = 0; var5 < var9.length; ++var5) {
                  var9[var5] = ((mz)var2.get(var5)).P();
               }

               return new mW(var9);
            } else if (var3 == Ay.I) {
               byte[] var8 = new byte[var2.size()];

               for(var5 = 0; var5 < var8.length; ++var5) {
                  var8[var5] = ((mA)var2.get(var5)).E();
               }

               return new Rq(var8);
            } else if (var3 != Ay.C) {
               var7 = new m_(var3, var2);
               return var7;
            } else {
               long[] var4 = new long[var2.size()];

               for(var5 = 0; var5 < var4.length; ++var5) {
                  var4[var5] = ((mQ)var2.get(var5)).Y();
               }

               return new mt(var4);
            }
         }
      }
   }
}

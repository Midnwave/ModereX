package com.gmail.olexorus.themis;

import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

public class VF implements uO {
   public final Map<UUID, WeakReference<Player>> D = new ConcurrentHashMap();

   public Object n(Object var1) {
      UUID var2 = ((Player)var1).getUniqueId();
      uV var3 = oS.J().X();
      Object var4 = var3.b(var2);
      if (var4 == null) {
         var4 = EO.L((Player)var1);
         if (var4 != null) {
            synchronized(var4) {
               if (lC.u(var4)) {
                  var3.a(var2, var4);
               }
            }
         }
      }

      return var4;
   }

   public Gs c(Object var1) {
      Player var2 = (Player)var1;
      Object var3 = this.n(var2);
      return var3 == null ? null : oS.J().X().p(var3);
   }
}

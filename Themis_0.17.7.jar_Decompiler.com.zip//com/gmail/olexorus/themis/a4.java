package com.gmail.olexorus.themis;

public interface a4<I extends X, O extends X, R> extends NP<I, R>, Ey<R, O> {
   O k(R var1);

   default O R(R var1) {
      return Ey.super.H(var1, (X)null);
   }

   default O H(R var1, O var2) {
      return Ey.super.H(var1, var2);
   }

   R h(I var1);

   default R z(I var1) {
      return this.D(var1, (Object)null);
   }

   default R D(I var1, R var2) {
      return var1 == null ? var2 : this.h(var1);
   }
}

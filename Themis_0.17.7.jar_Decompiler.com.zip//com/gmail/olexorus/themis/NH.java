package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum NH {
   PICKUP,
   QUICK_MOVE,
   SWAP,
   CLONE,
   THROW,
   QUICK_CRAFT,
   PICKUP_ALL,
   UNKNOWN;

   public static final NH[] VALUES;
   private static final NH[] J;

   public static NH p(int var0) {
      return var0 >= 0 && var0 < VALUES.length - 1 ? VALUES[var0] : UNKNOWN;
   }

   private static NH[] h() {
      return new NH[]{PICKUP, QUICK_MOVE, SWAP, CLONE, THROW, QUICK_CRAFT, PICKUP_ALL, UNKNOWN};
   }

   static {
      long var0 = kt.a(-4626056102724617344L, -1125797822361514835L, MethodHandles.lookup().lookupClass()).a(86774787717534L) ^ 6596688545395L;
      PICKUP = new NH("PICKUP", 0);
      QUICK_MOVE = new NH("QUICK_MOVE", 1);
      SWAP = new NH("SWAP", 2);
      CLONE = new NH("CLONE", 3);
      THROW = new NH("THROW", 4);
      QUICK_CRAFT = new NH("QUICK_CRAFT", 5);
      PICKUP_ALL = new NH("PICKUP_ALL", 6);
      UNKNOWN = new NH("UNKNOWN", 7);
      J = h();
      VALUES = values();
   }
}

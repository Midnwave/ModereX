package com.gmail.olexorus.themis;

public interface C {
   <V> V x(Va<V> var1);
}

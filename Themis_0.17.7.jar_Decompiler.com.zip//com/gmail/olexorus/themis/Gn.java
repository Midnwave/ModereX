package com.gmail.olexorus.themis;

public interface Gn<R> {
   R q(String var1, MC var2);

   default R h(String var1, byte var2) {
      return this.q(var1, bn.y(var2));
   }

   default R M(String var1, int var2) {
      return this.q(var1, bh.a(var2));
   }

   default R l(String var1, String var2) {
      return this.q(var1, BO.f(var2));
   }
}

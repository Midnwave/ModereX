package com.gmail.olexorus.themis;

import java.util.Iterator;
import java.util.Map.Entry;

public final class mT extends mq implements Iterator<Entry<K, V>> {
   final z4 t;

   public mT(z4 var1) {
      super(var1);
      this.t = var1;
   }

   public final Entry<K, V> W() {
      return zk.C(this.b());
   }
}

package com.gmail.olexorus.themis;

public final class OR extends OG {
}

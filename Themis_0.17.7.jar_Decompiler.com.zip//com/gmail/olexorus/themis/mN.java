package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum mN implements H {
   DEFAULT,
   NETHER;

   public static final tw<mN> CODEC;
   private final String o;
   private static final mN[] Q;

   private mN(String var3) {
      this.o = var3;
   }

   public String g() {
      return this.o;
   }

   private static mN[] P() {
      return new mN[]{DEFAULT, NETHER};
   }

   static {
      long var0 = kt.a(-9022712325886713946L, 4888224811685978828L, MethodHandles.lookup().lookupClass()).a(275806492583504L) ^ 75787686413920L;
      DEFAULT = new mN("DEFAULT", 0, "default");
      NETHER = new mN("NETHER", 1, "nether");
      Q = P();
      CODEC = g9.c(values());
   }
}

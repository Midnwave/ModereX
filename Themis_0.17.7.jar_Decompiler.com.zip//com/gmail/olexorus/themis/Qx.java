package com.gmail.olexorus.themis;

import java.util.UUID;

public class Qx extends lm<Qx> {
   private UUID i;
   private String z;
   private String X;
   private boolean x;
   private X s;

   public void t() {
      if (this.I.i(zZ.V_1_20_3)) {
         this.i = this.V();
      }

      this.z = this.A();
      this.X = this.m(40);
      if (this.I.i(zZ.V_1_17)) {
         this.x = this.P();
         boolean var1 = this.P();
         if (var1) {
            this.s = this.a();
         }
      }

   }

   public void d() {
      if (this.I.i(zZ.V_1_20_3)) {
         this.y(this.i);
      }

      this.I(this.z);
      this.a(this.X, 40);
      if (this.I.i(zZ.V_1_17)) {
         this.I(this.x);
         this.I(this.s != null);
         if (this.s != null) {
            this.G(this.s);
         }
      }

   }

   public void z(Qx var1) {
      this.i = var1.i;
      this.z = var1.z;
      this.X = var1.X;
      this.x = var1.x;
      this.s = var1.s;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class tp {
   private static final N8<bW> o;
   public static final bW t;
   public static final bW n;
   public static final bW V;
   public static final bW B;
   public static final bW P;
   public static final bW z;
   public static final bW H;
   public static final bW R;
   public static final bW u;
   public static final bW d;
   public static final bW M;
   public static final bW l;
   public static final bW m;
   public static final bW K;
   public static final bW y;
   public static final bW c;
   public static final bW r;
   public static final bW b;
   public static final bW k;
   public static final bW O;
   public static final bW v;
   public static final bW J;
   public static final bW f;
   public static final bW F;
   public static final bW G;
   public static final bW E;
   public static final bW T;
   public static final bW X;
   public static final bW I;
   public static final bW A;
   public static final bW C;
   public static final bW N;

   public static bW G(String var0, Wl var1) {
      return (bW)o.h(var0, tp::lambda$define$0);
   }

   public static N8<bW> w() {
      return o;
   }

   private static cd lambda$define$0(Wl var0, z2 var1) {
      return new cd(var1, var0);
   }

   static {
      long var0 = kt.a(-5750369449688325337L, -6579398049354068288L, MethodHandles.lookup().lookupClass()).a(256270730080628L) ^ 45553209312302L;
      o = new N8("easing_type");
      t = G("constant", nO::u);
      n = G("linear", nO::C);
      V = G("in_back", nO::L);
      B = G("in_bounce", nO::S);
      P = G("in_circ", nO::i);
      z = G("in_cubic", nO::h);
      H = G("in_elastic", nO::N);
      R = G("in_expo", nO::H);
      u = G("in_quad", nO::q);
      d = G("in_quart", nO::G);
      M = G("in_quint", nO::M);
      l = G("in_sine", nO::e);
      m = G("in_out_back", nO::j);
      K = G("in_out_bounce", nO::I);
      y = G("in_out_circ", nO::A);
      c = G("in_out_cubic", nO::Q);
      r = G("in_out_elastic", nO::t);
      b = G("in_out_expo", nO::J);
      k = G("in_out_quad", nO::P);
      O = G("in_out_quart", nO::x);
      v = G("in_out_quint", nO::y);
      J = G("in_out_sine", nO::D);
      f = G("out_back", nO::Z);
      F = G("out_bounce", nO::Y);
      G = G("out_circ", nO::w);
      E = G("out_cubic", nO::z);
      T = G("out_elastic", nO::g);
      X = G("out_expo", nO::m);
      I = G("out_quad", nO::R);
      A = G("out_quart", nO::k);
      C = G("out_quint", nO::r);
      N = G("out_sine", nO::n);
      o.f();
   }
}

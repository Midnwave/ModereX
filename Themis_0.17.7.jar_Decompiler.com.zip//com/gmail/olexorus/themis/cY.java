package com.gmail.olexorus.themis;

// $FF: synthetic class
class cY {
}

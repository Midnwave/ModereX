package com.gmail.olexorus.themis;

public interface ck<R, B extends oP<R>> {
}

package com.gmail.olexorus.themis;

public class nA implements RI {
   private final rw I;

   public nA(rw var1) {
      this.I = var1;
   }

   public static nA P(lm<?> var0) {
      rw var1 = var0.R().i(zZ.V_1_19_3) ? (rw)var0.w((Enum[])rw.values()) : rw.MISC;
      return new nA(var1);
   }

   public static void O(lm<?> var0, nA var1) {
      if (var0.R().i(zZ.V_1_19_3)) {
         var0.o((Enum)var1.o());
      }

   }

   public rw o() {
      return this.I;
   }
}

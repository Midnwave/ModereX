package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.stream.Stream;

final class B2 extends BG implements MR {
   private final float j;
   private static final long a = kt.a(4450286763914794415L, -4530228368599510165L, MethodHandles.lookup().lookupClass()).a(121580252041056L);

   B2(float var1) {
      this.j = var1;
   }

   public float t() {
      return this.j;
   }

   public byte l() {
      return (byte)(Gr.G(this.j) & 255);
   }

   public int p() {
      return Gr.G(this.j);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         B2 var2 = (B2)var1;
         return Float.floatToIntBits(this.j) == Float.floatToIntBits(var2.j);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Float.hashCode(this.j);
   }

   public Stream<? extends rE> T() {
      long var1 = a ^ 124970624058155L;
      return Stream.of(rE.G("value", this.j));
   }
}

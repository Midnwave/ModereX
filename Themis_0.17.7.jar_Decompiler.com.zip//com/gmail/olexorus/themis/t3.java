package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.stream.Collectors;

public class t3 {
   private StringBuilder e = new StringBuilder();
   private boolean b = false;
   private static final long a = kt.a(-7879311985274187762L, 8941814146151585505L, MethodHandles.lookup().lookupClass()).a(123441858360877L);

   public t3() {
      this.e.append("{");
   }

   public t3 X(String var1, String var2) {
      long var3 = a ^ 63820653772690L;
      if (var2 == null) {
         throw new IllegalArgumentException("JSON value must not be null");
      } else {
         this.D(var1, "\"" + f(var2) + "\"");
         return this;
      }
   }

   public t3 b(String var1, int var2) {
      this.D(var1, String.valueOf(var2));
      return this;
   }

   public t3 P(String var1, nl var2) {
      long var3 = a ^ 34214045317856L;
      if (var2 == null) {
         throw new IllegalArgumentException("JSON object must not be null");
      } else {
         this.D(var1, var2.toString());
         return this;
      }
   }

   public t3 v(String var1, nl[] var2) {
      long var3 = a ^ 97625783568531L;
      if (var2 == null) {
         throw new IllegalArgumentException("JSON values must not be null");
      } else {
         String var5 = (String)Arrays.stream(var2).map(nl::toString).collect(Collectors.joining(","));
         this.D(var1, "[" + var5 + "]");
         return this;
      }
   }

   private void D(String var1, String var2) {
      long var3 = a ^ 119504220700163L;
      if (this.e == null) {
         throw new IllegalStateException("JSON has already been built");
      } else if (var1 == null) {
         throw new IllegalArgumentException("JSON key must not be null");
      } else {
         if (this.b) {
            this.e.append(",");
         }

         this.e.append("\"").append(f(var1)).append("\":").append(var2);
         this.b = true;
      }
   }

   public nl I() {
      long var1 = a ^ 111158692613691L;
      if (this.e == null) {
         throw new IllegalStateException("JSON has already been built");
      } else {
         nl var3 = new nl(this.e.append("}").toString(), (W0)null);
         this.e = null;
         return var3;
      }
   }

   private static String f(String var0) {
      long var1 = a ^ 125065606114450L;
      StringBuilder var3 = new StringBuilder();

      for(int var4 = 0; var4 < var0.length(); ++var4) {
         char var5 = var0.charAt(var4);
         if (var5 == '"') {
            var3.append("\\\"");
         } else if (var5 == '\\') {
            var3.append("\\\\");
         } else if (var5 <= 15) {
            var3.append("\\u000").append(Integer.toHexString(var5));
         } else if (var5 <= 31) {
            var3.append("\\u00").append(Integer.toHexString(var5));
         } else {
            var3.append(var5);
         }
      }

      return var3.toString();
   }

   private static String lambda$appendField$0(String var0) {
      return "\"" + f(var0) + "\"";
   }
}

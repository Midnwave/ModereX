package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum cw implements GL {
   BLOCK,
   ENTITY;

   private final OU<?> p;
   private static final cw[] O;
   private static final long a = kt.a(-2453020369813561395L, -4214444178910070080L, MethodHandles.lookup().lookupClass()).a(233215033714195L);

   private cw(OU<?> var3) {
      this.p = var3;
   }

   public static cw A(OU<?> var0) {
      long var1 = a ^ 82843759269955L;
      if (var0 == null) {
         return null;
      } else {
         cw[] var3 = values();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            cw var6 = var3[var5];
            if (var6.p == var0) {
               return var6;
            }
         }

         throw new UnsupportedOperationException("Unsupported modern type: " + var0.f());
      }
   }

   public al f() {
      return this.p.f();
   }

   public int f(vL var1) {
      return this.p.f(var1);
   }

   private static cw[] o() {
      return new cw[]{BLOCK, ENTITY};
   }

   static {
      long var0 = a ^ 86138011220994L;
      BLOCK = new cw("BLOCK", 0, W4.s);
      ENTITY = new cw("ENTITY", 1, W4.f);
      O = o();
   }
}

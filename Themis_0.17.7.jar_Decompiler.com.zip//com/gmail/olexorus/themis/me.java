package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum me {
   STANDING,
   FALL_FLYING,
   SLEEPING,
   SWIMMING,
   SPIN_ATTACK,
   CROUCHING,
   LONG_JUMPING,
   DYING,
   CROAKING,
   USING_TONGUE,
   SITTING,
   ROARING,
   SNIFFING,
   EMERGING,
   DIGGING,
   SLIDING,
   SHOOTING,
   INHALING;

   public int O(vL var1) {
      if (this == DYING && var1.X(vL.V_1_17)) {
         return 6;
      } else {
         return this.ordinal() >= 11 && var1.X(vL.V_1_19_3) ? this.ordinal() - 1 : this.ordinal();
      }
   }

   public static me a(vL var0, int var1) {
      if (var1 == 6 && var0.X(vL.V_1_17)) {
         return DYING;
      } else {
         if (var1 >= 10 && var0.X(vL.V_1_19_3)) {
            ++var1;
         }

         return values()[var1];
      }
   }

   // $FF: synthetic method
   private static me[] P() {
      return new me[]{STANDING, FALL_FLYING, SLEEPING, SWIMMING, SPIN_ATTACK, CROUCHING, LONG_JUMPING, DYING, CROAKING, USING_TONGUE, SITTING, ROARING, SNIFFING, EMERGING, DIGGING, SLIDING, SHOOTING, INHALING};
   }

   static {
      long var0 = kt.a(3961280829638424046L, 2403264987693976544L, MethodHandles.lookup().lookupClass()).a(30200988832294L) ^ 104957285474872L;
      STANDING = new me("STANDING", 0);
      FALL_FLYING = new me("FALL_FLYING", 1);
      SLEEPING = new me("SLEEPING", 2);
      SWIMMING = new me("SWIMMING", 3);
      SPIN_ATTACK = new me("SPIN_ATTACK", 4);
      CROUCHING = new me("CROUCHING", 5);
      LONG_JUMPING = new me("LONG_JUMPING", 6);
      DYING = new me("DYING", 7);
      CROAKING = new me("CROAKING", 8);
      USING_TONGUE = new me("USING_TONGUE", 9);
      SITTING = new me("SITTING", 10);
      ROARING = new me("ROARING", 11);
      SNIFFING = new me("SNIFFING", 12);
      EMERGING = new me("EMERGING", 13);
      DIGGING = new me("DIGGING", 14);
      SLIDING = new me("SLIDING", 15);
      SHOOTING = new me("SHOOTING", 16);
      INHALING = new me("INHALING", 17);
   }
}

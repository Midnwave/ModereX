package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class Zc extends lm<Zc> {
   private Tp i;
   private static final long a = kt.a(5088855376083128671L, 2873992722199636553L, MethodHandles.lookup().lookupClass()).a(184700058179573L);

   public void t() {
      this.i = (Tp)this.t(ty.NEWER_THAN_OR_EQUALS, zZ.V_1_8, Zc::lambda$read$0, Zc::lambda$read$1);
   }

   public void d() {
      this.o(ty.NEWER_THAN_OR_EQUALS, zZ.V_1_8, this.i.ordinal(), this::lambda$write$2, lm::u);
   }

   public void b(Zc var1) {
      this.i = var1.i;
   }

   private void lambda$write$2(lm var1, Integer var2) {
      long var3 = a ^ 120399943598415L;
      if (this.I.i(zZ.V_1_16) && var2 == 2) {
         throw new IllegalStateException("The WrapperGameClientClientStatus.Action.OPEN_INVENTORY_ACTION enum constant is not supported on 1.16+ servers!");
      } else {
         var1.E(var2);
      }
   }

   private static Tp lambda$read$1(lm var0) {
      return Tp.f(var0.M());
   }

   private static Tp lambda$read$0(lm var0) {
      return Tp.f(var0.Q());
   }
}

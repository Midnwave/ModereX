package com.gmail.olexorus.themis;

import java.util.List;
import java.util.Objects;

public class ga {
   private rT E;
   private Integer m;
   private List<zR> b;
   private String u;

   public ga(rT var1, Integer var2, List<zR> var3, String var4) {
      this.E = var1;
      this.m = var2;
      this.b = var3;
      this.u = var4;
   }

   public static ga b(lm<?> var0) {
      rT var1 = (rT)var0.u(ga::lambda$read$0);
      Integer var2 = (Integer)var0.u(lm::f);
      List var3 = var0.j(zR::r);
      String var4 = var0.R().i(zZ.V_1_21_2) ? (String)var0.u(lm::A) : null;
      return new ga(var1, var2, var3, var4);
   }

   public static void s(lm<?> var0, ga var1) {
      var0.l(var1.E, lm::j);
      var0.l(var1.m, lm::L);
      var0.D(var1.b, zR::g);
      if (var0.R().i(zZ.V_1_21_2)) {
         var0.l(var1.u, lm::I);
      }

   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof ga)) {
         return false;
      } else {
         ga var2 = (ga)var1;
         if (!Objects.equals(this.E, var2.E)) {
            return false;
         } else if (!Objects.equals(this.m, var2.m)) {
            return false;
         } else {
            return !this.b.equals(var2.b) ? false : Objects.equals(this.u, var2.u);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.E, this.m, this.b, this.u});
   }

   private static rT lambda$read$0(lm var0) {
      return (rT)var0.e(iD::b);
   }
}

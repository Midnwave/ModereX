package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public enum Bb {
   OPEN_URL,
   OPEN_FILE,
   RUN_COMMAND,
   SUGGEST_COMMAND,
   CHANGE_PAGE,
   COPY_TO_CLIPBOARD,
   SHOW_DIALOG,
   CUSTOM;

   public static final l3<String, Bb> NAMES;
   private final String R;
   private final boolean i;
   private final Class<? extends gK> X;
   private static final Bb[] G;
   private static final long a = kt.a(5973863892613652968L, 7356373394370236870L, MethodHandles.lookup().lookupClass()).a(243036951197350L);

   private Bb(String var3, boolean var4, Class<? extends gK> var5) {
      this.R = var3;
      this.i = var4;
      this.X = var5;
   }

   public boolean i() {
      return this.i;
   }

   public boolean F(gK var1) {
      long var2 = a ^ 58739801965813L;
      Objects.requireNonNull(var1, "payload");
      return this.X.isAssignableFrom(var1.getClass());
   }

   public Class<? extends gK> M() {
      return this.X;
   }

   public String toString() {
      return this.R;
   }

   private static String lambda$static$0(Bb var0) {
      return var0.R;
   }

   private static Bb[] w() {
      return new Bb[]{OPEN_URL, OPEN_FILE, RUN_COMMAND, SUGGEST_COMMAND, CHANGE_PAGE, COPY_TO_CLIPBOARD, SHOW_DIALOG, CUSTOM};
   }

   static {
      long var0 = a ^ 16534554725453L;
      OPEN_URL = new Bb("OPEN_URL", 0, "open_url", true, EM.class);
      OPEN_FILE = new Bb("OPEN_FILE", 1, "open_file", false, EM.class);
      RUN_COMMAND = new Bb("RUN_COMMAND", 2, "run_command", true, EM.class);
      SUGGEST_COMMAND = new Bb("SUGGEST_COMMAND", 3, "suggest_command", true, EM.class);
      CHANGE_PAGE = new Bb("CHANGE_PAGE", 4, "change_page", true, l4.class);
      COPY_TO_CLIPBOARD = new Bb("COPY_TO_CLIPBOARD", 5, "copy_to_clipboard", true, EM.class);
      SHOW_DIALOG = new Bb("SHOW_DIALOG", 6, "show_dialog", false, tv.class);
      CUSTOM = new Bb("CUSTOM", 7, "custom", true, JR.class);
      G = w();
      NAMES = l3.Q(Bb.class, Bb::lambda$static$0);
   }
}

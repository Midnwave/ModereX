package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;
import java.util.Set;

final class R implements Nr {
   v1 P;
   BX p;
   Vd e;
   c8 w;
   Eb b;
   mk<?> c;
   String u;
   private static final long a = kt.a(3924471646477682471L, -5662852286697437210L, MethodHandles.lookup().lookupClass()).a(228808695970541L);

   R() {
      this.w = c8.W;
   }

   R(nn var1) {
      this.p = var1.k;
      this.e = var1.W;
      this.w = var1.L;
      this.b = var1.h;
      this.c = var1.l;
      this.u = var1.J;
      this.P = var1.q;
   }

   public Nr d(v1 var1) {
      this.P = var1;
      return this;
   }

   public Nr h(BX var1) {
      this.p = var1;
      return this;
   }

   public Nr X(BX var1) {
      if (this.p == null) {
         this.p = var1;
      }

      return this;
   }

   public Nr E(MJ var1) {
      this.e = var1 == null ? null : Vd.M(var1);
      return this;
   }

   public Nr e(ux var1, NW var2) {
      long var3 = a ^ 106827702580061L;
      Objects.requireNonNull(var2, "state");
      Objects.requireNonNull(var1, "decoration");
      this.w = this.w.z(var1, var2);
      return this;
   }

   public Nr c(ux var1, NW var2) {
      long var3 = a ^ 133965782565060L;
      Objects.requireNonNull(var2, "state");
      NW var5 = this.w.Y(var1);
      if (var5 == NW.NOT_SET) {
         this.w = this.w.z(var1, var2);
      }

      if (var5 != null) {
         return this;
      } else {
         throw new IllegalArgumentException(String.format("unknown decoration '%s'", var1));
      }
   }

   public Nr W(Eb var1) {
      this.b = var1;
      return this;
   }

   public Nr I(AT<?> var1) {
      this.c = AT.t(var1);
      return this;
   }

   public Nr s(String var1) {
      this.u = var1;
      return this;
   }

   public Nr F(WR var1, ba var2, Set<mb> var3) {
      long var4 = a ^ 15629861797713L;
      Objects.requireNonNull(var1, "style");
      Objects.requireNonNull(var2, "strategy");
      Objects.requireNonNull(var3, "merges");
      if (nn.R(var1, var2, var3)) {
         return this;
      } else {
         if (var3.contains(mb.COLOR)) {
            BX var6 = var1.z();
            if (var6 != null && (var2 == ba.ALWAYS || var2 == ba.IF_ABSENT_ON_TARGET && this.p == null)) {
               this.h(var6);
            }
         }

         if (var3.contains(mb.SHADOW_COLOR)) {
            Vd var10 = var1.K();
            if (var10 != null && (var2 == ba.ALWAYS || var2 == ba.IF_ABSENT_ON_TARGET && this.e == null)) {
               this.E(var10);
            }
         }

         if (var3.contains(mb.DECORATIONS)) {
            int var11 = 0;

            for(int var7 = c8.H.length; var11 < var7; ++var11) {
               ux var8 = c8.H[var11];
               NW var9 = var1.m(var8);
               if (var9 != NW.NOT_SET) {
                  if (var2 == ba.ALWAYS) {
                     this.e(var8, var9);
                  } else if (var2 == ba.IF_ABSENT_ON_TARGET) {
                     this.c(var8, var9);
                  }
               }
            }
         }

         if (var3.contains(mb.EVENTS)) {
            Eb var12 = var1.Q();
            if (var12 != null && (var2 == ba.ALWAYS || var2 == ba.IF_ABSENT_ON_TARGET && this.b == null)) {
               this.W(var12);
            }

            mk var13 = var1.U();
            if (var13 != null && (var2 == ba.ALWAYS || var2 == ba.IF_ABSENT_ON_TARGET && this.c == null)) {
               this.I(var13);
            }
         }

         if (var3.contains(mb.INSERTION)) {
            String var14 = var1.L();
            if (var14 != null && (var2 == ba.ALWAYS || var2 == ba.IF_ABSENT_ON_TARGET && this.u == null)) {
               this.s(var14);
            }
         }

         if (var3.contains(mb.FONT)) {
            v1 var15 = var1.U();
            if (var15 != null && (var2 == ba.ALWAYS || var2 == ba.IF_ABSENT_ON_TARGET && this.P == null)) {
               this.d(var15);
            }
         }

         return this;
      }
   }

   public nn Q() {
      return this.Z() ? nn.T : new nn(this.P, this.p, this.e, this.w, this.b, this.c, this.u);
   }

   private boolean Z() {
      return this.p == null && this.e == null && this.w == c8.W && this.b == null && this.c == null && this.u == null && this.P == null;
   }
}

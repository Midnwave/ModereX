package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.function.BiFunction;

public enum cK {
   SENDER,
   TARGET,
   CONTENT;

   public static final l3<String, cK> ID_INDEX;
   private final String Z;
   private final BiFunction<X, r0, X> O;
   private static final cK[] f;

   private cK(String var3, BiFunction<X, r0, X> var4) {
      this.Z = var3;
      this.O = var4;
   }

   public String Y() {
      return this.Z;
   }

   private static X lambda$static$2(X var0, r0 var1) {
      return var0;
   }

   private static X lambda$static$1(X var0, r0 var1) {
      return (X)(var1.k() != null ? var1.k() : X.f());
   }

   private static X lambda$static$0(X var0, r0 var1) {
      return var1.z();
   }

   private static cK[] B() {
      return new cK[]{SENDER, TARGET, CONTENT};
   }

   static {
      long var0 = kt.a(7369038020601995977L, 5147888292440152548L, MethodHandles.lookup().lookupClass()).a(155012196188208L) ^ 114810136663224L;
      SENDER = new cK("SENDER", 0, "sender", cK::lambda$static$0);
      TARGET = new cK("TARGET", 1, "target", cK::lambda$static$1);
      CONTENT = new cK("CONTENT", 2, "content", cK::lambda$static$2);
      f = B();
      ID_INDEX = l3.Q(cK.class, cK::Y);
   }
}

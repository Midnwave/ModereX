package com.gmail.olexorus.themis;

import java.util.function.Function;

class w4 implements tw<Z> {
   final Function z;
   final Function Y;
   final tw t;

   w4(tw var1, Function var2, Function var3) {
      this.t = var1;
      this.z = var2;
      this.Y = var3;
   }

   public Z n(Rc var1, lm<?> var2) {
      return this.z.apply(this.t.n(var1, var2));
   }

   public Rc j(lm<?> var1, Z var2) {
      return this.t.j(var1, this.Y.apply(var2));
   }
}

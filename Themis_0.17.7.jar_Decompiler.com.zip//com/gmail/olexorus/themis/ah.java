package com.gmail.olexorus.themis;

public class ah extends lm<ah> {
   private V p;
   private float y;
   private float z;

   public void t() {
      this.p = new V(this.o(), this.o(), this.o());
      this.y = this.L();
      this.z = this.L();
   }

   public void d() {
      this.v(this.p.f);
      this.v(this.p.K);
      this.v(this.p.r);
      this.S(this.y);
      this.S(this.z);
   }

   public void U(ah var1) {
      this.p = var1.p;
      this.y = var1.y;
      this.z = var1.z;
   }
}

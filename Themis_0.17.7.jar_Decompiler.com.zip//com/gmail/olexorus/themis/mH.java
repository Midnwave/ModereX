package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public final class mH {
   private gL a;
   private double d;
   private double B;
   private float u;
   private static final long b = kt.a(1762225101092090509L, -772722869457769212L, MethodHandles.lookup().lookupClass()).a(217726330207288L);

   public mH(gL var1, double var2, double var4, float var6) {
      this.a = var1;
      this.d = var2;
      this.B = var4;
      this.u = var6;
   }

   public static mH G(RT var0) {
      long var1 = b ^ 40865230794145L;
      gL var3 = WA.u(var0.N("type"));
      double var4 = var0.N("x").Q();
      double var6 = var0.N("z").Q();
      float var8 = var0.N("rotation").b();
      return new mH(var3, var4, var6, var8);
   }

   public static void J(RT var0, mH var1) {
      long var2 = b ^ 20488071958404L;
      var0.j("type", new mZ(var1.a.f().toString()));
      var0.j("x", new mO(var1.d));
      var0.j("z", new mO(var1.B));
      var0.j("rotation", new m6(var1.u));
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof mH)) {
         return false;
      } else {
         mH var2 = (mH)var1;
         if (Double.compare(var2.d, this.d) != 0) {
            return false;
         } else if (Double.compare(var2.B, this.B) != 0) {
            return false;
         } else {
            return Float.compare(var2.u, this.u) != 0 ? false : this.a.equals(var2.a);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.a, this.d, this.B, this.u});
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class c1 {
   private static final N8<gb> v;
   public static final gb m;
   public static final gb X;
   public static final gb i;
   public static final gb x;
   public static final gb t;
   public static final gb o;
   public static final gb N;
   private static final long a = kt.a(-3002088852452898993L, -4527702920484458231L, MethodHandles.lookup().lookupClass()).a(151633455218331L);

   public static N8<gb> z() {
      return v;
   }

   public static gb b(String var0, String var1) {
      long var2 = a ^ 11466267136457L;
      return f(var0, b1.N("entity.wolf" + var1 + ".ambient"), b1.N("entity.wolf" + var1 + ".death"), b1.N("entity.wolf" + var1 + ".growl"), b1.N("entity.wolf" + var1 + ".hurt"), b1.N("entity.wolf" + var1 + ".pant"), b1.N("entity.wolf" + var1 + ".whine"));
   }

   public static gb f(String var0, CW var1, CW var2, CW var3, CW var4, CW var5, CW var6) {
      return (gb)v.h(var0, c1::lambda$define$0);
   }

   private static i8 lambda$define$0(CW var0, CW var1, CW var2, CW var3, CW var4, CW var5, z2 var6) {
      return new i8(var6, var0, var1, var2, var3, var4, var5);
   }

   static {
      long var0 = a ^ 41505802820459L;
      v = new N8("wolf_sound_variant");
      m = b("classic", "");
      X = b("puglin", "_puglin");
      i = b("sad", "_sad");
      x = b("angry", "_angry");
      t = b("grumpy", "_grumpy");
      o = b("big", "_big");
      N = b("cute", "_cute");
      v.f();
   }
}

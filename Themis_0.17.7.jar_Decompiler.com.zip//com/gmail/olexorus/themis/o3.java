package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;

final class o3 implements Tg {
   private final StringBuilder B;
   private final ES O;
   private B5 E;
   private ES[] s;
   private int J;
   final Wr v;
   private static final long a = kt.a(4916378268503503077L, -7911418604307097171L, MethodHandles.lookup().lookupClass()).a(101845599912099L);

   private o3(Wr var1) {
      this.v = var1;
      this.B = new StringBuilder();
      this.O = new ES(this);
      this.s = new ES[8];
      this.J = -1;
   }

   public void S(WR var1) {
      int var2 = ++this.J;
      if (var2 >= this.s.length) {
         this.s = (ES[])Arrays.copyOf(this.s, this.s.length * 2);
      }

      ES var3 = this.s[var2];
      if (var3 == null) {
         this.s[var2] = var3 = new ES(this);
      }

      if (var2 > 0) {
         var3.s(this.s[var2 - 1]);
      } else {
         var3.B();
      }

      var3.p(var1);
   }

   public void B(String var1) {
      long var2 = a ^ 23786961934200L;
      if (!var1.isEmpty()) {
         if (this.J < 0) {
            throw new IllegalStateException("No style has been pushed!");
         }

         this.s[this.J].W();
         this.B.append(var1);
      }

   }

   public void F(WR var1) {
      long var2 = a ^ 99917000652091L;
      if (this.J-- < 0) {
         throw new IllegalStateException("Tried to pop beyond what was pushed!");
      }
   }

   void N(B5 var1) {
      if (this.E != var1) {
         String var2 = Wr.l(this.v, var1);
         if (var2 == null) {
            return;
         }

         this.B.append(Wr.n(this.v)).append(var2);
      }

      this.E = var1;
   }

   public String toString() {
      return this.B.toString();
   }

   o3(Wr var1, bz var2) {
      this(var1);
   }

   static ES e(o3 var0) {
      return var0.O;
   }

   static B5 h(o3 var0) {
      return var0.E;
   }
}

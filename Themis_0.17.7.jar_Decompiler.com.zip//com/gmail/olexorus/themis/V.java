package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class V {
   private static final V R = new V();
   public final double f;
   public final double K;
   public final double r;
   private static final long a = kt.a(2985848452545824846L, -3614128839005921842L, MethodHandles.lookup().lookupClass()).a(255572902479577L);

   public V() {
      this.f = 0.0D;
      this.K = 0.0D;
      this.r = 0.0D;
   }

   public V(double var1, double var3, double var5) {
      this.f = var1;
      this.K = var3;
      this.r = var5;
   }

   public static V c(lm<?> var0) {
      double var1 = var0.o();
      double var3 = var0.o();
      double var5 = var0.o();
      return new V(var1, var3, var5);
   }

   public static void q(lm<?> var0, V var1) {
      var0.v(var1.f);
      var0.v(var1.K);
      var0.v(var1.r);
   }

   public static V b(Rc var0, vL var1) {
      m_ var2 = (m_)var0;
      double var3 = ((mh)var2.t(0)).Q();
      double var5 = ((mh)var2.t(1)).Q();
      double var7 = ((mh)var2.t(2)).Q();
      return new V(var3, var5, var7);
   }

   public static Rc Q(V var0, vL var1) {
      m_ var2 = new m_(Ay.h, 3);
      var2.Z(new mO(var0.f));
      var2.Z(new mO(var0.K));
      var2.Z(new mO(var0.r));
      return var2;
   }

   public double o() {
      return this.f;
   }

   public double h() {
      return this.K;
   }

   public double D() {
      return this.r;
   }

   public boolean equals(Object var1) {
      if (var1 instanceof V) {
         V var4 = (V)var1;
         return this.f == var4.f && this.K == var4.K && this.r == var4.r;
      } else if (var1 instanceof r3) {
         r3 var3 = (r3)var1;
         return this.f == (double)var3.E && this.K == (double)var3.j && this.r == (double)var3.D;
      } else if (!(var1 instanceof VC)) {
         return false;
      } else {
         VC var2 = (VC)var1;
         return this.f == (double)var2.Q && this.K == (double)var2.R && this.r == (double)var2.e;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.f, this.K, this.r});
   }

   public VC G() {
      return new VC((int)this.f, (int)this.K, (int)this.r);
   }

   public String toString() {
      long var1 = a ^ 139588738152254L;
      return "X: " + this.f + ", Y: " + this.K + ", Z: " + this.r;
   }

   public static V g() {
      return R;
   }
}

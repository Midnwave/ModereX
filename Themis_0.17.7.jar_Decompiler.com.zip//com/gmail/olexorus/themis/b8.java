package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;

public class b8<T extends oh> {
   public static final tw<b8<?>> p = (new JI()).I();
   private VI<T> z;
   private T R;
   private static final long a = kt.a(135278632834574019L, -6219485775540628826L, MethodHandles.lookup().lookupClass()).a(159401021544080L);

   public b8(VI<T> var1, T var2) {
      this.z = var1;
      this.R = var2;
   }

   public b8(VI<T> var1) {
      this(var1, oh.z());
   }

   public static b8<?> Z(lm<?> var0) {
      VI var1 = (VI)var0.e(R3::k);
      return new b8(var1, var1.J(var0));
   }

   public static <T extends oh> void M(lm<?> var0, b8<T> var1) {
      var0.j((GL)var1.z);
      var1.x().c(var0, var1.R);
   }

   public VI<T> x() {
      return this.z;
   }

   public T l() {
      return this.R;
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof b8)) {
         return false;
      } else {
         b8 var2 = (b8)var1;
         return !this.z.equals(var2.z) ? false : this.R.equals(var2.R);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.z, this.R});
   }

   public String toString() {
      long var1 = a ^ 139586680463035L;
      return "Particle[" + this.z.f() + ", " + this.R + ']';
   }

   static VI E(b8 var0) {
      return var0.z;
   }
}

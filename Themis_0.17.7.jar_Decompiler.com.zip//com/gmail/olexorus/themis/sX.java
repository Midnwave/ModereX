package com.gmail.olexorus.themis;

public class sX extends lm<sX> {
   private long a;

   public void t() {
      this.a = this.k();
   }

   public void d() {
      this.A(this.a);
   }

   public void f(sX var1) {
      this.a = var1.a;
   }
}

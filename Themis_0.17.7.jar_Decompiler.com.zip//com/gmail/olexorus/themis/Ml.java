package com.gmail.olexorus.themis;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Ml {
   private UUID R;
   private String h;
   private List<m8> N;

   public Ml(UUID var1, String var2) {
      this.R = var1;
      this.h = var2;
      this.N = new ArrayList();
   }

   public UUID J() {
      return this.R;
   }

   public void G(UUID var1) {
      this.R = var1;
   }

   public String s() {
      return this.h;
   }

   public void s(String var1) {
      this.h = var1;
   }

   public List<m8> k() {
      return this.N;
   }

   public void y(List<m8> var1) {
      this.N = var1;
   }
}

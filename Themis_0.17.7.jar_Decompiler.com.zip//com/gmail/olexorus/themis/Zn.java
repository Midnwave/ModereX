package com.gmail.olexorus.themis;

import java.time.Instant;
import java.util.List;

public class Zn extends lm<Zn> {
   private String H;
   private Bv A;
   private List<cv> n;
   private zf M;
   private GA u;

   public void t() {
      this.H = this.m(256);
      Instant var1 = this.V();
      long var2 = this.k();
      this.A = new Bv(new Wi(var2, new byte[0]), var1);
      this.n = this.a();
      if (this.I.i(zZ.V_1_19_3)) {
         this.M = this.C();
      } else {
         boolean var4 = this.P();
         this.A.d(var4);
         if (this.I.i(zZ.V_1_19_1)) {
            this.u = this.N();
         }
      }

   }

   public void d() {
      this.a(this.H, 256);
      this.e(this.A.Z());
      this.A(this.A.I().e());
      this.y(this.n);
      if (this.I.i(zZ.V_1_19_3)) {
         if (this.M != null) {
            this.C(this.M);
         }
      } else {
         this.I(this.A.X());
         if (this.I.i(zZ.V_1_19_1) && this.u != null) {
            this.f(this.u);
         }
      }

   }

   public void l(Zn var1) {
      this.H = var1.H;
      this.A = var1.A;
      this.n = var1.n;
      this.M = var1.M;
      this.u = var1.u;
   }
}

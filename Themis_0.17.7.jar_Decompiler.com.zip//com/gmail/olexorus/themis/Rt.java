package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum Rt {
   FALSE,
   LOW,
   NONE,
   SIDE,
   TALL,
   TRUE,
   UP;

   // $FF: synthetic method
   private static Rt[] d() {
      return new Rt[]{FALSE, LOW, NONE, SIDE, TALL, TRUE, UP};
   }

   static {
      long var0 = kt.a(-4649574225702902707L, -8946962860864849906L, MethodHandles.lookup().lookupClass()).a(241938115196313L) ^ 124797743185746L;
      FALSE = new Rt("FALSE", 0);
      LOW = new Rt("LOW", 1);
      NONE = new Rt("NONE", 2);
      SIDE = new Rt("SIDE", 3);
      TALL = new Rt("TALL", 4);
      TRUE = new Rt("TRUE", 5);
      UP = new Rt("UP", 6);
   }
}

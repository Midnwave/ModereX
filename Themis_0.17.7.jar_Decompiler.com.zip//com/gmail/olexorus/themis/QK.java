package com.gmail.olexorus.themis;

public class QK extends lm<QK> {
   private int S;
   private TU B;

   public QK(int var1, TU var2) {
      super((wC)rX.SET_PLAYER_INVENTORY);
      this.S = var1;
      this.B = var2;
   }

   public void t() {
      this.S = this.Q();
      this.B = this.u();
   }

   public void d() {
      this.E(this.S);
      this.m(this.B);
   }

   public void y(QK var1) {
      this.S = var1.S;
      this.B = var1.B;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;

final class nn implements WR {
   static final nn T;
   final v1 q;
   final BX k;
   final Vd W;
   final c8 L;
   final Eb h;
   final mk<?> l;
   final String J;
   private static final long a = kt.a(318710699567865545L, 3359349440691145293L, MethodHandles.lookup().lookupClass()).a(207038795697756L);

   nn(v1 var1, BX var2, Vd var3, Map<ux, NW> var4, Eb var5, mk<?> var6, String var7) {
      this.q = var1;
      this.k = var2;
      this.W = var3;
      this.L = c8.l(var4);
      this.h = var5;
      this.l = var6;
      this.J = var7;
   }

   public v1 U() {
      return this.q;
   }

   public BX z() {
      return this.k;
   }

   public WR b(BX var1) {
      return Objects.equals(this.k, var1) ? this : new nn(this.q, var1, this.W, this.L, this.h, this.l, this.J);
   }

   public Vd K() {
      return this.W;
   }

   public WR Y(MJ var1) {
      return Objects.equals(this.W, var1) ? this : new nn(this.q, this.k, var1 == null ? null : Vd.M(var1), this.L, this.h, this.l, this.J);
   }

   public NW m(ux var1) {
      long var2 = a ^ 10820135655346L;
      NW var4 = this.L.Y(var1);
      if (var4 != null) {
         return var4;
      } else {
         throw new IllegalArgumentException(String.format("unknown decoration '%s'", var1));
      }
   }

   public WR T(ux var1, NW var2) {
      long var3 = a ^ 21506962970304L;
      Objects.requireNonNull(var2, "state");
      return this.m(var1) == var2 ? this : new nn(this.q, this.k, this.W, this.L.z(var1, var2), this.h, this.l, this.J);
   }

   public Eb Q() {
      return this.h;
   }

   public mk<?> U() {
      return this.l;
   }

   public WR I(AT<?> var1) {
      return new nn(this.q, this.k, this.W, this.L, this.h, AT.t(var1), this.J);
   }

   public String L() {
      return this.J;
   }

   public WR V(WR var1, ba var2, Set<mb> var3) {
      if (R(var1, var2, var3)) {
         return this;
      } else if (this.A() && mb.r(var3)) {
         return var1;
      } else {
         Nr var4 = this.y();
         var4.F(var1, var2, var3);
         return var4.C();
      }
   }

   static boolean R(WR var0, ba var1, Set<mb> var2) {
      if (var1 == ba.NEVER) {
         return true;
      } else if (var0.A()) {
         return true;
      } else {
         return var2.isEmpty();
      }
   }

   public boolean A() {
      return this == T;
   }

   public Nr y() {
      return new R(this);
   }

   public Stream<? extends rE> T() {
      long var1 = a ^ 126017129942045L;
      return Stream.concat(this.L.T(), Stream.of(rE.E("color", this.k), rE.E("shadowColor", this.W), rE.E("clickEvent", this.h), rE.E("hoverEvent", this.l), rE.c("insertion", this.J), rE.E("font", this.q)));
   }

   public String toString() {
      return cH.M(this);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof nn)) {
         return false;
      } else {
         nn var2 = (nn)var1;
         return Objects.equals(this.k, var2.k) && this.L.equals(var2.L) && Objects.equals(this.W, var2.W) && Objects.equals(this.h, var2.h) && Objects.equals(this.l, var2.l) && Objects.equals(this.J, var2.J) && Objects.equals(this.q, var2.q);
      }
   }

   public int hashCode() {
      int var1 = Objects.hashCode(this.k);
      var1 = 31 * var1 + Objects.hashCode(this.W);
      var1 = 31 * var1 + this.L.hashCode();
      var1 = 31 * var1 + Objects.hashCode(this.h);
      var1 = 31 * var1 + Objects.hashCode(this.l);
      var1 = 31 * var1 + Objects.hashCode(this.J);
      var1 = 31 * var1 + Objects.hashCode(this.q);
      return var1;
   }

   static {
      T = new nn((v1)null, (BX)null, (Vd)null, c8.W, (Eb)null, (mk)null, (String)null);
   }
}

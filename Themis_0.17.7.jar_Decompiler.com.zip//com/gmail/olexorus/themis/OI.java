package com.gmail.olexorus.themis;

class OI extends Oy {
}

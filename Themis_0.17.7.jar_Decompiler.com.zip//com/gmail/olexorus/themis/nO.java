package com.gmail.olexorus.themis;

public final class nO {
   public static float u(float var0) {
      return 0.0F;
   }

   public static float C(float var0) {
      return var0;
   }

   public static float L(float var0) {
      float var1 = 1.70158F;
      float var2 = var1 + 1.0F;
      return var0 * var0 * (var2 * var0 - var1);
   }

   public static float S(float var0) {
      return 1.0F - Y(1.0F - var0);
   }

   public static float h(float var0) {
      return var0 * var0 * var0;
   }

   public static float N(float var0) {
      if (var0 == 0.0F) {
         return 0.0F;
      } else if (var0 == 1.0F) {
         return 1.0F;
      } else {
         float var1 = 2.0943952F;
         return (float)(-Math.pow(2.0D, 10.0D * (double)var0 - 10.0D) * Math.sin(((double)var0 * 10.0D - 10.75D) * (double)var1));
      }
   }

   public static float H(float var0) {
      return var0 == 0.0F ? 0.0F : (float)Math.pow(2.0D, 10.0D * (double)var0 - 10.0D);
   }

   public static float G(float var0) {
      return var0 * var0 * var0 * var0;
   }

   public static float M(float var0) {
      return var0 * var0 * var0 * var0 * var0;
   }

   public static float e(float var0) {
      return 1.0F - (float)Math.cos((double)(var0 * 1.5707964F));
   }

   public static float I(float var0) {
      return var0 < 0.5F ? (1.0F - Y(1.0F - 2.0F * var0)) / 2.0F : (1.0F + Y(2.0F * var0 - 1.0F)) / 2.0F;
   }

   public static float A(float var0) {
      return var0 < 0.5F ? (float)((1.0D - Math.sqrt(1.0D - Math.pow(2.0D * (double)var0, 2.0D))) / 2.0D) : (float)((Math.sqrt(1.0D - Math.pow(-2.0D * (double)var0 + 2.0D, 2.0D)) + 1.0D) / 2.0D);
   }

   public static float Q(float var0) {
      return var0 < 0.5F ? 4.0F * var0 * var0 * var0 : (float)(1.0D - Math.pow(-2.0D * (double)var0 + 2.0D, 3.0D) / 2.0D);
   }

   public static float P(float var0) {
      return var0 < 0.5F ? 2.0F * var0 * var0 : (float)(1.0D - Math.pow(-2.0D * (double)var0 + 2.0D, 2.0D) / 2.0D);
   }

   public static float x(float var0) {
      return var0 < 0.5F ? 8.0F * var0 * var0 * var0 * var0 : (float)(1.0D - Math.pow(-2.0D * (double)var0 + 2.0D, 4.0D) / 2.0D);
   }

   public static float y(float var0) {
      return (double)var0 < 0.5D ? 16.0F * var0 * var0 * var0 * var0 * var0 : (float)(1.0D - Math.pow(-2.0D * (double)var0 + 2.0D, 5.0D) / 2.0D);
   }

   public static float Y(float var0) {
      float var1 = 7.5625F;
      float var2 = 2.75F;
      if (var0 < 1.0F / var2) {
         return var1 * var0 * var0;
      } else if (var0 < 2.0F / var2) {
         return var1 * a8.p(var0 - 1.5F / var2) + 0.75F;
      } else {
         return (double)var0 < (double)(2.5F / var2) ? var1 * a8.p(var0 - 2.25F / var2) + 0.9375F : var1 * a8.p(var0 - 2.625F / var2) + 0.984375F;
      }
   }

   public static float g(float var0) {
      float var1 = 2.0943952F;
      if (var0 == 0.0F) {
         return 0.0F;
      } else {
         return var0 == 1.0F ? 1.0F : (float)(Math.pow(2.0D, -10.0D * (double)var0) * Math.sin(((double)var0 * 10.0D - 0.75D) * (double)var1) + 1.0D);
      }
   }

   public static float m(float var0) {
      return var0 == 1.0F ? 1.0F : 1.0F - (float)Math.pow(2.0D, -10.0D * (double)var0);
   }

   public static float R(float var0) {
      return 1.0F - a8.p(1.0F - var0);
   }

   public static float r(float var0) {
      return 1.0F - (float)Math.pow(1.0D - (double)var0, 5.0D);
   }

   public static float n(float var0) {
      return (float)Math.sin((double)(var0 * 1.5707964F));
   }

   public static float D(float var0) {
      return -((float)Math.cos((double)(3.1415927F * var0)) - 1.0F) / 2.0F;
   }

   public static float Z(float var0) {
      float var1 = 1.70158F;
      float var2 = 2.70158F;
      return 1.0F + var2 * a8.B(var0 - 1.0F) + var1 * a8.p(var0 - 1.0F);
   }

   public static float k(float var0) {
      return 1.0F - a8.p(a8.p(1.0F - var0));
   }

   public static float z(float var0) {
      return 1.0F - a8.B(1.0F - var0);
   }

   public static float J(float var0) {
      if (var0 == 0.0F) {
         return 0.0F;
      } else if (var0 == 1.0F) {
         return 1.0F;
      } else {
         return var0 < 0.5F ? (float)(Math.pow(2.0D, 20.0D * (double)var0 - 10.0D) / 2.0D) : (float)((2.0D - Math.pow(2.0D, -20.0D * (double)var0 + 10.0D)) / 2.0D);
      }
   }

   public static float q(float var0) {
      return var0 * var0;
   }

   public static float w(float var0) {
      return (float)Math.sqrt((double)(1.0F - a8.p(var0 - 1.0F)));
   }

   public static float t(float var0) {
      float var1 = 1.3962635F;
      if (var0 == 0.0F) {
         return 0.0F;
      } else if (var0 == 1.0F) {
         return 1.0F;
      } else {
         double var2 = Math.sin((20.0D * (double)var0 - 11.125D) * (double)var1);
         return var0 < 0.5F ? (float)(-(Math.pow(2.0D, 20.0D * (double)var0 - 10.0D) * var2) / 2.0D) : (float)(Math.pow(2.0D, -20.0D * (double)var0 + 10.0D) * var2 / 2.0D + 1.0D);
      }
   }

   public static float i(float var0) {
      return (float)(-Math.sqrt((double)(1.0F - var0 * var0))) + 1.0F;
   }

   public static float j(float var0) {
      float var1 = 1.70158F;
      float var2 = var1 * 1.525F;
      if (var0 < 0.5F) {
         return 4.0F * var0 * var0 * (2.0F * (var2 + 1.0F) * var0 - var2) / 2.0F;
      } else {
         float var3 = 2.0F * var0 - 2.0F;
         return (var3 * var3 * ((var2 + 1.0F) * var3 + var2) + 2.0F) / 2.0F;
      }
   }
}

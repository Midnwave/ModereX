package com.gmail.olexorus.themis;

class Of extends OH {
}

package com.gmail.olexorus.themis;

import java.util.List;
import java.util.Objects;

public class Bj {
   private int J;
   private List<cI> V;

   public Bj(int var1, List<cI> var2) {
      this.J = var1;
      this.V = var2;
   }

   public static Bj q(lm<?> var0) {
      int var1 = var0.Q();
      List var2 = var0.j(cI::T);
      return new Bj(var1, var2);
   }

   public static void u(lm<?> var0, Bj var1) {
      var0.E(var1.J);
      var0.D(var1.V, cI::y);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof Bj)) {
         return false;
      } else {
         Bj var2 = (Bj)var1;
         return this.J != var2.J ? false : this.V.equals(var2.V);
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.J, this.V});
   }
}

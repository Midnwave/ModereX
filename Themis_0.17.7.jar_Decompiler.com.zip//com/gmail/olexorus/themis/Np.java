package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

final class Np {
   static final String c;

   static boolean R(char var0) {
      return var0 >= 'a' && var0 <= 'z' || var0 >= 'A' && var0 <= 'Z' || var0 >= '0' && var0 <= '9' || var0 == '-' || var0 == '_' || var0 == '.' || var0 == '+';
   }

   static boolean h(char var0) {
      return var0 >= '0' && var0 <= '9' || var0 == '+' || var0 == '-' || var0 == 'e' || var0 == 'E' || var0 == '.';
   }

   static {
      long var0 = kt.a(-4601011997654512924L, 5858028728842832779L, MethodHandles.lookup().lookupClass()).a(124776087154869L) ^ 101849992092672L;
      c = System.getProperty("line.separator", "\n");
   }
}

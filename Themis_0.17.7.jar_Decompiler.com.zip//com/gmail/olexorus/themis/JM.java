package com.gmail.olexorus.themis;

public class JM extends RuntimeException {
   JM(String var1) {
      super(var1);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class yK extends lm<yK> {
   private int D;
   private int c;
   private static final long a = kt.a(694315753119385796L, -4650671251083017402L, MethodHandles.lookup().lookupClass()).a(203554412795740L);

   public void t() {
      long var1 = a ^ 102892054643125L;
      this.D = this.Q();
      this.c = this.Q();
      if (this.c < 0 && this.c != -1) {
         throw new IllegalArgumentException("Invalid selectedItemIndex: " + this.c);
      }
   }

   public void d() {
      this.E(this.D);
      this.E(this.c);
   }

   public void G(yK var1) {
      this.D = var1.D;
      this.c = var1.c;
   }
}

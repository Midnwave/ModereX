package com.gmail.olexorus.themis;

import com.gmail.olexorus.themis.api.CheckType;
import java.lang.invoke.MethodHandles;
import java.util.UUID;
import org.bukkit.entity.Player;

public final class Ww {
   private static int[] m;
   private static final long a = kt.a(-2522328812928119739L, -9103255840416909813L, MethodHandles.lookup().lookupClass()).a(185799184940919L);

   public static final Vb g(Object[] var0) {
      Player var1 = (Player)var0[0];
      return Ea.N.x(new Object[]{var1.getUniqueId()});
   }

   public static final Vb Z(Object[] var0) {
      long var2 = (Long)var0[0];
      Gs var1 = (Gs)var0[1];
      long var10000 = a ^ var2;
      int[] var4 = Vb.m();

      UUID var8;
      Vb var9;
      label33: {
         try {
            if (var4 != null) {
               var8 = var1.e();
               if (var8 != null) {
                  break label33;
               }
            }
         } catch (RuntimeException var7) {
            throw a(var7);
         }

         var9 = null;
         return var9;
      }

      UUID var5 = var8;
      boolean var6 = false;
      var9 = Ea.N.x(new Object[]{var5});
      return var9;
   }

   public static final oG d(Object[] var0) {
      long var2 = (Long)var0[0];
      Player var4 = (Player)var0[1];
      CheckType var1 = (CheckType)var0[2];
      var2 ^= a;
      long var5 = var2 ^ 85337539837061L;
      return Ea.N.P(new Object[]{var4, var1, var5});
   }

   public static void T(int[] var0) {
      m = var0;
   }

   public static int[] U() {
      return m;
   }

   static {
      if (U() != null) {
         T(new int[3]);
      }

   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}

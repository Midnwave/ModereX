package com.gmail.olexorus.themis;

import java.util.Objects;
import java.util.OptionalLong;

public class cx extends id implements AR, Cy {
   private final boolean v;
   private final T0 G;
   private final mN K;
   private final BY s;
   private final Ng<cV> D;
   private gC<cV> Q;
   private final Long Y;
   private final boolean m;
   private final boolean L;
   private final boolean q;
   private final al b;
   private final double i;
   private final int E;
   private final int p;
   private final Rc B;
   private final int P;
   private final boolean h;
   private final boolean y;
   private final int X;
   private final rO R;
   private final float S;

   public cx(OptionalLong var1, boolean var2, boolean var3, boolean var4, boolean var5, double var6, boolean var8, boolean var9, int var10, int var11, int var12, String var13, al var14, float var15, boolean var16, boolean var17, Rc var18, int var19) {
      this(var1, var2, var3, var4, var5, var6, var8, var9, var10, var11, var12, var13, var14, var15, 192, var16, var17, var18, var19);
   }

   public cx(OptionalLong var1, boolean var2, boolean var3, boolean var4, boolean var5, double var6, boolean var8, boolean var9, int var10, int var11, int var12, String var13, al var14, float var15, Integer var16, boolean var17, boolean var18, Rc var19, int var20) {
      this((z2)null, var1.isPresent(), T0.OVERWORLD, mN.DEFAULT, BY.Y().Y(Bg.R, var4).Y(Bg.l, var16 != null ? (float)var16 : 192.0F).Y(Bg.Y, !var17).Y(Bg.n, var18).m(), gC.l(), var1.isPresent() ? var1.getAsLong() : null, var5, var8, var9, var14, var6, var10, var11, (Rc)(var19 != null ? var19 : new mz(7)), var20, var2, var3, var12, rO.c(var13), var15);
   }

   public cx(z2 var1, boolean var2, T0 var3, mN var4, BY var5, Ng<cV> var6, Long var7, boolean var8, boolean var9, boolean var10, al var11, double var12, int var14, int var15, Rc var16, int var17, boolean var18, boolean var19, int var20, rO var21, float var22) {
      super(var1);
      this.v = var2;
      this.G = var3;
      this.K = var4;
      this.s = var5;
      this.D = var6;
      this.Y = var7;
      this.m = var8;
      this.L = var9;
      this.q = var10;
      this.b = var11;
      this.i = var12;
      this.E = var14;
      this.p = var15;
      this.B = var16;
      this.P = var17;
      this.h = var18;
      this.y = var19;
      this.X = var20;
      this.R = var21;
      this.S = var22;
   }

   public void w(lm<?> var1) {
      VD var2 = var1.w((VD)Tu.U());
      this.Q = this.D.o(var1, var2);
   }

   public AR a(z2 var1) {
      return new cx(this.f, this.v, this.G, this.K, this.s, this.D, this.Y, this.m, this.L, this.q, this.b, this.i, this.E, this.p, this.B, this.P, this.h, this.y, this.X, this.R, this.S);
   }

   public boolean q() {
      return this.v;
   }

   public OptionalLong n() {
      return this.Y != null ? OptionalLong.of(this.Y) : OptionalLong.empty();
   }

   public boolean D() {
      return this.h;
   }

   public boolean y() {
      return this.y;
   }

   public boolean v() {
      return (Boolean)this.s.w(Bg.R);
   }

   public boolean U() {
      return this.m;
   }

   public double T() {
      return this.i;
   }

   public boolean a() {
      return this.L;
   }

   public boolean c() {
      return this.q;
   }

   public int N() {
      return this.E;
   }

   public int C() {
      return this.p;
   }

   public int s() {
      return this.X;
   }

   public rO F() {
      return this.R;
   }

   public al y() {
      if (this.b == null) {
         throw new UnsupportedOperationException();
      } else {
         return this.b;
      }
   }

   public float t() {
      return this.S;
   }

   public Integer j() {
      return ((Float)this.s.w(Bg.l)).intValue();
   }

   public boolean g() {
      return !(Boolean)this.s.w(Bg.t);
   }

   public boolean w() {
      return (Boolean)this.s.w(Bg.n);
   }

   public Rc K() {
      return this.B;
   }

   public int x() {
      return this.P;
   }

   public T0 A() {
      return this.G;
   }

   public mN M() {
      return this.K;
   }

   public BY f() {
      return this.s;
   }

   public gC<cV> J() {
      if (this.Q == null) {
         throw new UnsupportedOperationException();
      } else {
         return this.Q;
      }
   }

   public Ng<cV> Q() {
      return this.D;
   }

   public boolean I(Object var1) {
      if (var1 != null && this.getClass() == var1.getClass()) {
         if (!super.equals(var1)) {
            return false;
         } else {
            cx var2 = (cx)var1;
            if (this.v != var2.v) {
               return false;
            } else if (this.m != var2.m) {
               return false;
            } else if (this.L != var2.L) {
               return false;
            } else if (this.q != var2.q) {
               return false;
            } else if (Double.compare(var2.i, this.i) != 0) {
               return false;
            } else if (this.E != var2.E) {
               return false;
            } else if (this.p != var2.p) {
               return false;
            } else if (this.P != var2.P) {
               return false;
            } else if (this.h != var2.h) {
               return false;
            } else if (this.y != var2.y) {
               return false;
            } else if (this.X != var2.X) {
               return false;
            } else if (Float.compare(var2.S, this.S) != 0) {
               return false;
            } else if (this.G != var2.G) {
               return false;
            } else if (this.K != var2.K) {
               return false;
            } else if (!this.s.equals(var2.s)) {
               return false;
            } else if (!this.D.equals(var2.D)) {
               return false;
            } else if (!Objects.equals(this.Y, var2.Y)) {
               return false;
            } else if (!Objects.equals(this.b, var2.b)) {
               return false;
            } else {
               return !this.B.equals(var2.B) ? false : this.R.equals(var2.R);
            }
         }
      } else {
         return false;
      }
   }

   public int z() {
      return Objects.hash(new Object[]{super.hashCode(), this.v, this.G, this.K, this.s, this.D, this.Y, this.m, this.L, this.q, this.b, this.i, this.E, this.p, this.B, this.P, this.h, this.y, this.X, this.R, this.S});
   }
}

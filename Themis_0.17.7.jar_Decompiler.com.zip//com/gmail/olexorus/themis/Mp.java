package com.gmail.olexorus.themis;

import java.util.Objects;

public class Mp {
   private boolean b;
   private boolean v;
   private float t;

   public Mp(boolean var1, boolean var2, float var3) {
      this.b = var1;
      this.v = var2;
      this.t = var3;
   }

   public static Mp F(lm<?> var0) {
      boolean var1 = var0.P();
      boolean var2 = var0.P();
      float var3 = var0.L();
      return new Mp(var1, var2, var3);
   }

   public static void a(lm<?> var0, Mp var1) {
      var0.I(var1.b);
      var0.I(var1.v);
      var0.S(var1.t);
   }

   public boolean equals(Object var1) {
      if (var1 != null && this.getClass() == var1.getClass()) {
         Mp var2 = (Mp)var1;
         if (this.b != var2.b) {
            return false;
         } else if (this.v != var2.v) {
            return false;
         } else {
            return Float.compare(var2.t, this.t) == 0;
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.b, this.v, this.t});
   }
}

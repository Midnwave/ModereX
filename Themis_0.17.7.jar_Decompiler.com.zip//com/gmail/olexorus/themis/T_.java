package com.gmail.olexorus.themis;

import java.io.DataInput;

interface T_<T extends MC> {
   T N(DataInput var1);
}

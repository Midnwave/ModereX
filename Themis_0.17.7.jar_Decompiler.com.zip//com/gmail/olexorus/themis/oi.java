package com.gmail.olexorus.themis;

enum oi {
   public int T(zZ var1) {
      if (var1.i(zZ.V_1_21_6)) {
         return this.ordinal() - 2;
      } else {
         return var1.i(zZ.V_1_9) ? this.ordinal() : -1;
      }
   }
}

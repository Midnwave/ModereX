package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class lp implements T9 {
   private final al x;
   private final RT U;
   private static final long a = kt.a(4076803434417426410L, -6693371455117512800L, MethodHandles.lookup().lookupClass()).a(189165434902469L);

   public lp(al var1, RT var2) {
      this.x = var1;
      this.U = var2;
   }

   public static lp z(RT var0, lm<?> var1) {
      long var2 = a ^ 100698449852314L;
      al var4 = (al)var0.g("id", al::o, var1);
      RT var5 = var0.J("additions");
      return new lp(var4, var5);
   }

   public static void B(RT var0, lm<?> var1, lp var2) {
      long var3 = a ^ 53034653185159L;
      var0.X("id", var2.x, al::c, var1);
      if (var2.U != null) {
         var0.j("additions", var2.U);
      }

   }

   public ur<?> W() {
      return CY.V;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

class m4 implements bg<uu<T, ?>> {
   final tw a;
   final Jf f;
   private static final long b = kt.a(-1118388833150578996L, -860716260375441817L, MethodHandles.lookup().lookupClass()).a(14248766870488L);

   m4(tw var1, Jf var2) {
      this.a = var1;
      this.f = var2;
   }

   public uu<T, ?> s(RT var1, lm<?> var2) {
      long var3 = b ^ 86492007411940L;
      bA var5 = (bA)var1.P("modifier", this.a, bA.v(), var2);
      return (uu)uu.f(this.f, var5).U(var1, var2);
   }

   public void U(RT var1, lm<?> var2, uu<T, ?> var3) {
      this.k(var1, var2, var3);
   }

   private <A> void k(RT var1, lm<?> var2, uu<T, A> var3) {
      long var4 = b ^ 3050887672569L;
      if (uu.d(var3) != bA.v()) {
         var1.X("modifier", uu.d(var3), this.a, var2);
      }

      uu.f(this.f, uu.d(var3)).r(var1, var2, var3);
   }
}

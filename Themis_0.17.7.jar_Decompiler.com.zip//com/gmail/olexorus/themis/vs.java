package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class vs {
   private static final N8<Ov<?>> y;
   public static final Ov<Nj> N;
   public static final Ov<w8> Y;
   public static final Ov<RB> R;
   public static final Ov<zy> x;
   public static final Ov<bq> Q;
   public static final Ov<nv> X;
   public static final Ov<vK> o;
   public static final Ov<tI> z;
   public static final Ov<J> c;

   public static <T extends R9> Ov<T> w(String var0, boolean var1, Ot<T> var2, ms<T> var3) {
      return (Ov)y.h(var0, vs::lambda$define$0);
   }

   public static N8<Ov<?>> S() {
      return y;
   }

   private static ix lambda$define$0(boolean var0, Ot var1, ms var2, z2 var3) {
      return new ix(var3, var0, var1, var2);
   }

   static {
      long var0 = kt.a(5526561837998986953L, -3032811790604479806L, MethodHandles.lookup().lookupClass()).a(107616225667664L) ^ 123617082441103L;
      y = new N8("click_event_action");
      N = w("open_url", true, Nj::H, Nj::Z);
      Y = w("open_file", false, w8::n, w8::d);
      R = w("run_command", true, RB::m, RB::r);
      x = w("twitch_user_info", false, zy::G, zy::Y);
      Q = w("suggest_command", true, bq::R, bq::u);
      X = w("change_page", true, nv::t, nv::m);
      o = w("copy_to_clipboard", true, vK::V, vK::Y);
      z = w("show_dialog", true, tI::W, tI::c);
      c = w("custom", true, J::n, J::G);
      y.f();
   }
}

package com.gmail.olexorus.themis;

import java.io.IOException;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.Properties;
import java.util.function.Function;

final class iL {
   private static final Properties z;
   private static final long a = kt.a(-4522406142280103962L, -2172092380079668853L, MethodHandles.lookup().lookupClass()).a(249294030770064L);

   private static void N(Throwable var0) {
      var0.printStackTrace();
   }

   static String D(String var0) {
      long var1 = a ^ 20909477140340L;
      return String.join(".", "net", "kyori", "adventure", var0);
   }

   static <T> Nn<T> q(String var0, Function<String, T> var1, T var2, boolean var3) {
      return new VZ(var0, var1, var2, var3);
   }

   private static Path lambda$static$1() {
      long var0 = a ^ 88194592649171L;
      return Paths.get("config", "adventure.properties");
   }

   private static Path lambda$static$0(String var0) {
      return Paths.get(var0);
   }

   static Properties U() {
      return z;
   }

   static {
      long var0 = a ^ 108823551988157L;
      z = new Properties();
      Path var2 = (Path)Optional.ofNullable(System.getProperty(D("config"))).map(iL::lambda$static$0).orElseGet(iL::lambda$static$1);
      if (Files.isRegularFile(var2, new LinkOption[0])) {
         try {
            InputStream var3 = Files.newInputStream(var2);

            try {
               z.load(var3);
            } catch (Throwable var7) {
               if (var3 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (var3 != null) {
               var3.close();
            }
         } catch (IOException var8) {
            N(var8);
         }
      }

   }
}

package com.gmail.olexorus.themis;

public class ZB extends lm<ZB> {
   private String R;

   public void t() {
      this.R = this.A();
   }

   public void d() {
      this.I(this.R);
   }

   public void f(ZB var1) {
      this.R = var1.R;
   }
}

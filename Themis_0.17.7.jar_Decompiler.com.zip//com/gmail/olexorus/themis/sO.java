package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.BitSet;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public class sO extends lm<sO> {
   private static tl H = new tl();
   private static uf f = new uf();
   private static zg B = new zg();
   private static JA C = new JA();
   private static n_ W = new n_();
   private TX P;
   private r_ X;
   private boolean t;
   private static final long a = kt.a(-6279078411669508285L, -1076202192307295478L, MethodHandles.lookup().lookupClass()).a(253518039268510L);

   public void t() {
      long var1 = a ^ 112053767584036L;
      int var3 = this.f();
      int var4 = this.f();
      boolean var5 = this.I.m(zZ.V_1_17);
      boolean var6 = !var5 || this.P();
      if (this.I == zZ.V_1_16 || this.I == zZ.V_1_16_1) {
         this.t = this.P();
      }

      BitSet var7 = this.I.i(zZ.V_1_18) ? null : JJ.p(this);
      boolean var8 = this.I.i(zZ.V_1_14);
      RT var9 = null;
      Map var10 = null;
      if (var8) {
         if (this.I.i(zZ.V_1_21_5)) {
            var10 = this.U(TJ::R, lm::J);
         } else {
            var9 = this.u();
         }
      }

      BitSet var11 = null;
      if (this.I.R(zZ.V_1_7_10)) {
         var11 = JJ.p(this);
      }

      int var12 = 16;
      if (this.I.i(zZ.V_1_17)) {
         var12 = this.Z.C() >> 4;
      }

      boolean var13 = var6 && this.I.m(zZ.V_1_18);
      boolean var14 = this.I.m(zZ.V_1_13);
      int[] var15 = null;
      byte[] var16 = null;
      if (var13 && this.I.i(zZ.V_1_16_2)) {
         var15 = this.k();
      } else if (var13 && this.I.i(zZ.V_1_15)) {
         var15 = new int[1024];

         for(int var17 = 0; var17 < var15.length; ++var17) {
            var15[var17] = this.f();
         }
      }

      boolean var27 = (this.I.i(zZ.V_1_16) || this.I.m(zZ.V_1_14)) && !this.I.R(zZ.V_1_8_8);
      boolean var18 = this.I.i(zZ.V_1_16) || this.I.R(zZ.V_1_8_8) || this.Z != null && this.Z.j().D() && this.I.m(zZ.V_1_14);
      Object var19 = this.g;
      int var20;
      if (this.I.R(zZ.V_1_7_10)) {
         byte[] var21 = this.b(this.w(), var7, var6);
         this.g = nT.l(var21);
         var20 = var21.length;
      } else {
         var20 = this.Q();
      }

      int var22;
      g3[] var28;
      try {
         var22 = NY.p(this.g) + var20;
         var28 = this.C().X(this.Z.j(), var7, var11, var6, var27, var18, var12, var20, this);
         int var23;
         if (var13 && this.I.m(zZ.V_1_15)) {
            if (this.I.i(zZ.V_1_13)) {
               var15 = new int[256];

               for(var23 = 0; var23 < var15.length; ++var23) {
                  var15[var23] = this.f();
               }
            } else if (this.I.i(zZ.V_1_9)) {
               var16 = new byte[256];

               for(var23 = 0; var23 < var16.length; ++var23) {
                  var16[var23] = this.M();
               }
            } else if (var20 == 0) {
               var16 = new byte[0];
            } else {
               var16 = this.E(256);
            }
         }

         var23 = NY.p(this.g);
         if (var22 != var23) {
            if (var22 < var23) {
               throw new RuntimeException("Error while decoding chunk at " + var3 + " " + var4 + "; expected reader index " + var22 + ", got " + var23);
            }

            NY.n(this.g, var22);
         }
      } finally {
         if (this.g != var19) {
            NY.o(this.g);
            this.g = var19;
         }

      }

      var22 = this.I.m(zZ.V_1_9) ? 0 : this.Q();
      GU[] var29 = new GU[var22];
      int var24;
      if (this.I.i(zZ.V_1_18)) {
         for(var24 = 0; var24 < var29.length; ++var24) {
            var29[var24] = new GU(this.M(), this.x(), this.Q(), this.u());
         }
      } else {
         for(var24 = 0; var24 < var29.length; ++var24) {
            var29[var24] = new GU(this.u());
         }
      }

      if (this.I.i(zZ.V_1_18)) {
         this.X = r_.R(this);
      }

      if (var13) {
         if (var8) {
            if (var14) {
               this.P = new TX(var3, var4, true, var28, var29, var9, var16);
            } else {
               this.P = new TX(var3, var4, true, var28, var29, var9, var15);
            }
         } else if (var14) {
            this.P = new TX(var3, var4, true, var28, var29, var16);
         } else {
            this.P = new TX(var3, var4, true, var28, var29, var15);
         }
      } else if (var8) {
         if (var10 != null) {
            this.P = new TX(var3, var4, var6, var28, var29, var10);
         } else {
            this.P = new TX(var3, var4, var6, var28, var29, var9);
         }
      } else {
         this.P = new TX(var3, var4, var6, var28, var29);
      }

   }

   private byte[] b(byte[] var1, BitSet var2, boolean var3) {
      int var4 = 0;

      int var5;
      for(var5 = 0; var5 < 16; ++var5) {
         var4 += var2.get(var5) ? 1 : 0;
      }

      var5 = 12288 * var4;
      if (var3) {
         var5 += 256;
      }

      byte[] var6 = new byte[var5];
      Inflater var7 = new Inflater();
      var7.setInput(var1, 0, var1.length);

      try {
         var7.inflate(var6);
      } catch (DataFormatException var12) {
         var12.printStackTrace();
      } finally {
         var7.end();
      }

      return var6;
   }

   public void d() {
      this.L(this.P.d());
      this.L(this.P.Y());
      boolean var1 = this.I.i(zZ.V_1_18);
      boolean var2 = this.I.i(zZ.V_1_17);
      boolean var3 = this.I.i(zZ.V_1_9);
      boolean var4 = this.I.i(zZ.V_1_8);
      if (!var2) {
         this.I(this.P.k());
      }

      boolean var5 = false;
      if (this.I == zZ.V_1_16 || this.I == zZ.V_1_16_1) {
         this.I(this.t);
      }

      BitSet var6 = new BitSet();
      g3[] var7 = this.P.b();
      int var26;
      if (!this.I.i(zZ.V_1_9)) {
         z9 var22;
         if (var4) {
            var22 = uf.x((Vi[])var7, this.P.B());
            this.f(var22.i());
            this.N(var22.u());
         } else {
            var22 = tl.z((A1[])var7, this.P.B());
            Deflater var29 = new Deflater(-1);
            byte[] var35 = new byte[var22.u().length];

            try {
               var29.setInput(var22.u(), 0, var22.u().length);
               var29.finish();
               var26 = var29.deflate(var35);
            } finally {
               var29.end();
            }

            this.f(var22.i());
            this.f(var22.q());
            this.L(var26);
            NY.r(this.g, var35, 0, var26);
         }
      } else {
         Object var9 = this.g;
         Object var8 = NY.o(this.g);
         this.g = var8;

         int var10;
         for(var10 = 0; var10 < var7.length; ++var10) {
            g3 var11 = var7[var10];
            if (var1) {
               Nx.l(this, (Nx)var11);
            } else if (var3 && var11 != null) {
               var6.set(var10);
               a7.h(this, (a7)var11);
            }
         }

         this.g = var9;
         int var23;
         if (this.I.m(zZ.V_1_21_6) && this.I.i(zZ.V_1_21_5)) {
            var10 = n_.Y(var7);
            var23 = NY.P(var8) + var10;
            if (var23 > NY.K(var8)) {
               NY.x(var8, var23);
            }

            NY.E(var8, var23);
         }

         if (this.P.k() && this.I.m(zZ.V_1_15)) {
            if (this.I.i(zZ.V_1_13)) {
               int[] var20 = this.P.F();
               var10 = var20.length;

               for(var23 = 0; var23 < var10; ++var23) {
                  var26 = var20[var23];
                  NY.p(var8, var26);
               }
            } else {
               byte[] var19 = this.P.B();
               var10 = var19.length;

               for(var23 = 0; var23 < var10; ++var23) {
                  byte var12 = var19[var23];
                  NY.Z(var8, var12);
               }
            }

            var5 = true;
         }

         if (!var1) {
            JJ.O(this, var6);
         }

         boolean var21 = this.I.i(zZ.V_1_14);
         if (var21) {
            if (this.I.i(zZ.V_1_21_5)) {
               this.o(this.P.y(), TJ::A, lm::Q);
            } else {
               this.G(this.P.N());
            }
         }

         int[] var30;
         if (this.P.R() && this.I.i(zZ.V_1_15) && !var1) {
            boolean var24 = this.I.m(zZ.V_1_13);
            var30 = this.P.F();
            byte[] var28 = this.P.B();
            int var14;
            int var15;
            if (var24) {
               byte[] var31 = var28;
               var14 = var28.length;

               for(var15 = 0; var15 < var14; ++var15) {
                  byte var37 = var31[var15];
                  this.u(var37);
               }
            } else if (this.I.i(zZ.V_1_16_2)) {
               this.B(var30);
            } else {
               int[] var13 = var30;
               var14 = var30.length;

               for(var15 = 0; var15 < var14; ++var15) {
                  int var16 = var13[var15];
                  this.L(var16);
               }
            }

            var5 = true;
         }

         this.E(NY.r(var8));
         NY.I(this.g, var8);
         NY.o(var8);
         if (this.P.R() && !var5) {
            byte[] var25 = new byte[256];
            var30 = this.P.F();

            for(var26 = 0; var26 < var25.length; ++var26) {
               var25[var26] = (byte)var30[var26];
            }

            this.N(var25);
         }

         GU[] var27;
         if (this.I.i(zZ.V_1_18)) {
            this.E(this.P.W().length);
            var27 = this.P.W();
            var23 = var27.length;

            for(var26 = 0; var26 < var23; ++var26) {
               GU var32 = var27[var26];
               this.u(var32.C());
               this.f(var32.E());
               this.E(var32.t());
               this.G(var32.Q());
            }
         } else if (this.I.i(zZ.V_1_9)) {
            var27 = this.P.W();
            this.E(var27.length);
            GU[] var33 = var27;
            var26 = var27.length;

            for(int var34 = 0; var34 < var26; ++var34) {
               GU var36 = var33[var34];
               this.G(var36.Q());
            }
         }

         if (this.I.i(zZ.V_1_18)) {
            r_.Z(this, this.X);
         }

      }
   }

   public void t(sO var1) {
      this.P = var1.P;
      this.X = var1.X != null ? var1.X.a() : null;
      this.t = var1.t;
   }

   public TX M() {
      return this.P;
   }

   public r_ b() {
      return this.X;
   }

   private Ju C() {
      if (this.I.i(zZ.V_1_18)) {
         return W;
      } else if (this.I.i(zZ.V_1_16)) {
         return C;
      } else if (this.I.i(zZ.V_1_9)) {
         return B;
      } else {
         return (Ju)(this.I.i(zZ.V_1_8) ? f : H);
      }
   }
}

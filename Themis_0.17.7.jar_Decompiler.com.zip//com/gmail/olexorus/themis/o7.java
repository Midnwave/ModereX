package com.gmail.olexorus.themis;

public final class o7 {
   private Long L;

   public o7(Long var1) {
      this.L = var1;
   }

   public static o7 y(lm<?> var0) {
      return new o7((Long)var0.u(lm::k));
   }

   public static void t(lm<?> var0, o7 var1) {
      var0.l(var1.L, lm::A);
   }
}

package com.gmail.olexorus.themis;

import java.util.HashSet;
import java.util.Set;

public class Qs extends lm<Qs> {
   private Set<al> B;

   public void t() {
      this.B = (Set)this.U(HashSet::new, lm::R);
   }

   public void d() {
      this.d(this.B, lm::T);
   }

   public void X(Qs var1) {
      this.B = var1.B;
   }
}

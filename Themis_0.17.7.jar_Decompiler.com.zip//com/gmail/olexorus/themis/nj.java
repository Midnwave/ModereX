package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

final class nj extends n9 implements EP<y> {
   final vz k;
   final V p;
   private static final long a = kt.a(5997455619269532462L, 1557529194152299526L, MethodHandles.lookup().lookupClass()).a(195360093598918L);

   nj(vz var1, V var2) {
      super(0);
      this.k = var1;
      this.p = var2;
   }

   public final void g(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = a ^ var2;
      vQ.e();
      vz.O(new Object[]{this.k}).add(new z0(Math.hypot(vz.P(new Object[]{this.k}).getVelocity().getX() + this.p.f, vz.P(new Object[]{this.k}).getVelocity().getZ() + this.p.r) + 0.05D, System.currentTimeMillis()));

      try {
         if (vh.i() == null) {
            vQ.S(new vh[2]);
         }

      } catch (RuntimeException var5) {
         throw a(var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}

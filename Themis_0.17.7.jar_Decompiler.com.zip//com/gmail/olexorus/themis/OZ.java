package com.gmail.olexorus.themis;

import java.io.DataInput;
import java.io.IOException;
import java.lang.invoke.MethodHandles;

final class OZ implements DataInput, CH {
   private final DataInput d;
   private final long Y;
   private long b;
   private int m;
   private static final long a = kt.a(-1912676890742896540L, -4622762733597717307L, MethodHandles.lookup().lookupClass()).a(178683474816933L);

   public static CH H(DataInput var0) {
      return (CH)(var0 instanceof OZ ? ((OZ)var0).h() : MF.t);
   }

   public static CH K(DataInput var0, long var1) {
      return (CH)(var0 instanceof OZ ? ((OZ)var0).L(var1) : MF.t);
   }

   public OZ L(long var1) {
      long var3 = a ^ 10981828085174L;
      if (this.m++ > 512) {
         throw new IOException("NBT read exceeded maximum depth of 512");
      } else {
         this.D(var1);
         return this;
      }
   }

   public OZ h() {
      return this.L(0L);
   }

   public void o() {
      --this.m;
      this.D(0L);
   }

   private void D(long var1) {
      long var3 = a ^ 12441893030736L;
      if (this.Y > 0L && this.b + var1 > this.Y) {
         throw new IOException("The read NBT was longer than the maximum allowed size of " + this.Y + " bytes!");
      }
   }

   public void readFully(byte[] var1) {
      this.b += (long)var1.length;
      this.d.readFully(var1);
   }

   public void readFully(byte[] var1, int var2, int var3) {
      this.b += (long)var3;
      this.d.readFully(var1, var2, var3);
   }

   public int skipBytes(int var1) {
      return this.d.skipBytes(var1);
   }

   public boolean readBoolean() {
      ++this.b;
      return this.d.readBoolean();
   }

   public byte readByte() {
      ++this.b;
      return this.d.readByte();
   }

   public int readUnsignedByte() {
      ++this.b;
      return this.d.readUnsignedByte();
   }

   public short readShort() {
      this.b += 2L;
      return this.d.readShort();
   }

   public int readUnsignedShort() {
      this.b += 2L;
      return this.d.readUnsignedShort();
   }

   public char readChar() {
      this.b += 2L;
      return this.d.readChar();
   }

   public int readInt() {
      this.b += 4L;
      return this.d.readInt();
   }

   public long readLong() {
      this.b += 8L;
      return this.d.readLong();
   }

   public float readFloat() {
      this.b += 4L;
      return this.d.readFloat();
   }

   public double readDouble() {
      this.b += 8L;
      return this.d.readDouble();
   }

   public String readLine() {
      String var1 = this.d.readLine();
      if (var1 != null) {
         this.b += (long)(var1.length() + 1);
      }

      return var1;
   }

   public String readUTF() {
      String var1 = this.d.readUTF();
      this.b += (long)var1.length() * 2L + 2L;
      return var1;
   }

   public void close() {
      this.o();
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class WA {
   private static final N8<gL> R;
   public static final gL Y;
   public static final gL F;
   public static final gL i;
   public static final gL E;
   public static final gL S;
   public static final gL h;
   public static final gL f;
   public static final gL y;
   public static final gL V;
   public static final gL X;
   public static final gL l;
   public static final gL L;
   public static final gL z;
   public static final gL P;
   public static final gL A;
   public static final gL W;
   public static final gL d;
   public static final gL j;
   public static final gL g;
   public static final gL D;
   public static final gL w;
   public static final gL o;
   public static final gL u;
   public static final gL a;
   public static final gL k;
   public static final gL N;
   public static final gL m;
   public static final gL M;
   public static final gL O;
   public static final gL r;
   public static final gL Z;
   public static final gL v;
   public static final gL U;
   public static final gL n;
   public static final gL e;

   public static gL d(String var0, boolean var1, boolean var2) {
      return t(var0, al.z(var0), var1, var2);
   }

   public static gL t(String var0, al var1, boolean var2, boolean var3) {
      return k(var0, var1, var2, -1, false, var3);
   }

   public static gL Z(String var0, boolean var1, int var2, boolean var3, boolean var4) {
      return k(var0, al.z(var0), var1, var2, var3, var4);
   }

   public static gL k(String var0, al var1, boolean var2, int var3, boolean var4, boolean var5) {
      return (gL)R.h(var0, WA::lambda$define$0);
   }

   public static gL u(String var0) {
      return (gL)R.R(var0);
   }

   public static gL K(vL var0, int var1) {
      return (gL)R.e(var0, var1);
   }

   private static iT lambda$define$0(al var0, boolean var1, int var2, boolean var3, boolean var4, z2 var5) {
      return new iT(var5, var0, var1, var2, var3, var4);
   }

   static {
      long var0 = kt.a(-4705596188143988500L, -5622371869495728085L, MethodHandles.lookup().lookupClass()).a(46893925384662L) ^ 62688128499635L;
      R = new N8("map_decoration_type");
      Y = d("player", false, true);
      F = d("frame", true, true);
      i = d("red_marker", false, true);
      E = d("blue_marker", false, true);
      S = d("target_x", true, false);
      h = d("target_point", true, false);
      f = d("player_off_map", false, true);
      y = d("player_off_limits", false, true);
      V = Z("mansion", true, 5393476, true, false);
      X = Z("monument", true, 3830373, true, false);
      l = t("banner_white", al.z("white_banner"), true, true);
      L = t("banner_orange", al.z("orange_banner"), true, true);
      z = t("banner_magenta", al.z("magenta_banner"), true, true);
      P = t("banner_light_blue", al.z("light_blue_banner"), true, true);
      A = t("banner_yellow", al.z("yellow_banner"), true, true);
      W = t("banner_lime", al.z("lime_banner"), true, true);
      d = t("banner_pink", al.z("pink_banner"), true, true);
      j = t("banner_gray", al.z("gray_banner"), true, true);
      g = t("banner_light_gray", al.z("light_gray_banner"), true, true);
      D = t("banner_cyan", al.z("cyan_banner"), true, true);
      w = t("banner_purple", al.z("purple_banner"), true, true);
      o = t("banner_blue", al.z("blue_banner"), true, true);
      u = t("banner_brown", al.z("brown_banner"), true, true);
      a = t("banner_green", al.z("green_banner"), true, true);
      k = t("banner_red", al.z("red_banner"), true, true);
      N = t("banner_black", al.z("black_banner"), true, true);
      m = d("red_x", true, false);
      M = k("village_desert", al.z("desert_village"), true, 10066329, true, false);
      O = k("village_plains", al.z("plains_village"), true, 10066329, true, false);
      r = k("village_savanna", al.z("savanna_village"), true, 10066329, true, false);
      Z = k("village_snowy", al.z("snowy_village"), true, 10066329, true, false);
      v = k("village_taiga", al.z("taiga_village"), true, 10066329, true, false);
      U = Z("jungle_temple", true, 10066329, true, false);
      n = Z("swamp_hut", true, 10066329, true, false);
      e = Z("trial_chambers", true, 12741452, true, false);
      R.f();
   }
}

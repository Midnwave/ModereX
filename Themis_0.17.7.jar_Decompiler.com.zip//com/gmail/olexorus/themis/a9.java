package com.gmail.olexorus.themis;

public class a9 extends aw {
   public a9(Object var1, Gs var2, Object var3, Object var4, boolean var5) {
      super(var1, var2, var3, var4, var5);
   }

   protected a9(int var1, wC var2, zZ var3, Object var4, Gs var5, Object var6, Object var7) {
      super(var1, var2, var3, var4, var5, var6, var7);
   }

   public a9 A() {
      try {
         Object var1 = NY.j(this.n());
         return new a9(this.K(), this.i(), this.M(), this.c(), this.Z(), this.O(), var1);
      } catch (Co var2) {
         var2.printStackTrace();
         return null;
      }
   }

   public lF i() {
      return (lF)super.y();
   }
}

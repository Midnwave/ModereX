package com.gmail.olexorus.themis;

public class yR extends lm<yR> {
   private V z;
   private float h;
   private float T;
   private boolean n;

   public void t() {
      this.z = V.c(this);
      this.h = this.L();
      this.T = this.L();
      if (this.I.i(zZ.V_1_21_4)) {
         this.n = this.P();
      }

   }

   public void d() {
      V.q(this, this.z);
      this.S(this.h);
      this.S(this.T);
      if (this.I.i(zZ.V_1_21_4)) {
         this.I(this.n);
      }

   }

   public void L(yR var1) {
      this.z = var1.z;
      this.h = var1.h;
      this.T = var1.T;
      this.n = var1.n;
   }
}

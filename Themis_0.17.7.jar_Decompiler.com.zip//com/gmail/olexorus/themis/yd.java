package com.gmail.olexorus.themis;

public class yd extends lm<yd> {
   private VC i;
   private boolean V;

   public void t() {
      this.i = this.M();
      this.V = this.P();
   }

   public void d() {
      this.o(this.i);
      this.I(this.V);
   }

   public void C(yd var1) {
      this.i = var1.i;
      this.V = var1.V;
   }
}

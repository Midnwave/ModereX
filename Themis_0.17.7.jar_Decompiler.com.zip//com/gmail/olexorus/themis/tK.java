package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class tK {
   private static final N8<aS<?>> H;
   public static final aS<Jl> M;
   public static final aS<WM> r;
   public static final aS<nA> E;
   public static final aS<nA> y;
   public static final aS<nA> o;
   public static final aS<nA> P;
   public static final aS<nA> h;
   public static final aS<nA> i;
   public static final aS<nA> j;
   public static final aS<nA> s;
   public static final aS<nA> W;
   public static final aS<nA> C;
   public static final aS<nA> c;
   public static final aS<nA> F;
   public static final aS<nA> B;
   public static final aS<gE> N;
   public static final aS<gE> Z;
   public static final aS<gE> b;
   public static final aS<gE> a;
   public static final aS<o5> p;
   public static final aS<zs> f;
   public static final aS<zs> k;
   public static final aS<Ok> w;
   public static final aS<nA> O;

   public static <T extends RI> aS<T> I(String var0, MO<T> var1, Gw<T> var2) {
      return l(var0, var1, var2, (MV)null);
   }

   public static <T extends RI> aS<T> l(String var0, MO<T> var1, Gw<T> var2, MV var3) {
      return (aS)H.h(var0, tK::lambda$define$0);
   }

   public static aS<?> Z(String var0) {
      return (aS)H.R(var0);
   }

   public static aS<?> N(vL var0, int var1) {
      return (aS)H.e(var0, var1);
   }

   private static void lambda$static$2(lm var0, zs var1) {
      zs.c(var0, var1, true);
   }

   private static zs lambda$static$1(lm var0) {
      return zs.T(var0, true);
   }

   private static cO lambda$define$0(MO var0, Gw var1, MV var2, z2 var3) {
      return new cO(var3, var0, var1, var2);
   }

   static {
      long var0 = kt.a(-1707947684013463960L, 2218221759295546434L, MethodHandles.lookup().lookupClass()).a(12809871123442L) ^ 104697584106498L;
      H = new N8("legacy_recipe_serializer");
      M = l("crafting_shaped", Jl::c, Jl::u, MV.CRAFTING_SHAPED);
      r = l("crafting_shapeless", WM::w, WM::H, MV.CRAFTING_SHAPELESS);
      E = l("crafting_special_armordye", nA::P, nA::O, MV.CRAFTING_SPECIAL_ARMORDYE);
      y = l("crafting_special_bookcloning", nA::P, nA::O, MV.CRAFTING_SPECIAL_BOOKCLONING);
      o = l("crafting_special_mapcloning", nA::P, nA::O, MV.CRAFTING_SPECIAL_MAPCLONING);
      P = l("crafting_special_mapextending", nA::P, nA::O, MV.CRAFTING_SPECIAL_MAPEXTENDING);
      h = l("crafting_special_firework_rocket", nA::P, nA::O, MV.CRAFTING_SPECIAL_FIREWORK_ROCKET);
      i = l("crafting_special_firework_star", nA::P, nA::O, MV.CRAFTING_SPECIAL_FIREWORK_STAR);
      j = l("crafting_special_firework_star_fade", nA::P, nA::O, MV.CRAFTING_SPECIAL_FIREWORK_STAR_FADE);
      s = l("crafting_special_tippedarrow", nA::P, nA::O, MV.CRAFTING_SPECIAL_TIPPEDARROW);
      W = l("crafting_special_bannerduplicate", nA::P, nA::O, MV.CRAFTING_SPECIAL_BANNERDUPLICATE);
      C = l("crafting_special_shielddecoration", nA::P, nA::O, MV.CRAFTING_SPECIAL_SHIELDDECORATION);
      c = l("crafting_special_shulkerboxcoloring", nA::P, nA::O, MV.CRAFTING_SPECIAL_SHULKERBOXCOLORING);
      F = l("crafting_special_suspiciousstew", nA::P, nA::O, MV.CRAFTING_SPECIAL_SUSPICIOUSSTEW);
      B = l("crafting_special_repairitem", nA::P, nA::O, MV.CRAFTING_SPECIAL_REPAIRITEM);
      N = l("smelting", gE::A, gE::Y, MV.SMELTING);
      Z = l("blasting", gE::A, gE::Y, MV.BLASTING);
      b = l("smoking", gE::A, gE::Y, MV.SMOKING);
      a = l("campfire_cooking", gE::A, gE::Y, MV.CAMPFIRE_COOKING);
      p = l("stonecutting", o5::u, o5::Q, MV.STONECUTTING);
      f = l("smithing", tK::lambda$static$1, tK::lambda$static$2, MV.SMITHING);
      k = l("smithing_transform", zs::F, zs::Y, MV.SMITHING);
      w = I("smithing_trim", Ok::B, Ok::Y);
      O = I("crafting_decorated_pot", nA::P, nA::O);
      H.f();
   }
}

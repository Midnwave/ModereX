package com.gmail.olexorus.themis;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class g1 {
   private static final long a = kt.a(-2207459447856383477L, 5621027850938674112L, MethodHandles.lookup().lookupClass()).a(22686392563289L);

   public static JsonElement y(Rc var0, boolean var1) {
      long var2 = a ^ 53407982641105L;
      if (var0 instanceof mh) {
         if (var0 instanceof mA && var1) {
            byte var10 = ((mA)var0).E();
            if (var10 == 0) {
               return new JsonPrimitive(false);
            }

            if (var10 == 1) {
               return new JsonPrimitive(true);
            }
         }

         return new JsonPrimitive(((mh)var0).r());
      } else if (var0 instanceof mZ) {
         return new JsonPrimitive(((mZ)var0).b());
      } else if (var0 instanceof m_) {
         m_ var9 = (m_)var0;
         JsonArray var11 = new JsonArray();
         var9.N().forEach(g1::lambda$nbtToJson$0);
         return var11;
      } else if (var0 instanceof RU) {
         throw new IllegalStateException("Encountered the NBTEnd tag during the NBT to JSON conversion: " + var0.toString());
      } else if (!(var0 instanceof RT)) {
         throw new IllegalStateException("Failed to convert NBT to JSON.");
      } else {
         JsonObject var4 = new JsonObject();
         Map var5 = ((RT)var0).q();
         Iterator var6 = var5.entrySet().iterator();

         while(var6.hasNext()) {
            Entry var7 = (Entry)var6.next();
            JsonElement var8 = y((Rc)var7.getValue(), var1);
            var4.add((String)var7.getKey(), var8);
         }

         return var4;
      }
   }

   public static Rc O(Object var0, zZ var1) {
      Gq var2 = Gq.S(var0);
      return X(var0, var1, var2);
   }

   public static Rc X(Object var0, zZ var1, Gq var2) {
      if (var1.i(zZ.V_1_8)) {
         try {
            boolean var12 = var1.m(zZ.V_1_20_2);
            return gq.O.j(var2, new Vx(var0), var12);
         } catch (IOException var9) {
            throw new IllegalStateException(var9);
         }
      } else {
         try {
            short var3 = NY.O(var0);
            if (var3 < 0) {
               return null;
            } else {
               Object var4 = NY.g(var0, var3);
               DataInputStream var5 = new DataInputStream(new GZIPInputStream(new Vx(var4)));

               Rc var6;
               try {
                  var6 = gq.O.X(var2, var5);
               } catch (Throwable var10) {
                  try {
                     var5.close();
                  } catch (Throwable var8) {
                     var10.addSuppressed(var8);
                  }

                  throw var10;
               }

               var5.close();
               return var6;
            }
         } catch (IOException var11) {
            throw new IllegalStateException(var11);
         }
      }
   }

   public static void A(Object var0, zZ var1, Rc var2) {
      if (var1.i(zZ.V_1_8)) {
         try {
            bc var3 = new bc(var0);

            try {
               if (var2 != null) {
                  boolean var4 = var1.m(zZ.V_1_20_2);
                  gq.O.e(var3, var2, var4);
               } else {
                  gq.O.D(var3, RU.v);
               }
            } catch (Throwable var12) {
               try {
                  var3.close();
               } catch (Throwable var8) {
                  var12.addSuppressed(var8);
               }

               throw var12;
            }

            var3.close();
         } catch (IOException var13) {
            throw new IllegalStateException(var13);
         }
      } else if (var2 == null) {
         NY.D(var0, -1);
      } else {
         int var14 = NY.P(var0);
         NY.D(var0, 0);
         int var15 = NY.P(var0);

         try {
            DataOutputStream var5 = new DataOutputStream(new GZIPOutputStream(new bc(var0)));

            try {
               gq.O.D(var5, var2);
            } catch (Throwable var10) {
               try {
                  var5.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }

               throw var10;
            }

            var5.close();
         } catch (Exception var11) {
            throw new IllegalStateException(var11);
         }

         int var16 = NY.P(var0);
         NY.E(var0, var14);
         NY.D(var0, var16 - var15);
         NY.E(var0, var16);
      }

   }

   private static void lambda$nbtToJson$0(JsonArray var0, boolean var1, Rc var2) {
      var0.add(y(var2, var1));
   }
}

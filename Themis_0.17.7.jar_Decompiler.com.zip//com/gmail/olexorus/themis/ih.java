package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.function.Consumer;

final class ih implements mp {
   private final Tr X;
   private final Map<Integer, bp> M = new TreeMap();
   private static final long a = kt.a(-1639070652907411518L, -1918967759829792124L, MethodHandles.lookup().lookupClass()).a(56927719158012L);

   ih(Tr var1) {
      this.X = var1;
   }

   public ML T() {
      if (this.M.isEmpty()) {
         return new iW(this.X, Collections.emptySortedMap(), 0, this.X.W());
      } else {
         TreeMap var1 = new TreeMap();
         Iterator var2 = this.M.entrySet().iterator();

         while(var2.hasNext()) {
            Entry var3 = (Entry)var2.next();
            var1.put((Integer)var3.getKey(), ((bp)var3.getValue()).A());
         }

         return new iW(this.X, var1, (Integer)var1.lastKey(), iW.i(this.X, var1, (Integer)var1.lastKey()));
      }
   }

   public mp M(int var1, Consumer<gB> var2) {
      long var3 = a ^ 139754442238663L;
      ((Consumer)Objects.requireNonNull(var2, "versionBuilder")).accept((gB)this.M.computeIfAbsent(var1, this::lambda$version$0));
      return this;
   }

   private bp lambda$version$0(Integer var1) {
      return new bp(this.X);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.stream.Stream;

public interface wT extends B9 {
   v1 Q;
   long b = kt.a(95362564795115525L, 4769243022917305320L, MethodHandles.lookup().lookupClass()).a(263778917489455L);

   v1 L();

   v1 E();

   default Stream<? extends rE> T() {
      long var1 = b ^ 32371260423270L;
      return Stream.of(rE.E("atlas", this.L()), rE.E("sprite", this.E()));
   }

   static {
      long var0 = b ^ 23296021902244L;
      Q = v1.t("minecraft:blocks");
   }
}

package com.gmail.olexorus.themis;

import java.util.UUID;

public class q {
   private final UUID X;
   private final BQ H;

   public q(UUID var1, BQ var2) {
      this.X = var1;
      this.H = var2;
   }

   public UUID V() {
      return this.X;
   }

   public BQ W() {
      return this.H;
   }
}

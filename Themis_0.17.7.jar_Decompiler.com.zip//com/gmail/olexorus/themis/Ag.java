package com.gmail.olexorus.themis;

import java.util.Objects;

public class Ag {
   private EZ s;

   public Ag(EZ var1) {
      this.s = var1;
   }

   public static Ag P(lm<?> var0) {
      EZ var1 = EZ.b(var0);
      return new Ag(var1);
   }

   public static void m(lm<?> var0, Ag var1) {
      EZ.M(var0, var1.s);
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof Ag)) {
         return false;
      } else {
         Ag var2 = (Ag)var1;
         return this.s.equals(var2.s);
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.s);
   }
}

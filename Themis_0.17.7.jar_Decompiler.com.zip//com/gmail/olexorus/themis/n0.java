package com.gmail.olexorus.themis;

public abstract class n0 {
   public abstract long[] n();

   public abstract int D();

   public abstract int h(int var1);
}

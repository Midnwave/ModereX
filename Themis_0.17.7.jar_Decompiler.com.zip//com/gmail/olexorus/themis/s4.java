package com.gmail.olexorus.themis;

public class s4 extends lm<s4> {
   private G8<?> v;

   public void t() {
      this.v = G8.F(this);
   }

   public void d() {
      G8.O(this, this.v);
   }

   public void g(s4 var1) {
      this.v = var1.v;
   }
}

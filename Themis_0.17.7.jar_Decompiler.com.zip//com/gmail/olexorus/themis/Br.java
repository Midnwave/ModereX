package com.gmail.olexorus.themis;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;

public class Br extends FilterInputStream {
   private static final long a = kt.a(6238532993577259754L, 8949121807671689741L, MethodHandles.lookup().lookupClass()).a(35719565083852L);

   public Br(InputStream var1) {
      super(var1);
   }

   public byte Q() {
      return (byte)this.X();
   }

   public int X() {
      int var1 = 0;

      try {
         var1 = this.read();
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      if (var1 < 0) {
         throw new IllegalStateException();
      } else {
         return var1;
      }
   }

   public short m() {
      return (short)this.p();
   }

   public int p() {
      int var1 = this.X();
      int var2 = this.X();
      return (var1 << 8) + var2;
   }

   public int G() {
      long var1 = a ^ 53790722654934L;
      int var3 = 0;
      int var4 = 0;

      do {
         byte var5;
         if (((var5 = this.Q()) & 128) != 128) {
            return var3 | (var5 & 127) << var4 * 7;
         }

         var3 |= (var5 & 127) << var4++ * 7;
      } while(var4 <= 5);

      throw new IllegalStateException("VarInt too long (length must be <= 5)");
   }

   public long V() {
      byte[] var1 = this.z(8);
      return ((long)var1[0] << 56) + ((long)(var1[1] & 255) << 48) + ((long)(var1[2] & 255) << 40) + ((long)(var1[3] & 255) << 32) + ((long)(var1[4] & 255) << 24) + (long)((var1[5] & 255) << 16) + (long)((var1[6] & 255) << 8) + (long)((var1[7] & 255) << 0);
   }

   public byte[] z(int var1) {
      long var2 = a ^ 55044779272699L;
      if (var1 < 0) {
         throw new IllegalArgumentException("Array cannot have length less than 0.");
      } else {
         byte[] var4 = new byte[var1];

         int var6;
         for(int var5 = 0; var5 < var1; var5 += var6) {
            var6 = 0;

            try {
               var6 = this.read(var4, var5, var1 - var5);
            } catch (IOException var8) {
               var8.printStackTrace();
            }

            if (var6 < 0) {
               throw new IllegalStateException();
            }
         }

         return var4;
      }
   }

   public long[] g(int var1) {
      long var2 = a ^ 92119153824446L;
      if (var1 < 0) {
         throw new IllegalArgumentException("Array cannot have length less than 0.");
      } else {
         long[] var4 = new long[var1];
         int var5 = this.h(var4);
         if (var5 < var1) {
            throw new IllegalStateException();
         } else {
            return var4;
         }
      }
   }

   public int h(long[] var1) {
      return this.c(var1, 0, var1.length);
   }

   public int c(long[] var1, int var2, int var3) {
      for(int var4 = var2; var4 < var2 + var3; ++var4) {
         try {
            var1[var4] = this.V();
         } catch (Exception var6) {
            return var4 - var2;
         }
      }

      return var3;
   }
}

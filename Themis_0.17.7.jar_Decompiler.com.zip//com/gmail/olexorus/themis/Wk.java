package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum Wk {
   ACTIVE,
   COOLDOWN,
   INACTIVE;

   // $FF: synthetic method
   private static Wk[] j() {
      return new Wk[]{ACTIVE, COOLDOWN, INACTIVE};
   }

   static {
      long var0 = kt.a(6225904413492095113L, 1588833939282822593L, MethodHandles.lookup().lookupClass()).a(128208000495470L) ^ 117670351363736L;
      ACTIVE = new Wk("ACTIVE", 0);
      COOLDOWN = new Wk("COOLDOWN", 1);
      INACTIVE = new Wk("INACTIVE", 2);
   }
}

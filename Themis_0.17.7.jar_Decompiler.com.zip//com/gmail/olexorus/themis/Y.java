package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import org.bukkit.NamespacedKey;

class Y {
   private static final long a = kt.a(-7097320831318292785L, -4213085689452611131L, MethodHandles.lookup().lookupClass()).a(268488187809678L);

   static void f(r7 var0) {
      var0.J(NamespacedKey.class, Y::lambda$register$0);
   }

   private static NamespacedKey lambda$register$0(cg var0) {
      long var1 = a ^ 41284555414585L;
      String var3 = var0.D();
      String[] var4 = nQ.Z.split(var3, 2);
      if (var4.length == 1) {
         String var5 = var0.d("namespace", (String)null);
         return var5 == null ? NamespacedKey.minecraft(var4[0]) : new NamespacedKey(var5, var4[0]);
      } else {
         return new NamespacedKey(var4[0], var4[1]);
      }
   }
}

package com.gmail.olexorus.themis;

public interface rs<T extends An> extends GL {
   T f(RT var1, lm<?> var2);

   void S(RT var1, lm<?> var2, T var3);
}

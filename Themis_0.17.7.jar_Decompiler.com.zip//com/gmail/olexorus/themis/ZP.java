package com.gmail.olexorus.themis;

public class ZP extends lm<ZP> {
   private al p;

   public void t() {
      this.p = this.R();
   }

   public void d() {
      this.T(this.p);
   }

   public void l(ZP var1) {
      this.p = var1.p;
   }
}

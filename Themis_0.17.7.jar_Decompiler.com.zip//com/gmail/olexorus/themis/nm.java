package com.gmail.olexorus.themis;

import com.destroystokyo.paper.brigadier.BukkitBrigadierCommandSource;
import com.destroystokyo.paper.event.brigadier.CommandRegisteredEvent;
import java.lang.invoke.MethodHandles;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

public class nm implements Listener {
   private final w1 v;
   private final VK<BukkitBrigadierCommandSource> R;
   private static final long a = kt.a(5847613130935440356L, -3264030152572280311L, MethodHandles.lookup().lookupClass()).a(102753011927718L);

   public nm(Plugin var1, w1 var2) {
      long var3 = a ^ 44093222503873L;
      super();
      var2.v("brigadier");
      var2.U(vq.INFO, "Enabled Brigadier Support!");
      this.v = var2;
      this.R = new VK(var2);
      Bukkit.getPluginManager().registerEvents(this, var1);
   }

   @EventHandler
   public void p(CommandRegisteredEvent<BukkitBrigadierCommandSource> var1) {
      ti var2 = this.v.q(var1.getCommandLabel());
      if (var2 != null) {
         var1.setLiteral(this.R.N(var2, var1.getLiteral(), var1.getBrigadierCommand(), var1.getBrigadierCommand(), this::G, this::B));
      }

   }

   private boolean B(Bd var1, BukkitBrigadierCommandSource var2) {
      return var1.l(this.v.w(var2.getBukkitSender()));
   }

   private boolean G(ti var1, BukkitBrigadierCommandSource var2) {
      return var1.X(this.v.w(var2.getBukkitSender()));
   }
}

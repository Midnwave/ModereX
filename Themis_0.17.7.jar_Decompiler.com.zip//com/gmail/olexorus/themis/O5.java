package com.gmail.olexorus.themis;

public final class O5 {
   private static boolean G = false;
   private static final zw T;
   private static final zw n;
   private static final zw w;
   private static final zw l;

   public static void u() {
      lF.w();
      rX.b();
      bK.v();
      gt.F();
      G = true;
   }

   public static boolean T() {
      return G;
   }

   public static wC w(RW var0, uy var1, vL var2, int var3) {
      // $FF: Couldn't be decompiled
   }

   static zw v() {
      return l;
   }

   static boolean q() {
      return G;
   }

   static zw c() {
      return w;
   }

   static zw D() {
      return n;
   }

   static zw Y() {
      return T;
   }

   static {
      T = new zw(new vL[]{vL.V_1_7_2, vL.V_1_8, vL.V_1_9, vL.V_1_10, vL.V_1_12, vL.V_1_12_1, vL.V_1_13, vL.V_1_14, vL.V_1_14_4, vL.V_1_15, vL.V_1_15_2, vL.V_1_16, vL.V_1_16_2, vL.V_1_17, vL.V_1_18, vL.V_1_19, vL.V_1_19_1, vL.V_1_19_3, vL.V_1_19_4, vL.V_1_20_2, vL.V_1_20_3, vL.V_1_20_5, vL.V_1_21, vL.V_1_21_2, vL.V_1_21_5, vL.V_1_21_6, vL.V_1_21_9});
      n = new zw(new vL[]{vL.V_1_7_2, vL.V_1_8, vL.V_1_9, vL.V_1_12, vL.V_1_12_1, vL.V_1_13, vL.V_1_14, vL.V_1_15_2, vL.V_1_16, vL.V_1_16_2, vL.V_1_17, vL.V_1_19, vL.V_1_19_1, vL.V_1_19_3, vL.V_1_19_4, vL.V_1_20_2, vL.V_1_20_3, vL.V_1_20_5, vL.V_1_21_2, vL.V_1_21_4, vL.V_1_21_5, vL.V_1_21_6, vL.V_1_21_9});
      w = new zw(new vL[]{vL.V_1_20_2, vL.V_1_20_3, vL.V_1_20_5, vL.V_1_21, vL.V_1_21_6, vL.V_1_21_9});
      l = new zw(new vL[]{vL.V_1_20_2, vL.V_1_20_5, vL.V_1_21_6, vL.V_1_21_9});
   }
}

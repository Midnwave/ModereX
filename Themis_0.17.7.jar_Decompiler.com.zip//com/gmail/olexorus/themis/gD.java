package com.gmail.olexorus.themis;

import java.time.Instant;
import java.util.UUID;

public class gD implements RH {
   public wA c(lm<?> var1) {
      byte[] var2 = (byte[])var1.u(lm::w);
      UUID var3 = var1.V();
      byte[] var4 = var1.w();
      String var5 = var1.m(256);
      Object var6 = (X)var1.u(lm::a);
      if (var6 == null && var5.isEmpty()) {
         var6 = X.f();
      } else if (var6 == null) {
         var6 = X.N(var5);
      }

      Instant var7 = var1.V();
      long var8 = var1.k();
      MZ var10 = var1.S();
      X var11 = (X)var1.u(lm::a);
      Tx var12 = var1.q();
      r0 var13 = var1.f();
      return new wQ(var5, (X)var6, var11, var3, var13, var2, var4, var7, var8, var10, var12);
   }

   public void V(lm<?> var1, wA var2) {
      wQ var3 = (wQ)var2;
      var1.l(var3.u(), lm::N);
      var1.y(var3.Q());
      var1.N(var3.F());
      var1.a(var3.X(), 256);
      var1.l(var3.b(), lm::G);
      var1.e(var3.u());
      var1.A(var3.o());
      var1.L(var3.T());
      var1.l(var3.B(), lm::G);
      var1.L(var3.q());
      var1.B(var3.K());
   }
}

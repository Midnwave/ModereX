package com.gmail.olexorus.themis;

import java.util.Objects;
import java.util.function.BiFunction;

public final class JB {
   private float w;
   private gC<md> b;
   private float B;
   private float L;

   public JB(float var1, gC<md> var2, float var3, float var4) {
      this.w = var1;
      this.b = var2;
      this.B = var3;
      this.L = var4;
   }

   public static JB R(lm<?> var0) {
      float var1 = var0.L();
      gC var2 = (gC)var0.u(JB::lambda$read$0);
      float var3 = var0.L();
      float var4 = var0.L();
      return new JB(var1, var2, var3, var4);
   }

   public static void Z(lm<?> var0, JB var1) {
      var0.S(var1.w);
      var0.l(var1.b, gC::n);
      var0.S(var1.B);
      var0.S(var1.L);
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof JB)) {
         return false;
      } else {
         JB var2 = (JB)var1;
         if (Float.compare(var2.w, this.w) != 0) {
            return false;
         } else if (Float.compare(var2.B, this.B) != 0) {
            return false;
         } else {
            return Float.compare(var2.L, this.L) != 0 ? false : Objects.equals(this.b, var2.b);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.w, this.b, this.B, this.L});
   }

   private static gC lambda$read$0(lm var0) {
      return gC.P((lm)var0, (BiFunction)V5.h());
   }
}

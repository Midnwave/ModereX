package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum TJ {
   WORLD_SURFACE_WG,
   WORLD_SURFACE,
   OCEAN_FLOOR_WG,
   OCEAN_FLOOR,
   MOTION_BLOCKING,
   MOTION_BLOCKING_NO_LEAVES;

   public static final l3<String, TJ> SERIALIZATION_KEY_INDEX;
   private final String I;
   private final boolean k;
   private static final TJ[] Q;

   private TJ(String var3, boolean var4) {
      this.I = var3;
      this.k = var4;
   }

   public static TJ q(String var0) {
      return (TJ)SERIALIZATION_KEY_INDEX.P(var0);
   }

   public static TJ R(lm<?> var0) {
      return (TJ)var0.i(TJ.class);
   }

   public static void A(lm<?> var0, TJ var1) {
      var0.o((Enum)var1);
   }

   public String n() {
      return this.I;
   }

   private static TJ[] Q() {
      return new TJ[]{WORLD_SURFACE_WG, WORLD_SURFACE, OCEAN_FLOOR_WG, OCEAN_FLOOR, MOTION_BLOCKING, MOTION_BLOCKING_NO_LEAVES};
   }

   static {
      long var0 = kt.a(2592836706402775874L, 7815601472462991852L, MethodHandles.lookup().lookupClass()).a(141801634653347L) ^ 37738281821312L;
      WORLD_SURFACE_WG = new TJ("WORLD_SURFACE_WG", 0, "WORLD_SURFACE_WG", false);
      WORLD_SURFACE = new TJ("WORLD_SURFACE", 1, "WORLD_SURFACE", true);
      OCEAN_FLOOR_WG = new TJ("OCEAN_FLOOR_WG", 2, "OCEAN_FLOOR_WG", false);
      OCEAN_FLOOR = new TJ("OCEAN_FLOOR", 3, "OCEAN_FLOOR", false);
      MOTION_BLOCKING = new TJ("MOTION_BLOCKING", 4, "MOTION_BLOCKING", true);
      MOTION_BLOCKING_NO_LEAVES = new TJ("MOTION_BLOCKING_NO_LEAVES", 5, "MOTION_BLOCKING_NO_LEAVES", true);
      Q = Q();
      SERIALIZATION_KEY_INDEX = l3.Q(TJ.class, TJ::n);
   }
}

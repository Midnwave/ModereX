package com.gmail.olexorus.themis;

public class ZA extends Zh<ZA> {
}

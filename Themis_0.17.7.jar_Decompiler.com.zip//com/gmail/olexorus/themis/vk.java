package com.gmail.olexorus.themis;

import java.util.Objects;

public class vk {
   private Gj<TN> B;

   public vk(Gj<TN> var1) {
      this.B = var1;
   }

   public static vk D(lm<?> var0) {
      Gj var1 = Gj.K(var0, TF.D(), TN::j);
      return new vk(var1);
   }

   public static void D(lm<?> var0, vk var1) {
      Gj.G(var0, var1.B, TN::k);
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof vk)) {
         return false;
      } else {
         vk var2 = (vk)var1;
         return this.B.equals(var2.B);
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.B);
   }
}

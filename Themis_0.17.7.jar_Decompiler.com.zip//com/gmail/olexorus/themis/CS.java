package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum CS {
   SUCCESSFULLY_LOADED,
   DECLINED,
   FAILED_DOWNLOAD,
   ACCEPTED,
   DOWNLOADED,
   INVALID_URL,
   FAILED_RELOAD,
   DISCARDED;

   public static final CS[] VALUES;
   private static final CS[] l;

   private static CS[] Q() {
      return new CS[]{SUCCESSFULLY_LOADED, DECLINED, FAILED_DOWNLOAD, ACCEPTED, DOWNLOADED, INVALID_URL, FAILED_RELOAD, DISCARDED};
   }

   static {
      long var0 = kt.a(50363171427340941L, 1180447811003325194L, MethodHandles.lookup().lookupClass()).a(8048044887545L) ^ 38229971239417L;
      SUCCESSFULLY_LOADED = new CS("SUCCESSFULLY_LOADED", 0);
      DECLINED = new CS("DECLINED", 1);
      FAILED_DOWNLOAD = new CS("FAILED_DOWNLOAD", 2);
      ACCEPTED = new CS("ACCEPTED", 3);
      DOWNLOADED = new CS("DOWNLOADED", 4);
      INVALID_URL = new CS("INVALID_URL", 5);
      FAILED_RELOAD = new CS("FAILED_RELOAD", 6);
      DISCARDED = new CS("DISCARDED", 7);
      l = Q();
      VALUES = values();
   }
}

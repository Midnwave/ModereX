package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class Go {
   private final gC<i> N;
   private final Optional<gC<i>> i;
   private final int I;
   private final int V;
   private final r2 C;
   private final r2 M;
   private final int q;
   private final List<tr> P;
   private static final long a = kt.a(5117675823212190720L, 6642505840513781440L, MethodHandles.lookup().lookupClass()).a(26198607188220L);

   public Go(gC<i> var1, Optional<gC<i>> var2, int var3, int var4, r2 var5, r2 var6, int var7, List<tr> var8) {
      this.N = var1;
      this.i = var2;
      this.I = var3;
      this.V = var4;
      this.C = var5;
      this.M = var6;
      this.q = var7;
      this.P = var8;
   }

   public static Go G(Rc var0, lm<?> var1) {
      long var2 = a ^ 83854704351090L;
      RT var4 = (RT)var0;
      gC var5 = (gC)var4.g("supported_items", Go::lambda$decode$0, var1);
      Optional var6 = Optional.ofNullable((gC)var4.M("primary_items", Go::lambda$decode$1, var1));
      int var7 = var4.N("weight").P();
      int var8 = var4.N("max_level").P();
      r2 var9 = (r2)var4.g("min_cost", r2::h, var1);
      r2 var10 = (r2)var4.g("max_cost", r2::h, var1);
      int var11 = var4.N("anvil_cost").P();
      Rc var12 = var4.W("slots");
      Object var13;
      if (var12 instanceof m_) {
         m_ var14 = (m_)var12;
         var13 = new ArrayList(var14.N());
         Iterator var15 = var14.N().iterator();

         while(var15.hasNext()) {
            Rc var16 = (Rc)var15.next();
            String var17 = ((mZ)var16).b();
            ((List)var13).add((tr)rN.V(tr.ID_INDEX, var17));
         }
      } else {
         String var18 = ((mZ)var12).b();
         tr var19 = (tr)rN.V(tr.ID_INDEX, var18);
         var13 = Collections.singletonList(var19);
      }

      return new Go(var5, var6, var7, var8, var9, var10, var11, (List)var13);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof Go)) {
         return false;
      } else {
         Go var2 = (Go)var1;
         if (this.I != var2.I) {
            return false;
         } else if (this.V != var2.V) {
            return false;
         } else if (this.q != var2.q) {
            return false;
         } else if (!this.N.equals(var2.N)) {
            return false;
         } else if (!this.i.equals(var2.i)) {
            return false;
         } else if (!this.C.equals(var2.C)) {
            return false;
         } else {
            return !this.M.equals(var2.M) ? false : this.P.equals(var2.P);
         }
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.N, this.i, this.I, this.V, this.C, this.M, this.q, this.P});
   }

   public String toString() {
      long var1 = a ^ 115742064896684L;
      return "EnchantmentDefinition{supportedItems=" + this.N + ", primaryItems=" + this.i + ", weight=" + this.I + ", maxLevel=" + this.V + ", minCost=" + this.C + ", maxCost=" + this.M + ", anvilCost=" + this.q + ", slots=" + this.P + '}';
   }

   private static void lambda$encode$2(RT var0, lm var1, gC var2) {
      long var3 = a ^ 8621249400967L;
      var0.X("primary_items", var2, gC::O, var1);
   }

   private static gC lambda$decode$1(Rc var0, lm var1) {
      return gC.T(var0, var1, z1.N());
   }

   private static gC lambda$decode$0(Rc var0, lm var1) {
      return gC.T(var0, var1, z1.N());
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Objects;
import java.util.function.Consumer;

final class GS implements EI {
   private C O = ci.E();
   private ab W;
   private VT P;
   private static final long a = kt.a(-5785917650238519608L, -5761218487035113783L, MethodHandles.lookup().lookupClass()).a(205566805416032L);

   GS() {
      A.K.accept(this);
   }

   public EI p(Consumer<gB> var1) {
      long var2 = a ^ 40902496673657L;
      gB var4 = ci.n().y().E(this.O);
      ((Consumer)Objects.requireNonNull(var1, "flagEditor")).accept(var4);
      this.O = var4.A();
      return this;
   }

   public EI u(ab var1) {
      this.W = var1;
      return this;
   }

   public EI b(VT var1) {
      this.P = var1;
      return this;
   }

   public MA v() {
      return new A(this.O, this.W, this.P);
   }
}

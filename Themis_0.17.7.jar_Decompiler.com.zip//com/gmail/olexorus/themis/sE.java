package com.gmail.olexorus.themis;

public class sE extends lm<sE> {
   private int x;
   private float u;

   public void t() {
      this.x = this.Q();
      this.u = (float)this.M() / 0.7111111F;
   }

   public void d() {
      this.E(this.x);
      this.u((int)(this.u * 0.7111111F));
   }

   public void B(sE var1) {
      this.x = var1.x;
      this.u = var1.u;
   }
}

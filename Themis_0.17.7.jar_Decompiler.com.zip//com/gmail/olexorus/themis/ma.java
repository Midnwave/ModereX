package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class ma extends mh {
   protected final short a;
   private static final long b = kt.a(1823857052222748715L, -2879014326404339129L, MethodHandles.lookup().lookupClass()).a(34863635418730L);

   public ma(short var1) {
      this.a = var1;
   }

   public Ay<ma> b() {
      return Ay.o;
   }

   public Number r() {
      return this.a;
   }

   public byte E() {
      return (byte)this.a;
   }

   public short x() {
      return this.a;
   }

   public int P() {
      return this.a;
   }

   public long Y() {
      return (long)this.a;
   }

   public float b() {
      return (float)this.a;
   }

   public double Q() {
      return (double)this.a;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 == null) {
         return false;
      } else if (this.getClass() != var1.getClass()) {
         return false;
      } else {
         ma var2 = (ma)var1;
         return this.a == var2.a;
      }
   }

   public int hashCode() {
      return Short.hashCode(this.a);
   }

   public ma U() {
      return this;
   }

   public String toString() {
      long var1 = b ^ 1908659741131L;
      return "Short(" + this.a + ")";
   }
}

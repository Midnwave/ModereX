package com.gmail.olexorus.themis;

public interface OT extends Vj {
   static OT S(double var0) {
      return new BS(var0);
   }

   default uX<OT> y() {
      return tq.O;
   }

   double r();
}

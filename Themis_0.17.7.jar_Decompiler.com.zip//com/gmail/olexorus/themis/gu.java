package com.gmail.olexorus.themis;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.lang.invoke.MethodHandles;

final class gu extends TypeAdapter<VE> {
   private final Gson H;
   private static final long a = kt.a(7942310603984285934L, -5539607219730527321L, MethodHandles.lookup().lookupClass()).a(273507245449225L);

   static TypeAdapter<VE> Z(Gson var0) {
      return (new gu(var0)).nullSafe();
   }

   private gu(Gson var1) {
      this.H = var1;
   }

   public void j(JsonWriter var1, VE var2) {
      long var3 = a ^ 8794832240839L;
      Object var5 = var2.P();
      if (var5 instanceof Boolean) {
         var1.value((Boolean)var5);
      } else if (var5 instanceof Number) {
         var1.value((Number)var5);
      } else {
         if (!(var5 instanceof X)) {
            throw new IllegalStateException("Unable to serialize translatable argument of type " + var5.getClass() + ": " + var5);
         }

         this.H.toJson(var5, zK.N, var1);
      }

   }

   public VE D(JsonReader var1) {
      // $FF: Couldn't be decompiled
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.Iterator;
import java.util.stream.Stream;

final class Bn extends BR implements zb {
   final byte[] I;
   private static final long a = kt.a(-7690171071622084755L, 3719176695790293578L, MethodHandles.lookup().lookupClass()).a(79353790976723L);

   Bn(byte[] var1) {
      this.I = Arrays.copyOf(var1, var1.length);
   }

   public byte[] x() {
      return Arrays.copyOf(this.I, this.I.length);
   }

   static byte[] g(zb var0) {
      return var0 instanceof Bn ? ((Bn)var0).I : var0.x();
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         Bn var2 = (Bn)var1;
         return Arrays.equals(this.I, var2.I);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Arrays.hashCode(this.I);
   }

   public Stream<? extends rE> T() {
      long var1 = a ^ 98120216981656L;
      return Stream.of(rE.F("value", this.I));
   }

   public Iterator<Byte> iterator() {
      return new NA(this);
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum TD {
   FOOT,
   HEAD;

   // $FF: synthetic method
   private static TD[] x() {
      return new TD[]{FOOT, HEAD};
   }

   static {
      long var0 = kt.a(-7913453109443027929L, 7662240081474105442L, MethodHandles.lookup().lookupClass()).a(6618599437771L) ^ 114191247708102L;
      FOOT = new TD("FOOT", 0);
      HEAD = new TD("HEAD", 1);
   }
}

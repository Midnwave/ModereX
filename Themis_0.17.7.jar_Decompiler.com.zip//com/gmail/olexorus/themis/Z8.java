package com.gmail.olexorus.themis;

import java.time.Instant;

public class Z8 extends lm<Z8> {
   private String y;
   private Bv P;
   private zf R;
   private GA T;

   public void t() {
      int var1 = this.I.i(zZ.V_1_11) ? 256 : 100;
      this.y = this.m(var1);
      if (this.I.i(zZ.V_1_19)) {
         Instant var2 = this.V();
         this.P = new Bv(this.x(), var2);
         if (this.I.i(zZ.V_1_19_3)) {
            this.R = this.C();
         } else {
            boolean var3 = this.P();
            this.P.d(var3);
            if (this.I.i(zZ.V_1_19_1)) {
               this.T = this.N();
            }
         }
      }

   }

   public void d() {
      int var1 = this.I.i(zZ.V_1_11) ? 256 : 100;
      this.a(this.y, var1);
      if (this.I.i(zZ.V_1_19)) {
         this.e(this.P.Z());
         this.e(this.P.I());
         if (this.I.i(zZ.V_1_19_3)) {
            if (this.R != null) {
               this.C(this.R);
            }
         } else {
            this.I(this.P.X());
            if (this.I.i(zZ.V_1_19_1) && this.T != null) {
               this.f(this.T);
            }
         }
      }

   }

   public void i(Z8 var1) {
      this.y = var1.y;
      this.P = var1.P;
      this.R = var1.R;
      this.T = var1.T;
   }
}

package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public class EJ {
   private static final long a = kt.a(6017317273998306432L, 7803296777225706285L, MethodHandles.lookup().lookupClass()).a(181106369619497L);

   public static RT m(lm<?> var0) {
      long var1 = a ^ 495149781195L;
      Rc var3 = var0.v();
      if (var3 instanceof RT) {
         return (RT)var3;
      } else if (var3 instanceof mZ) {
         String var4 = ((mZ)var3).b();
         return (RT)iA.B(var4);
      } else {
         throw new UnsupportedOperationException("Unsupported custom data nbt type: " + var3.b());
      }
   }

   public static void G(lm<?> var0, RT var1) {
      var0.G(var1);
   }
}

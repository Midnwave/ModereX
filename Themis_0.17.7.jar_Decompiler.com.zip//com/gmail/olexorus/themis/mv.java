package com.gmail.olexorus.themis;

class mv implements AY<or> {
   public <C> or o(NJ<C> var1, C var2, or var3) {
      return var3;
   }
}

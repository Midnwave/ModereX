package com.gmail.olexorus.themis;

public interface M5 extends GL {
}

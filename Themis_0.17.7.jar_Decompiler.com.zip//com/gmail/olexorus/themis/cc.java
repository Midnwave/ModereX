package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum cc {
   OPENED_TAB,
   CLOSED_SCREEN;

   private static final cc[] m;
   private static final cc[] P;

   public static cc c(int var0) {
      return m[var0];
   }

   private static cc[] h() {
      return new cc[]{OPENED_TAB, CLOSED_SCREEN};
   }

   static {
      long var0 = kt.a(7976579118729213795L, 6456953308358714949L, MethodHandles.lookup().lookupClass()).a(214637734682705L) ^ 10039567255355L;
      OPENED_TAB = new cc("OPENED_TAB", 0);
      CLOSED_SCREEN = new cc("CLOSED_SCREEN", 1);
      P = h();
      m = values();
   }
}

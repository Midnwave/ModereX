package com.gmail.olexorus.themis;

public class M3 extends Mo {
   private final boolean d(int var1) {
      return uv.G == null || uv.G >= var1;
   }

   public void F(Throwable var1, Throwable var2) {
      if (this.d(19)) {
         var1.addSuppressed(var2);
      } else {
         super.F(var1, var2);
      }

   }
}

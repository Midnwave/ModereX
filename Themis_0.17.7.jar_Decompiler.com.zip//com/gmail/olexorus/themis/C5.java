package com.gmail.olexorus.themis;

import java.util.Objects;

public final class C5 {
   private static final W2 d;
   private final W2 l;
   private final RT C;

   public C5(RT var1) {
      this(d, var1);
   }

   public C5(W2 var1, RT var2) {
      this.l = var1;
      this.C = var2;
   }

   public static C5 F(lm<?> var0) {
      W2 var1 = var0.R().i(zZ.V_1_21_9) ? (W2)var0.y((VD)bN.Q()) : d;
      RT var2 = var0.u();
      return new C5(var1, var2);
   }

   public static void D(lm<?> var0, C5 var1) {
      if (var0.R().i(zZ.V_1_21_9)) {
         var0.j((GL)var1.l);
      }

      var0.G(var1.C);
   }

   public RT q() {
      return this.C;
   }

   public boolean equals(Object var1) {
      if (var1 != null && this.getClass() == var1.getClass()) {
         C5 var2 = (C5)var1;
         return !this.l.equals(var2.l) ? false : this.C.equals(var2.C);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.l, this.C});
   }

   static {
      d = bN.i;
   }
}

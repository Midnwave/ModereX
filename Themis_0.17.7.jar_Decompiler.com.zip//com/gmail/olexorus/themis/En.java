package com.gmail.olexorus.themis;

enum En {
   public Boolean i(Boolean var1, Boolean var2) {
      return !var2 || !var1;
   }
}

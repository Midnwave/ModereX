package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public final class nU {
   private final long[] t;
   private int N;
   private double P;
   private static String i;
   private static final long a = kt.a(-8252052923942790388L, -884484693201816700L, MethodHandles.lookup().lookupClass()).a(154951597711980L);

   public nU() {
      long var1 = a ^ 71926635346544L;
      long var3 = var1 ^ 41632854016872L;
      super();
      this.t = new long[20];
      this.P = 20.0D;
      Bukkit.getScheduler().runTaskTimer((Plugin)Themis.g.n(new Object[]{var3}), nU::j, 0L, 1L);
   }

   public final double x(Object[] var1) {
      return this.P;
   }

   private static final void j(nU param0) {
      // $FF: Couldn't be decompiled
   }

   public static void K(String var0) {
      i = var0;
   }

   public static String d() {
      return i;
   }

   static {
      if (d() == null) {
         K("YYhzRc");
      }

   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}

package com.gmail.olexorus.themis;

public class QV extends lm<QV> {
   private int Q;
   private byte E;
   private double V;
   private double D;
   private double M;

   public void t() {
      this.Q = this.Q();
      this.E = this.M();
      if (this.I.i(zZ.V_1_9)) {
         this.V = this.o();
         this.D = this.o();
         this.M = this.o();
      } else {
         this.V = (double)this.f() / 32.0D;
         this.D = (double)this.f() / 32.0D;
         this.M = (double)this.f() / 32.0D;
      }

   }

   public void d() {
      this.E(this.Q);
      this.u(this.E);
      if (this.I.i(zZ.V_1_9)) {
         this.v(this.V);
         this.v(this.D);
         this.v(this.M);
      } else {
         this.L(a8.J(this.V * 32.0D));
         this.L(a8.J(this.D * 32.0D));
         this.L(a8.J(this.M * 32.0D));
      }

   }

   public void R(QV var1) {
      this.Q = var1.Q;
   }
}

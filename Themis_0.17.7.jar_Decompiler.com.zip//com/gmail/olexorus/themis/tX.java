package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public final class tX {
   private static final N8<ng> E;
   public static final ng s;
   public static final ng n;
   public static final ng u;
   public static final ng h;
   public static final ng O;
   public static final ng B;
   public static final ng A;
   public static final ng L;
   public static final ng m;
   public static final ng U;
   public static final ng q;
   public static final ng G;

   public static ng k(String var0, tT var1) {
      return (ng)E.h(var0, tX::lambda$define$0);
   }

   public static N8<ng> A() {
      return E;
   }

   private static ng lambda$define$0(tT var0, z2 var1) {
      return new iG(var1, var0);
   }

   static {
      long var0 = kt.a(5284449090896279714L, 6773824896374232328L, MethodHandles.lookup().lookupClass()).a(63245554591879L) ^ 10749834128435L;
      E = new N8("tropical_fish_pattern");
      s = k("kob", tT.SMALL);
      n = k("sunstreak", tT.SMALL);
      u = k("snooper", tT.SMALL);
      h = k("dasher", tT.SMALL);
      O = k("brinely", tT.SMALL);
      B = k("spotty", tT.SMALL);
      A = k("flopper", tT.LARGE);
      L = k("stripey", tT.LARGE);
      m = k("glitter", tT.LARGE);
      U = k("blockfish", tT.LARGE);
      q = k("betty", tT.LARGE);
      G = k("clayfish", tT.LARGE);
      E.f();
   }
}

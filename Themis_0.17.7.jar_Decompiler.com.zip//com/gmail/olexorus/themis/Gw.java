package com.gmail.olexorus.themis;

import java.util.function.BiConsumer;

public interface Gw<T> extends BiConsumer<lm<?>, T> {
}

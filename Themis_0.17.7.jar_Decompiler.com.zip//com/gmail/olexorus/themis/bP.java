package com.gmail.olexorus.themis;

public interface bP extends MC {
   static bP z() {
      return Bs.h;
   }

   default uX<bP> y() {
      return tq.j;
   }
}

package com.gmail.olexorus.themis;

public interface Vj extends MC {
   uX<? extends Vj> y();

   byte l();

   int p();
}

package com.gmail.olexorus.themis;

class b7 {
   final Bd A;
   final String[] g;
   final String R;
   final String c;

   b7(Bd var1, JD var2) {
      this(var1, var2.U, var2.Q, var2.v);
   }

   b7(Bd var1, String[] var2, String var3, String var4) {
      this.A = var1;
      this.g = var2;
      this.R = var4;
      this.c = var3;
   }
}

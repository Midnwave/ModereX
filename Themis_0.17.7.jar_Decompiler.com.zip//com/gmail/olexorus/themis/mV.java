package com.gmail.olexorus.themis;

public final class mV {
   private final float h;
   private final float U;
   private final float j;

   public mV(float var1, float var2, float var3) {
      this.h = var1;
      this.U = var2;
      this.j = var3;
   }

   public float l(float var1) {
      return ((this.h * var1 + this.U) * var1 + this.j) * var1;
   }

   public float b(float var1) {
      return (3.0F * this.h * var1 + 2.0F * this.U) * var1 + this.j;
   }
}

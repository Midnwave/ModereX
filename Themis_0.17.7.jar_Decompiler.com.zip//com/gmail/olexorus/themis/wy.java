package com.gmail.olexorus.themis;

import java.lang.invoke.MethodHandles;

public enum wy {
   START,
   LOG,
   FAIL,
   ACCEPT;

   private static final wy[] t;

   private static wy[] G() {
      return new wy[]{START, LOG, FAIL, ACCEPT};
   }

   static {
      long var0 = kt.a(2874543136762974436L, 5868039759849149934L, MethodHandles.lookup().lookupClass()).a(67132579963683L) ^ 121417829361696L;
      START = new wy("START", 0);
      LOG = new wy("LOG", 1);
      FAIL = new wy("FAIL", 2);
      ACCEPT = new wy("ACCEPT", 3);
      t = G();
   }
}

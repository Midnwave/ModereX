package com.gmail.olexorus.themis;

import java.util.List;
import java.util.function.BiConsumer;

public interface Re extends BiConsumer<lm<?>, List<Object>> {
}

package com.gmail.olexorus.themis;

public class iK<T extends T9> extends id implements ur<T> {
   private final Ot<T> Z;
   private final ms<T> c;

   public iK(z2 var1, Ot<T> var2, ms<T> var3) {
      super(var1);
      this.Z = var2;
      this.c = var3;
   }

   public T I(RT var1, lm<?> var2) {
      return (T9)this.Z.U(var1, var2);
   }

   public void C(RT var1, lm<?> var2, T var3) {
      this.c.r(var1, var2, var3);
   }
}

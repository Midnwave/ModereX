package com.gmail.olexorus.themis;

import java.util.List;

public class lJ {
   private al k;
   private List<Integer> f;

   public lJ(al var1, List<Integer> var2) {
      this.k = var1;
      this.f = var2;
   }

   public static lJ G(lm<?> var0) {
      al var1 = var0.R();
      List var2 = var0.j(lm::Q);
      return new lJ(var1, var2);
   }

   public static void E(lm<?> var0, lJ var1) {
      var0.T(var1.k);
      var0.D(var1.f, lm::E);
   }
}

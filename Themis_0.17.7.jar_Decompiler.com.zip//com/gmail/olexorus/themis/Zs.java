package com.gmail.olexorus.themis;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

public class Zs extends lm<Zs> {
   private int S;
   private Integer N;
   private int r;
   private int t;
   private Integer B;
   private NH q;
   private Map<Integer, TU> w;
   private Map<Integer, Optional<Ci>> k;
   private TU E;
   private Ci j;

   public void t() {
      this.S = this.a();
      this.N = this.I.i(zZ.V_1_17_1) ? this.Q() : null;
      this.r = this.x();
      this.t = this.M();
      this.B = this.I.i(zZ.V_1_17) ? null : Integer.valueOf(this.x());
      this.q = NH.p(this.Q());
      this.u();
   }

   protected void u() {
      if (this.I.i(zZ.V_1_21_5)) {
         this.k = this.Q(Zs::lambda$readSlots$0, Ci::T, 128);
         this.j = Ci.f(this);
      } else {
         if (this.I.i(zZ.V_1_17)) {
            this.w = this.U(Zs::lambda$readSlots$1, lm::u);
         }

         this.E = this.u();
      }

   }

   public void Y(Zs var1) {
      this.S = var1.S;
      this.N = var1.N;
      this.r = var1.r;
      this.t = var1.t;
      this.B = var1.B;
      this.q = var1.q;
      this.w = var1.w;
      this.k = var1.k;
      this.E = var1.E;
      this.j = var1.j;
   }

   public void d() {
      boolean var1 = this.I.i(zZ.V_1_17);
      this.y(this.S);
      if (this.I.i(zZ.V_1_17_1)) {
         this.E(this.N != null ? this.N : -1);
      }

      this.f(this.r);
      this.u(this.t);
      if (!var1) {
         this.f(this.B != null ? this.B : -1);
      }

      this.E(this.q.ordinal());
      if (this.I.i(zZ.V_1_21_5)) {
         this.o(this.k != null ? this.k : Collections.emptyMap(), lm::f, Ci::I);
         Ci.I(this, (Ci)this.j);
      } else {
         if (var1) {
            this.o(this.w != null ? this.w : Collections.emptyMap(), lm::f, lm::m);
         }

         this.m(this.E);
      }

   }

   private static Integer lambda$readSlots$1(lm var0) {
      return Math.toIntExact((long)var0.x());
   }

   private static Integer lambda$readSlots$0(lm var0) {
      return Math.toIntExact((long)var0.x());
   }
}

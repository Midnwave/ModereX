package com.gmail.olexorus.themis;

public class yo extends lm<yo> {
   private aX k;

   public void t() {
      if (this.I.i(zZ.V_1_21_6)) {
         this.k = (aX)this.i(aX.class);
      } else {
         this.k = aX.B(this.h());
      }

   }

   public void d() {
      if (this.I.i(zZ.V_1_21_6)) {
         this.o(this.k);
      } else {
         this.u(this.k.W());
      }

   }

   public void Q(yo var1) {
      this.k = var1.k;
   }
}
